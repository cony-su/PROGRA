/**
 * 
 */
/**
 * 
 */
module project {
	requires java.desktop;
	requires com.opencsv;
}