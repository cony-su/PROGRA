package project;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Arrays;
import com.opencsv.CSVReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class CSVDatos {
	GestorClientes gestor = new GestorClientes();
    
	public void leerClientes(List<Cliente> listaClientes) {
	    String csvFileClient = "C:\\Users\\scani\\Downloads\\21-c9e107e.xlsx - Avance SIA (4).csv"; // Cambia esto a la ruta de tu archivo CSV

	    try (BufferedReader br = new BufferedReader(new FileReader(csvFileClient))) {
	        String line;

	        while ((line = br.readLine()) != null) {
	            // Imprimir la línea para depuración

	            // Verificamos que la línea no esté vacía
	            if (!line.trim().isEmpty()) {
	                // Separamos los campos por comas
	                String[] campos = line.split(",");

	                // Validamos que la línea tenga suficientes campos
	                if (campos.length >= 10) {
	                    try {
	                        // Extraemos los campos
	                        String nombre = campos[0].trim();
	                        String fechaNacimiento = campos[1].trim();
	                        String rut = campos[2].trim();
	                        int numIdentificacion = Integer.parseInt(campos[3].trim());
	                        String direccion = campos[4].trim();
	                        String direccionFacturacion = campos[5].trim();
	                        String numTelefono = campos[6].trim();
	                        String correo = campos[7].trim();
	                        String equipoCompleto = campos[8].trim();
	                        String tipoPlan = campos[9].trim();
	                        
	                        if (gestor.buscarClientePorRut(listaClientes, rut) != null)
	                        	continue;

	                        // Procesamos el equipo
	                        String[] equipoPartes = equipoCompleto.split(" ");
	                        String marca = equipoPartes[0];
	                        String modelo = equipoPartes[1];
	                        String numeroSerie = equipoPartes[2];

	                        // Creamos los objetos de DatosPersonales, DatosContacto y Equipo
	                        DatosPersonales datosPersonales = new DatosPersonales(nombre, fechaNacimiento, direccion, rut);
	                        datosPersonales.setNumeroIdentificacion(numIdentificacion);

	                        DatosContacto datosContacto = new DatosContacto(direccionFacturacion, numTelefono, correo);
	                        Equipo equipo = new Equipo(marca, modelo, numeroSerie);

	                        // Creamos el cliente en base al tipo de plan
	                        PlanesDisponibles plan = null;

	                        switch (tipoPlan) {
	                            case "Plan Económico":
	                                plan = new PlanesDisponibles("Plan Económico", 8000, false, 60, false, 0, false, 10);
	                                break;
	                            case "Plan Básico":
	                                plan = new PlanesDisponibles("Plan Básico", 12000, false, 120, false, 30, false, 50);
	                                break;
	                            case "Plan Normal":
	                                plan = new PlanesDisponibles("Plan Normal", 15000, false, 200, false, 100, false, 100);
	                                break;
	                            case "Plan Premium":
	                                plan = new PlanesDisponibles("Plan Premium", 20000, true, 0, true, 0, true, 0);
	                                break;
	                            default:
	                                System.out.println("Tipo de plan inválido: " + tipoPlan);
	                                continue; // Si el plan es inválido, pasamos a la siguiente línea
	                        }

	                        Cliente cliente = new Cliente(datosPersonales, datosContacto, plan, equipo);
	                        listaClientes.add(cliente);

	                    } catch (NumberFormatException e) {
	                        System.out.println("Error al convertir un número en la línea: " + line);
	                    }
	                } else {
	                    System.out.println("Línea inválida: " + line);
	                }
	            }
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	
    public void leerFacturas(List<Cliente> listaClientes) {
        String csvFileFacturas = "C:\\Users\\scani\\Downloads\\Facturascsv (3).csv"; // Cambia esto a la ruta de tu archivo CSV

        try (BufferedReader br = new BufferedReader(new FileReader(csvFileFacturas))) {
            String line;

            while ((line = br.readLine()) != null) {
                // Verificamos que la línea no esté vacía
                if (!line.trim().isEmpty()) {
                    // Separamos los campos por comas
                    String[] partes = line.split(",");

                    // Validamos que la línea tenga suficientes campos (5 en total)
                    if (partes.length >= 5) {
                        String rut = partes[0].trim(); // RUT del cliente
                        Cliente client = gestor.buscarClientePorRut(listaClientes, rut);
                        String id = partes[1].trim();
                        
                        // Cambia aquí a Double.parseDouble
                        double Monto = Double.parseDouble(partes[2].trim()); // Asegúrate de que sea Double

                        String fechaEmision = partes[3].trim(); // Fecha de emisión
                        String estadoStr = partes[4].trim(); // Estado

                        // Comparamos el estado para asignar el valor booleano
                        boolean estado = false;
                        if (estadoStr.equals("Pagado"))
                        	estado = true;

                        // Creamos la factura
                        Factura factura = new Factura(id, Monto, fechaEmision, estado);

                        // Verificamos que el cliente no sea nulo antes de agregar la factura
                        if (client != null) {
                            client.agregarFactura(factura);
                        } else {
                            System.out.println("Cliente no encontrado para RUT: " + rut);
                        }
                    } else {
                        System.out.println("Línea inválida: " );
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.out.println("Error de formato en la línea: " );
            e.printStackTrace();
        }
    }

	
	public void leerTarjetas(List<Cliente> listaClientes) {
	    String csvFileTarjetas = "C:\\Users\\scani\\Downloads\\Tarjetascsv (3).csv"; // Cambia esto a la ruta de tu archivo CSV
	    
	    try (BufferedReader br = new BufferedReader(new FileReader(csvFileTarjetas))) {
	        String line;

	        while ((line = br.readLine()) != null) {
	            // Verificamos que la línea no esté vacía
	            if (!line.trim().isEmpty()) {
	                // Separamos los campos por comas
	                String[] campos = line.split(",");

	                // Validamos que la línea tenga suficientes campos
	                if (campos.length >= 8) {
	                	String nombre = campos[0].trim();
	                    String rut = campos[1].trim(); // RUT del cliente
	                    Cliente client = gestor.buscarClientePorRut(listaClientes, rut);
	                    String medioPagoStr = campos[2].trim();
	                    String tipoTarjetaStr = campos[3].trim();
	                    String nombreTitular = campos[4].trim();
	                    String numTarjeta = campos[5].trim();
	                    String fechaVencimiento = campos[6].trim();
	                    String codigoSeguridad = campos[7].trim();
	                    
	                    int medioPago;
	                    int tipoTarjeta;

	                    switch (medioPagoStr) {
                        case "Crédito":
                        	medioPago = 1;
                            break;
                        case "Débito":
                        	medioPago = 2;
                            break;
                        default:
                            System.out.println("Metodo de pago inválido: " + medioPagoStr);
                            continue; // Si el plan es inválido, pasamos a la siguiente línea
	                    }
	                    
	                    switch (tipoTarjetaStr) {
	                    	case "Visa":
	                    		tipoTarjeta = 1;
	                    		break;
	                    	case "MasterCard":
	                    		tipoTarjeta = 2;
	                    		break;
	                    	case "American Express":
	                    		tipoTarjeta = 3;
	                    		break;
	                    	case "Diners Club":
	                    		tipoTarjeta = 4;
	                    		break;
	                    	case "Visa Débito":
	                    		tipoTarjeta = 1;
	                    		break;
	                    	case "MasterCard Débito":
	                    		tipoTarjeta = 2;
	                    		break;
	                    	case "Redcompra":
	                    		tipoTarjeta = 3;
	                    		break;
	                    	case "Bank Red":
	                    		tipoTarjeta = 4;
	                    		break;
	                    	default:
	                    		System.out.println("Tipo de tarjeta inválido: " + tipoTarjetaStr);
	                    		continue; // Si el plan es inválido, pasamos a la siguiente línea
	                    }
	                    
	                    // Creamos la tarjeta
	                    Tarjeta tarjeta = new Tarjeta(medioPago, tipoTarjeta, nombreTitular, numTarjeta, fechaVencimiento, codigoSeguridad);

	                    // Verificamos que el cliente no sea nulo antes de agregar la tarjeta
	                    if (client != null) {
	                        client.agregarTarjeta(tarjeta);
	                    } else {
	                        System.out.println("Cliente no encontrado para RUT: " + rut);
	                    }
	                } else {
	                    System.out.println("Línea inválida: " + line);
	                }
	            }
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	
	
	// Registro de cliente en csv

	public void registrarClienteCSV(List<Cliente> listaClientes) {
	    String rutaCSV = "C:\\Users\\scani\\Downloads\\21-c9e107e.xlsx - Avance SIA (4).csv"; // Cambiar a localización del archivo CSV
	    
	    try (BufferedReader br = new BufferedReader(new FileReader(rutaCSV))) {
	        
	        
	        try (CSVWriter writer = new CSVWriter(new FileWriter(rutaCSV, false),
	        														CSVWriter.DEFAULT_SEPARATOR,
	        														CSVWriter.NO_QUOTE_CHARACTER,
	        														CSVWriter.DEFAULT_ESCAPE_CHARACTER,
	        														CSVWriter.DEFAULT_LINE_END)) {
	        	for (Cliente client : listaClientes)
	        	{
	        	

	        		String[] cliente = {client.getDatosPersonales().getNombreCliente(), 
	        							client.getDatosPersonales().getFechaNacimiento(), 
	        							client.getDatosPersonales().getRut(), 
	        							String.valueOf(client.getDatosPersonales().getNumeroIdentificacion()), 
	        							client.getDatosPersonales().getDireccion(), 
	        							client.getDatosContacto().getDireccionFacturacion(), 
	        							client.getDatosContacto().getTelefono(), 
	        							client.getDatosContacto().getCorreo(), 
	        							client.getEquipo().getMarca() + " " + client.getEquipo().getModelo() + " " + client.getEquipo().getNumeroSerie(), 
	        							client.getPlan().getNombrePlan()};

	        		writer.writeNext(cliente);


	        	} 
	        }catch (IOException e) {
	        		e.printStackTrace();
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

	
	
	public void registrarFacturasCSV(List<Cliente> listaClientes) {
	    String rutaCSV = "C:\\Users\\scani\\Downloads\\Facturascsv (3).csv"; // Cambiar a localización del archivo CSV
	    
	    try (BufferedReader br = new BufferedReader(new FileReader(rutaCSV))) {
	        
	    
	        try (CSVWriter writer = new CSVWriter(new FileWriter(rutaCSV, false),
	        		CSVWriter.DEFAULT_SEPARATOR,
	        		CSVWriter.NO_QUOTE_CHARACTER,
	        		CSVWriter.DEFAULT_ESCAPE_CHARACTER,
	        		CSVWriter.DEFAULT_LINE_END)) {

	        	for (Cliente client : listaClientes) { // Itera sobre toda la lista de clientes
	        		DatosPersonales datosPersonales = client.getDatosPersonales();
	        		Map<String, Factura> map = client.getFacturas();

	        		for (Factura fact : map.values()) {
	        			String estado = "Pagado";
	        			
	        			if(!fact.getPagado())
	        				estado = "Pendiente";

	        			String[] factura = {
	        					datosPersonales.getRut(), // RUT del propietario
	        					String.valueOf(fact.getIdFactura()), // ID de la factura
	        					String.valueOf(fact.getMonto()), // Monto de la factura
	        					fact.getFechaEmision(), // Fecha de emisión
	        					estado // Estado de la factura
	        			};

	        			writer.writeNext(factura);
	            	}
	        	}
	    	} catch (IOException e) {
	    	e.printStackTrace();
	    	}
	    
		} catch (IOException e) {
	        e.printStackTrace();
	    }
	}

	public void registrarTarjetasCSV(List<Cliente> listaClientes) {
	    String rutaCSV = "\"C:\\Users\\scani\\Downloads\\Tarjetascsv (3).csv\""; // Cambiar a localización del archivo CSV
	    
	    try (BufferedReader br = new BufferedReader(new FileReader(rutaCSV))) {
	        
	    
	        try (CSVWriter writer = new CSVWriter(new FileWriter(rutaCSV, false),
	        		CSVWriter.DEFAULT_SEPARATOR,
	        		CSVWriter.NO_QUOTE_CHARACTER,
	        		CSVWriter.DEFAULT_ESCAPE_CHARACTER,
	        		CSVWriter.DEFAULT_LINE_END)) {

	        	for (Cliente client : listaClientes) { // Itera sobre toda la lista de clientes
	        		DatosPersonales datosPersonales = client.getDatosPersonales();
	        		Map<String, Tarjeta> map = client.getTarjetasRegistradas();

	        		for (Tarjeta tarj : map.values()) {
	        			String[] tarjetaDatos = {
	        					datosPersonales.getNombreCliente(), // Nombre del propietario
	        					datosPersonales.getRut(), // RUT del propietario
	        					tarj.getMetodoPago(), // Medio de pago
	        					tarj.getTipoTarjeta(), // Tipo de tarjeta
	        					tarj.getNombreTitular(), // Nombre del titular
	        					tarj.getNumeroTarjeta(), // Número de tarjeta
	        					tarj.getFechaVencimiento(), // Fecha de vencimiento
	        					String.valueOf(tarj.getCodigoSeguridad()) // Código de seguridad
	        			};

	        			writer.writeNext(tarjetaDatos);
	        		}
	        	}
	        } catch (IOException e) {
	        	e.printStackTrace();
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	
	public void guardarCambios(List<Cliente> listaClientes) {
	    registrarClienteCSV(listaClientes);
	    registrarFacturasCSV(listaClientes);
	    registrarTarjetasCSV(listaClientes);
	    System.out.println("Cambios guardados en CSV.");
	}
}