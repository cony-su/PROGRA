package project;

import java.util.*; 
import com.opencsv.CSVReader;

/**
 * La clase Cliente representa un cliente en el sistema de gestión.
 * Contiene información personal, de contacto, el plan asociado,
 * facturas y tarjetas registradas, así como el equipo del cliente.
 */
class Cliente {
  
  private DatosPersonales datosPersonales; // Información personal del cliente
  private DatosContacto datosContacto; // Información de contacto del cliente
  private PlanesDisponibles plan; // Plan contratado por el cliente
  private HashMap<String, Factura> facturas; // Colección de facturas asociadas al cliente
  private HashMap<String, Tarjeta> tarjetasRegistradas; // Colección de tarjetas registradas del cliente
  private Equipo equipo; // Equipo asociado al cliente

  /**
   * Constructor para crear un nuevo cliente.
   *
   * @param datosPersonales  Datos personales del cliente
   * @param datosContacto    Datos de contacto del cliente
   * @param plan             Plan contratado por el cliente
   * @param equipo           Equipo asociado al cliente
   */
  public Cliente(DatosPersonales datosPersonales, DatosContacto datosContacto, PlanesDisponibles plan, Equipo equipo) {
    this.datosPersonales = datosPersonales;
    this.datosContacto = datosContacto;
    this.plan = plan;
    this.equipo = equipo;
    facturas = new HashMap<String, Factura>();
    tarjetasRegistradas = new HashMap<String, Tarjeta>();
  }

  // Métodos de acceso (getters y setters)

  /**
   * Obtiene los datos personales del cliente.
   *
   * @return DatosPersonales del cliente
   */
  public DatosPersonales getDatosPersonales() {
    return datosPersonales;
  }

  /**
   * Establece los datos personales del cliente.
   *
   * @param datosPersonales Datos personales a establecer
   */
  public void setDatosPersonales(DatosPersonales datosPersonales) {
    this.datosPersonales = datosPersonales;
  }                                                                     

  /**
   * Obtiene los datos de contacto del cliente.
   *
   * @return DatosContacto del cliente
   */
  public DatosContacto getDatosContacto() {
    return datosContacto;
  }

  /**
   * Establece los datos de contacto del cliente.
   *
   * @param datosContacto Datos de contacto a establecer
   */
  public void setDatosContacto(DatosContacto datosContacto) {
    this.datosContacto = datosContacto;
  }

  /**
   * Obtiene el plan contratado por el cliente.
   *
   * @return PlanesDisponibles del cliente
   */
  public PlanesDisponibles getPlan() {
    return plan;
  }

  /**
   * Establece el plan contratado por el cliente.
   *
   * @param plan Plan a establecer
   */
  public void setPlan(PlanesDisponibles plan) {
    this.plan = plan;
  }

  /**
   * Obtiene el equipo asociado al cliente.
   *
   * @return Equipo del cliente
   */
  public Equipo getEquipo() {
    return equipo;
  }

  /**
   * Establece el equipo asociado al cliente.
   *
   * @param equipo Equipo a establecer
   */
  public void setEquipo(Equipo equipo) {
    this.equipo = equipo;
  }

  /**
   * Obtiene la colección de facturas del cliente.
   *
   * @return HashMap de facturas
   */
  public HashMap<String, Factura> getFacturas() {
    return facturas;
  }

  /**
   * Establece la colección de facturas del cliente.
   *
   * @param facturas Colección de facturas a establecer
   */
  public void setFacturas(HashMap<String, Factura> facturas) {
    this.facturas = facturas;
  }

  /**
   * Obtiene la colección de tarjetas registradas del cliente.
   *
   * @return HashMap de tarjetas registradas
   */
  public HashMap<String, Tarjeta> getTarjetasRegistradas() {
    return tarjetasRegistradas;
  }

  /**
   * Establece la colección de tarjetas registradas del cliente.
   *
   * @param tarjetasRegistradas Colección de tarjetas a establecer
   */
  public void setTarjetasRegistradas(HashMap<String, Tarjeta> tarjetasRegistradas) {
    this.tarjetasRegistradas = tarjetasRegistradas;
  }

  
  

  //MÉTODOS PARA FACTURAS
  public void agregarFactura(Factura factura) //SOBRECARGA DE MÉTODOS 1.1
  {
    facturas.put(factura.getIdFactura(), factura);
  }

  public void agregarFactura(String idFactura, double monto, String fechaEmision, boolean pagado) //SOBRECARGA DE MÉTODOS 1.2
  {
    Factura factura = new Factura(idFactura, monto, fechaEmision, pagado);
    facturas.put(factura.getIdFactura(), factura);
  }
  
  public Factura buscarFactura(String id)
  {
	  if(facturas.containsKey(id)) return facturas.get(id);
	  else return null;
  }
  
  
  

  //MÉTODOS PARA TARJETAS
  public void agregarTarjeta(Tarjeta tarjeta) //SOBRECARGA DE MÉTODOS 2.1
  {
    tarjetasRegistradas.put(tarjeta.getNumeroTarjeta(), tarjeta);
  }

  public void agregarTarjeta(int metodoPago, int tipoTarjeta, String nombreTitular, String numeroTarjeta, String fechaVencimiento, String codigoSeguridad) //SOBRECARGA DE MÉTODOS 2.1
  {
    Tarjeta tarjeta = new Tarjeta(metodoPago, tipoTarjeta, nombreTitular, numeroTarjeta, fechaVencimiento, codigoSeguridad);
    tarjetasRegistradas.put(tarjeta.getNumeroTarjeta(), tarjeta);
  }
  
  public Tarjeta buscarTarjeta(String numSerie)
  {
	  if(tarjetasRegistradas.containsKey(numSerie)) return tarjetasRegistradas.get(numSerie);
	  else return null;
  }
  
  public void MostrarTarjetas()
  {
	  int contadorT = 1;
	  if( tarjetasRegistradas == null) 
	  {
		  System.out.println("No hay Tarjetas Registradas");
		  return;
	  }
      for(String NumSerie : getTarjetasRegistradas().keySet())
      {
    	Tarjeta tarjeta = getTarjetasRegistradas().get(NumSerie); 
        System.out.println(contadorT + ". ");
        tarjeta.mostrarTarjeta();
        contadorT++;
      }
  }
  
  public boolean EliminarTarjeta(String numSerie)
  {
	  for(String clave : getTarjetasRegistradas().keySet())
	  {
		  Tarjeta tarjeta = getTarjetasRegistradas().get(clave);
		  if((numSerie).equals(tarjeta.getNumeroTarjeta()))
		  {
			  tarjetasRegistradas.remove(numSerie); 		 
			  return true;
		  }
	  }
	  return false;
  }
  
  //MÉTODOS PARA CLIENTES
  public void mostrarCliente()
  {
	  System.out.println("Nombre: " + getDatosPersonales().getNombreCliente());
	  System.out.println("Rut: " + getDatosPersonales().getRut());
	  System.out.println("Numero de Identificación: " + getDatosPersonales().getNumeroIdentificacion());
	  System.out.println("Dirección: " + getDatosPersonales().getDireccion());
	  System.out.println("Tipo de Plan: " + getPlan().getNombrePlan());
	  System.out.println("Equipo: " + getEquipo().getMarca() + " " + getEquipo().getModelo());
	  System.out.println("Facturas:");

	  if (getFacturas() == null || getFacturas().isEmpty()) System.out.println("  No hay facturas para mostrar.");
	    
	  else 
	  {
		  for(String idFactura : getFacturas().keySet())
		  {
	         Factura factura = getFacturas().get(idFactura); // Obtiene la factura usando el idFactura
	         System.out.print("  - Factura ID: " + factura.getIdFactura() + ", Monto: $" + factura.getMonto() + ", Fecha: " + factura.getFechaEmision() + ", Estado de Factura: ");
	         if (factura.getPagado()) System.out.println("PAGADO");
	         else System.out.println("NO PAGADO");
		  }
	  }	  
	  System.out.println("--------------------------------------------------------------------------------------");
  }
  
  public boolean clienteDeudor()
  {
	  if(getFacturas() == null || getFacturas().isEmpty()) return false;
	  
	  int count = 0;
	  
	  for(String idFactura : getFacturas().keySet())
	  {
		  Factura factura = getFacturas().get(idFactura);
	      if (factura.getPagado() == false) count++;	         
	  }
	  if(count >= 2) return true;
	  return false;
  }
  
  @Override
  public String toString() {
      StringBuilder sb = new StringBuilder();
      
      sb.append("Nombre: ").append(getDatosPersonales().getNombreCliente()).append("\n");
      sb.append("Rut: ").append(getDatosPersonales().getRut()).append("\n");
      sb.append("Número de Identificación: ").append(getDatosPersonales().getNumeroIdentificacion()).append("\n");
      sb.append("Dirección: ").append(getDatosPersonales().getDireccion()).append("\n");
      sb.append("Tipo de Plan: ").append(getPlan().getNombrePlan()).append("\n");
      sb.append("Equipo: ").append(getEquipo().getMarca()).append(" ").append(getEquipo().getModelo()).append("\n");
      sb.append("Facturas:\n");
      
      if (getFacturas().isEmpty()) {
          sb.append("  No hay facturas para mostrar.\n");
      } else {
          for (String idFactura : getFacturas().keySet()) {
              Factura factura = getFacturas().get(idFactura);
              sb.append("  - Factura ID: ").append(factura.getIdFactura())
                .append(", Monto: $").append(factura.getMonto())
                .append(", Fecha: ").append(factura.getFechaEmision())
                .append(", Estado: ").append(factura.getPagado() ? "PAGADO" : "NO PAGADO").append("\n");
          }
      }
      
      sb.append("Tarjetas Registradas:\n");
      if (getTarjetasRegistradas().isEmpty()) {
          sb.append("  No hay tarjetas registradas.\n");
      } else {
          for (String numTarjeta : getTarjetasRegistradas().keySet()) {
              Tarjeta tarjeta = getTarjetasRegistradas().get(numTarjeta);
              sb.append("  - Tarjeta: ").append(tarjeta.getNumeroTarjeta()).append("\n");
          }
      }
      
      return sb.toString();
  }

}

