package project;

import java.util.*; 
import java.util.HashMap;

/**
 * La clase ClientesDeudores gestiona un mapa de clientes que son deudores.
 */
public class ClientesDeudores 
{
    // Mapa que almacena los clientes deudores, con su número de identificación como clave
    HashMap <Integer, Cliente> mapaClientesDeudores = null; 

    /**
     * Constructor de la clase ClientesDeudores.
     * Inicializa el mapa de clientes deudores.
     */
    public ClientesDeudores()
    {
        mapaClientesDeudores = new HashMap<Integer, Cliente>(); 
    }

    /**
     * Obtiene el mapa de clientes deudores.
     *
     * @return mapa de clientes deudores
     */
    public HashMap<Integer, Cliente> getMapaClientesDeudores()
    {
        return mapaClientesDeudores;
    }

    /**
     * Establece el mapa de clientes deudores.
     *
     * @param mapaClientesDeudores Mapa de clientes deudores a establecer
     */
    public void setMapaClientesDeudores(HashMap<Integer, Cliente> mapaClientesDeudores)
    {
        this.mapaClientesDeudores = mapaClientesDeudores;
    }

    /**
     * Llena el mapa de clientes deudores a partir de una lista de clientes.
     *
     * @param listaClientes Lista de clientes a evaluar
     */
    public void llenarMapa(ArrayList<Cliente> listaClientes)
    {
        for(Cliente cliente : listaClientes)
        {
            // Si el cliente es deudor, se añade al mapa
            if(cliente.clienteDeudor()) 
                mapaClientesDeudores.put(cliente.getDatosPersonales().getNumeroIdentificacion(), cliente);
        }
    }

    /**
     * Elimina un cliente del mapa de deudores si ya no es considerado deudor.
     *
     * @param cliente Cliente a eliminar
     * @return true si se eliminó el cliente, false si el cliente sigue siendo deudor
     */
    public boolean eliminarDeudor(Cliente cliente) //si ya no es deudor lo quito del mapa
    {
        if(cliente.clienteDeudor()) 
            return false;     
        mapaClientesDeudores.remove(cliente.getDatosPersonales().getNumeroIdentificacion(), cliente);
        return true;
    }

    /**
     * Muestra todos los clientes deudores.
     *
     * @return true si se mostraron clientes deudores, false si no hay clientes deudores
     */
    public boolean mostrarClientesDeudores()
    {
        if(getMapaClientesDeudores() == null || getMapaClientesDeudores().isEmpty()) 
            return false;
        
        for(int numID : getMapaClientesDeudores().keySet())
        {
            Cliente cliente = getMapaClientesDeudores().get(numID);
            cliente.mostrarCliente(); // Muestra la información del cliente
        }
        return true;
    }
}
