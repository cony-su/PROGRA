package project;

/**
 * La clase DatosContacto almacena la información de contacto de un cliente,
 * incluyendo la dirección de facturación, el número de teléfono y el correo electrónico.
 */
class DatosContacto
{
    private String direccionFacturacion; // Almacena la dirección de facturación del cliente
    private String telefono; // Almacena el número de teléfono del cliente
    private String correo; // Almacena el correo electrónico del cliente

    /**
     * Constructor de la clase DatosContacto que inicializa los atributos.
     *
     * @param direccionFacturacion La dirección de facturación del cliente.
     * @param telefono El número de teléfono del cliente.
     * @param correo El correo electrónico del cliente.
     */
    public DatosContacto(String direccionFacturacion, String telefono, String correo)
    {
        this.direccionFacturacion = direccionFacturacion; // Inicializa la dirección de facturación
        this.telefono = telefono; // Inicializa el número de teléfono
        this.correo = correo; // Inicializa el correo electrónico
    }

    // SETTERS Y GETTERS

    /**
     * Obtiene la dirección de facturación del cliente.
     *
     * @return La dirección de facturación.
     */
    public String getDireccionFacturacion()
    {
        return direccionFacturacion; // Retorna la dirección de facturación
    }

    /**
     * Establece la dirección de facturación del cliente.
     *
     * @param direccionFacturacion La nueva dirección de facturación.
     */
    public void setDireccionFacturacion(String direccionFacturacion)
    {
        this.direccionFacturacion = direccionFacturacion; // Actualiza la dirección de facturación
    }

    /**
     * Obtiene el número de teléfono del cliente.
     *
     * @return El número de teléfono.
     */
    public String getTelefono()
    {
        return telefono; // Retorna el número de teléfono
    }

    /**
     * Establece el número de teléfono del cliente.
     *
     * @param telefono El nuevo número de teléfono.
     */
    public void setTelefono(String telefono)
    {
        this.telefono = telefono; // Actualiza el número de teléfono
    }

    /**
     * Obtiene el correo electrónico del cliente.
     *
     * @return El correo electrónico.
     */
    public String getCorreo()
    {
        return correo; // Retorna el correo electrónico
    }

    /**
     * Establece el correo electrónico del cliente.
     *
     * @param correo El nuevo correo electrónico.
     */
    public void setCorreo(String correo)
    {
        this.correo = correo; // Actualiza el correo electrónico
    }
}
