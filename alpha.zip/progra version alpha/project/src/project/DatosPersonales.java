package project;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * La clase DatosPersonales almacena la información personal de un cliente,
 * incluyendo su nombre, fecha de nacimiento, dirección, número de identificación
 * y RUT. Además, genera un número de serie único para cada cliente.
 */
class DatosPersonales
{  
    private String nombreCliente; // Almacena el nombre del cliente
    private String fechaNacimiento; // Almacena la fecha de nacimiento del cliente
    private String direccion; // Almacena la dirección del cliente
    private int numeroIdentificacion; // Almacena un número de identificación único para el cliente
    private String rut; // Almacena el RUT del cliente
    private static Set<Integer> seriesGeneradas = new HashSet<>(); // Conjunto para almacenar números de serie generados

    /**
     * Constructor de la clase DatosPersonales que inicializa los atributos.
     *
     * @param nombreCliente El nombre del cliente.
     * @param FechaNacimiento La fecha de nacimiento del cliente.
     * @param direccion La dirección del cliente.
     * @param rut El RUT del cliente.
     */
    public DatosPersonales(String nombreCliente, String FechaNacimiento, String direccion, String rut)
    {
        this.nombreCliente = nombreCliente; // Inicializa el nombre del cliente
        this.fechaNacimiento = FechaNacimiento; // Inicializa la fecha de nacimiento
        this.direccion = direccion; // Inicializa la dirección
        this.numeroIdentificacion = generarNumSerieUnico(); // Genera un número de serie único
        this.rut = rut; // Inicializa el RUT
    }

    /**
     * Constructor sobrecargado de la clase DatosPersonales que permite establecer
     * un número de identificación específico.
     *
     * @param nombreCliente El nombre del cliente.
     * @param FechaNacimiento La fecha de nacimiento del cliente.
     * @param direccion La dirección del cliente.
     * @param rut El RUT del cliente.
     * @param numeroIdentificacion El número de identificación del cliente.
     */
    public DatosPersonales(String nombreCliente, String FechaNacimiento, String direccion, String rut, int numeroIdentificacion)
    {
        this.nombreCliente = nombreCliente; // Inicializa el nombre del cliente
        this.fechaNacimiento = FechaNacimiento; // Inicializa la fecha de nacimiento
        this.direccion = direccion; // Inicializa la dirección
        this.numeroIdentificacion = numeroIdentificacion; // Inicializa el número de identificación
        this.rut = rut; // Inicializa el RUT
    }

    /**
     * Genera un número de serie único de 4 dígitos entre 1000 y 9999.
     * 
     * @return Un número de serie único.
     */
    private int generarNumSerieUnico() {
        Random random = new Random();
        int serie;
        do {
            // Genera un número aleatorio de 4 dígitos entre 1000 y 9999
            serie = random.nextInt(9000) + 1000;
        } while (seriesGeneradas.contains(serie)); // Repetir si el número ya existe
        seriesGeneradas.add(serie); // Añadir el número al conjunto para no repetirlo
        return serie; // Retorna el número de serie único generado
    }

    // SETTERS Y GETTERS

    /**
     * Obtiene el nombre del cliente.
     *
     * @return El nombre del cliente.
     */
    public String getNombreCliente(){ 
        return nombreCliente; // Retorna el nombre del cliente
    }

    /**
     * Establece el nombre del cliente.
     *
     * @param nombreCliente El nuevo nombre del cliente.
     */
    public void setnombreCliente(String nombreCliente){
        this.nombreCliente = nombreCliente; // Actualiza el nombre del cliente
    }

    /**
     * Obtiene la fecha de nacimiento del cliente.
     *
     * @return La fecha de nacimiento.
     */
    public String getFechaNacimiento(){
        return fechaNacimiento; // Retorna la fecha de nacimiento
    }

    /**
     * Establece la fecha de nacimiento del cliente.
     *
     * @param fechaNacimiento La nueva fecha de nacimiento.
     */
    public void setFechaNacimiento(String fechaNacimiento){
        this.fechaNacimiento = fechaNacimiento; // Actualiza la fecha de nacimiento
    }

    /**
     * Obtiene la dirección del cliente.
     *
     * @return La dirección.
     */
    public String getDireccion(){
        return direccion; // Retorna la dirección del cliente
    }

    /**
     * Establece la dirección del cliente.
     *
     * @param direccion La nueva dirección.
     */
    public void setDireccion(String direccion){
        this.direccion = direccion; // Actualiza la dirección
    }

    /**
     * Obtiene el número de identificación del cliente.
     *
     * @return El número de identificación.
     */
    public int getNumeroIdentificacion(){
        return numeroIdentificacion; // Retorna el número de identificación
    }

    /**
     * Establece el número de identificación del cliente.
     *
     * @param numeroIdentificacion El nuevo número de identificación.
     */
    public void setNumeroIdentificacion(int numeroIdentificacion){
        this.numeroIdentificacion = numeroIdentificacion; // Actualiza el número de identificación
    }

    /**
     * Obtiene el RUT del cliente.
     *
     * @return El RUT.
     */
    public String getRut(){
        return rut; // Retorna el RUT del cliente
    }

    /**
     * Establece el RUT del cliente.
     *
     * @param rut El nuevo RUT.
     */
    public void setRut(String rut){
        this.rut = rut; // Actualiza el RUT
    }
}
