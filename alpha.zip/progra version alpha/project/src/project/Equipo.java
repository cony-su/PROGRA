package project;

/**
 * La clase Equipo representa un dispositivo de telecomunicaciones,
 * incluyendo su marca, modelo y número de serie.
 */
class Equipo
{
    private String marca; // Almacena la marca del equipo
    private String modelo; // Almacena el modelo del equipo
    private String numeroSerie; // Almacena el número de serie del equipo

    /**
     * Constructor de la clase Equipo que inicializa los atributos.
     *
     * @param marca La marca del equipo.
     * @param modelo El modelo del equipo.
     * @param numeroSerie El número de serie del equipo.
     */
    public Equipo(String marca, String modelo, String numeroSerie)
    {
        this.marca = marca; // Inicializa la marca del equipo
        this.modelo = modelo; // Inicializa el modelo del equipo
        this.numeroSerie = numeroSerie; // Inicializa el número de serie del equipo
    }

    // SETTERS Y GETTERS

    /**
     * Obtiene la marca del equipo.
     *
     * @return La marca del equipo.
     */
    public String getMarca() {
        return marca; // Retorna la marca del equipo
    }

    /**
     * Establece la marca del equipo.
     *
     * @param marca La nueva marca del equipo.
     */
    public void setMarca(String marca){
        this.marca = marca; // Actualiza la marca del equipo
    }

    /**
     * Obtiene el modelo del equipo.
     *
     * @return El modelo del equipo.
     */
    public String getModelo() {
        return modelo; // Retorna el modelo del equipo
    }

    /**
     * Establece el modelo del equipo.
     *
     * @param modelo El nuevo modelo del equipo.
     */
    public void setModelo(String modelo){
        this.modelo = modelo; // Actualiza el modelo del equipo
    }

    /**
     * Obtiene el número de serie del equipo.
     *
     * @return El número de serie del equipo.
     */
    public String getNumeroSerie() {
        return numeroSerie; // Retorna el número de serie del equipo
    }

    /**
     * Establece el número de serie del equipo.
     *
     * @param numeroSerie El nuevo número de serie del equipo.
     */
    public void setNumeroSerie(String numeroSerie){
        this.numeroSerie = numeroSerie; // Actualiza el número de serie del equipo
    }
}
