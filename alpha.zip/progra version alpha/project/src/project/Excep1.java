package project;

/**
 * La clase Excep1 representa una excepción personalizada que se utiliza para validar entradas
 * como nombres, apellidos y correos electrónicos. Extiende la clase Exception.
 */
public class Excep1 extends Exception
{
    /**
     * Constructor de la clase Excep1 que recibe un mensaje de error.
     *
     * @param msg El mensaje de error que se mostrará al lanzar la excepción.
     */
    public Excep1(String msg)
    {
        super(msg); // Llama al constructor de la clase padre (Exception)
    }
    
    /**
     * Valida que el nombre y apellido proporcionados cumplan con un formato específico.
     * El formato esperado es: la primera letra de cada nombre debe ser mayúscula, seguido de letras minúsculas.
     * 
     * @param n El nombre completo a validar (nombre y apellido separados por un espacio).
     * @throws Excep1 Si el nombre o apellido no cumplen con el formato especificado.
     */
    public void validarNombre(String n) throws Excep1
    {
        if (!n.matches("^[A-Z][a-z]* [A-Z][a-z]*$")) // Verifica el formato de nombre
        {
            throw new Excep1("El nombre o el apellido no son válidos");
        }
    }
    
    /**
     * Valida que el correo electrónico proporcionado tenga un formato válido.
     * Actualmente, acepta cualquier dominio, no solo Gmail.
     * 
     * @param g El correo electrónico a validar.
     * @throws Excep1 Si el correo electrónico no cumple con el formato especificado.
     */
    public void validarMail(String g) throws Excep1
    {
        if (!g.matches("^[\\w\\d.%+-]+@[\\w\\d]*\\.+[\\w]{2,6}")) // Verifica el formato del correo electrónico
        {
            throw new Excep1("El correo no es válido");
        }
    }
}
