package project;

/**
 * La clase Excep2 representa una excepción personalizada que se utiliza para validar diferentes entradas
 * relacionadas con datos personales y financieros, como números, teléfonos y fechas.
 */
public class Excep2 extends Exception {
    
    /**
     * Constructor de la clase Excep2 que recibe un mensaje de error.
     *
     * @param msg El mensaje de error que se mostrará al lanzar la excepción.
     */
    public Excep2(String msg) {
        super(msg); // Llama al constructor de la clase padre (Exception)
    }
    
    /**
     * Valida que el valor ingresado sea numérico.
     *
     * @param n El valor a validar.
     * @throws Excep2 Si el valor ingresado no es numérico.
     */
    public void validarN(String n) throws Excep2 {
        if (!n.matches("\\d*")) // Verifica que solo contenga dígitos
            throw new Excep2("El valor ingresado no es numérico, por favor ingrese un valor válido");
    }
    
    /**
     * Valida que el número de teléfono ingresado cumpla con el formato esperado.
     * El formato esperado es: "+569 XXXX XXXX".
     *
     * @param t El número de teléfono a validar.
     * @throws Excep2 Si el número de teléfono no es válido.
     */
    public void validarTelefono(String t) throws Excep2 {
        if (!t.matches("^\\+569 [0-9]{4} [0-9]{4}$")) // Verifica el formato del teléfono
            throw new Excep2("El número telefónico no es válido");
    }
    
    /**
     * Valida que la fecha de nacimiento ingresada cumpla con el formato esperado.
     * El formato esperado es: "DD/MM/YYYY", donde el año debe estar entre 1900 y 2024.
     *
     * @param fn La fecha de nacimiento a validar.
     * @throws Excep2 Si la fecha de nacimiento no es válida.
     */
    public void validarFechaNacimiento(String fn) throws Excep2 {
        if (!fn.matches("^(0[1-9]|[12][0-9]|3[01])/(1[0-2]|0[1-9])/(19[0-9][0-9]|20[01][0-9]|202[0-4])$")) // Verifica el formato de la fecha
            throw new Excep2("La fecha de nacimiento no es válida");
    }
    
    /**
     * Valida que el número de la tarjeta de crédito ingresado cumpla con el formato esperado.
     * El formato esperado es: "XXXX XXXX XXXX XXXX".
     *
     * @param tar El número de la tarjeta a validar.
     * @throws Excep2 Si el número de la tarjeta no es válido.
     */
    public void validarTarjeta(String tar) throws Excep2 {
        if (!tar.matches("\\d{4} \\d{4} \\d{4} \\d{4}")) // Verifica el formato del número de la tarjeta
            throw new Excep2("El número de la tarjeta no es válido");
    }
    
    /**
     * Valida que el código de seguridad de la tarjeta ingresado sea válido.
     * El formato esperado es un número de 3 dígitos.
     *
     * @param cr El código de seguridad a validar.
     * @throws Excep2 Si el código de seguridad no es válido.
     */
    public void validarCodigoSeguridad(String cr) throws Excep2 {
        if (!cr.matches("\\d{3}")) // Verifica que el código tenga 3 dígitos
            throw new Excep2("El número del reverso de su tarjeta no es válido");
    }
    
    /**
     * Valida que la fecha de vencimiento de la tarjeta ingresada cumpla con el formato esperado.
     * El formato esperado es: "MM/YY", donde MM es el mes y YY es el año.
     *
     * @param fv La fecha de vencimiento a validar.
     * @throws Excep2 Si la fecha de vencimiento no es válida o ha caducado.
     */
    public void validarFechaVencimiento(String fv) throws Excep2 {
        if (!fv.matches("^(0[1-9]|1[0-2])/(2[4-9]|[3-9][0-9])$")) // Verifica el formato de la fecha de vencimiento
            throw new Excep2("La fecha de caducidad de su tarjeta no es válida o ha caducado");
    }
    
    /**
     * Valida que el RUT ingresado cumpla con el formato esperado.
     * El formato esperado es: "XX.XXX.XXX-K", donde K puede ser un número o 'K'.
     *
     * @param r El RUT a validar.
     * @throws Excep2 Si el RUT ingresado no es válido.
     */
    public void validarRut(String r) throws Excep2 {
        if (!r.matches("^([1-9]|[12][0-9])\\.\\d{3}\\.\\d{3}-([k]|[K]|[0-9])$")) // Verifica el formato del RUT
            throw new Excep2("El RUT ingresado no es válido");
    }
}
