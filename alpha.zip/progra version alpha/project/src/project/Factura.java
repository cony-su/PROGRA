package project;

/**
 * La clase Factura representa una factura individual en el sistema.
 * Cada factura tiene un identificador único, un monto, una fecha de emisión 
 * y un estado de pago que indica si ha sido pagada o no.
 */
class Factura {
    private String idFactura; // Identificador único de la factura
    private double monto; // Monto total de la factura
    private String fechaEmision; // Fecha de emisión de la factura
    private boolean pagado; // Estado de pago de la factura

    /**
     * Constructor de la clase Factura.
     *
     * @param idFactura   El identificador único de la factura.
     * @param monto       El monto total de la factura.
     * @param fechaEmision La fecha en que se emitió la factura.
     * @param pagado      Indica si la factura ha sido pagada o no.
     */
    public Factura(String idFactura, double monto, String fechaEmision, boolean pagado) {
        this.idFactura = idFactura;
        this.monto = monto;
        this.fechaEmision = fechaEmision;
        this.pagado = pagado;
    }

    // Setters y Getters
    public String getIdFactura() {
        return idFactura; // Retorna el ID de la factura
    }

    public void setIdFactura(String idFactura) {
        this.idFactura = idFactura; // Establece el ID de la factura
    }

    public double getMonto() {
        return monto; // Retorna el monto de la factura
    }

    public void setMonto(double monto) {
        this.monto = monto; // Establece el monto de la factura
    }

    public String getFechaEmision() {
        return fechaEmision; // Retorna la fecha de emisión de la factura
    }

    public void setFechaEmision(String fechaEmision) {
        this.fechaEmision = fechaEmision; // Establece la fecha de emisión de la factura
    }

    public boolean getPagado() {
        return pagado; // Retorna el estado de pago de la factura
    }

    public void setPagado(boolean pagado) {
        this.pagado = pagado; // Establece el estado de pago de la factura
    }

    /**
     * Marca la factura como pagada si aún no ha sido pagada.
     *
     * @return true si la factura fue pagada exitosamente, false si ya estaba pagada.
     */
    public boolean pagarFactura() {
        if (pagado) return false; // Retorna false si la factura ya estaba pagada
        this.pagado = true; // Marca la factura como pagada
        return true; // Retorna true indicando que el pago fue exitoso
    }

    @Override
    public String toString() {
        // Retorna una representación en forma de cadena de la factura
        return "ID: " + idFactura +
               ", Monto: $" + monto +
               ", Fecha: " + fechaEmision +
               ", Pagado: " + (pagado ? "Sí" : "No");
    }
}
