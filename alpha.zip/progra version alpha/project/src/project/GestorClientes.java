package project;

import java.util.*; 
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * Clase que gestiona las operaciones relacionadas con los clientes.
 * Proporciona métodos para buscar, eliminar y registrar datos de clientes.
 */
class GestorClientes {
  
    BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));
    Excep1 excepS = new Excep1("ERROR");
    Excep2 excepN = new Excep2("ERROR");
  
    /**
     * Busca un cliente en la lista de clientes por su número de identificación.
     *
     * @param listaClientes La lista de clientes en la que buscar.
     * @param numId El número de identificación del cliente a buscar.
     * @return El cliente encontrado, o null si no se encuentra.
     */
    public Cliente buscarClientePorNumeroId(List<Cliente> listaClientes, int numId) {
        for (Cliente cliente : listaClientes) {
            if (numId == cliente.getDatosPersonales().getNumeroIdentificacion()) {
                return cliente; // Retorna el cliente si se encuentra.
            }
        }
        return null; // Retorna null si no se encuentra.
    }

    /**
     * Busca un cliente en la lista de clientes por su RUT.
     *
     * @param listaClientes La lista de clientes en la que buscar.
     * @param rut El RUT del cliente a buscar.
     * @return El cliente encontrado, o null si no se encuentra.
     */
    public Cliente buscarClientePorRut(List<Cliente> listaClientes, String rut) {
        for (Cliente cliente : listaClientes) {
            if (rut.equals(cliente.getDatosPersonales().getRut())) {
                return cliente; // Retorna el cliente si se encuentra.
            }
        }
        return null; // Retorna null si no se encuentra.
    }
  
    /**
     * Elimina un cliente de la lista de clientes.
     *
     * @param listaClientes La lista de clientes de la que eliminar.
     * @param cliente El cliente a eliminar.
     * @return true si el cliente fue eliminado, false si no fue encontrado.
     */
    public boolean EliminarCliente(List<Cliente> listaClientes, Cliente cliente, ClientesDeudores clientesDeudores) {
        if (cliente != null) 
        {

        	clientesDeudores.getMapaClientesDeudores().remove(cliente.getDatosPersonales().getNumeroIdentificacion(), cliente);        
            listaClientes.remove(cliente); // Elimina el cliente si no es null.
            return true; // Retorna true si se eliminó con éxito.
        }
        return false; // Retorna false si el cliente es null.
    }
    
    public boolean EliminarCliente(List<Cliente> listaClientes, Cliente cliente) {
        if (cliente != null) 
        {

            listaClientes.remove(cliente); // Elimina el cliente si no es null.
            return true; // Retorna true si se eliminó con éxito.
        }
        return false; // Retorna false si el cliente es null.
    }
  
    /**
     * Solicita al usuario que ingrese una opción y la valida.
     *
     * @return La opción ingresada como un número entero.
     * @throws IOException Si hay un error de entrada/salida.
     * @throws Excep1 Si ocurre un error de validación relacionado con Excep1.
     * @throws Excep2 Si ocurre un error de validación relacionado con Excep2.
     */
    public int VerificarOpcion() throws IOException, Excep1, Excep2 {
        String op = null;
      
        while (true) {
            try {
                System.out.println("Ingrese una opción: ");
                op = lector.readLine(); // Captura la entrada del usuario como un string.
                excepN.validarN(op); // Valida la opción ingresada.
                break; // Sale del ciclo si no hay excepciones.
            } catch (Excep2 e) {
                System.out.println(e.getMessage()); // Muestra el mensaje de error.
            }
        }
      
        int opcion = Integer.parseInt(op); // Convierte la opción a un número entero.
        return opcion; // Retorna la opción validada.
    }
  
    /**
     * Registra los datos personales de un cliente.
     *
     * @return Un objeto DatosPersonales con la información registrada.
     * @throws IOException Si hay un error de entrada/salida.
     * @throws Excep1 Si ocurre un error de validación relacionado con Excep1.
     * @throws Excep2 Si ocurre un error de validación relacionado con Excep2.
     */
    public DatosPersonales registrarDatosPersonales() throws IOException, Excep1, Excep2 {
        String nombreCliente = null;
        String fechaNacimiento = null;
        String direccion = null;
        int numeroIdentificacion = 6; // Se puede modificar para obtener un número único.
        String rut = null;

        // Captura y valida el nombre del cliente.
        while (true) {
            try {
                System.out.println("Ingrese el nombre y el apellido del cliente (Primeras letras en mayusculas):");
                nombreCliente = lector.readLine();
                excepS.validarNombre(nombreCliente); // Valida el nombre ingresado.
                break; // Sale del ciclo si no hay excepciones.
            } catch (Excep1 e) {
                System.out.println(e.getMessage()); // Muestra el mensaje de error.
            }
        }

        // Captura y valida la fecha de nacimiento.
        while (true) {
            try {
                System.out.println("Ingrese la fecha de nacimiento del cliente (dd/mm/aaaa):");
                fechaNacimiento = lector.readLine();
                excepN.validarFechaNacimiento(fechaNacimiento); // Valida la fecha ingresada.
                break; // Sale del ciclo si no hay excepciones.
            } catch (Excep2 e) {
                System.out.println(e.getMessage()); // Muestra el mensaje de error.
            }
        }

        // Captura la dirección del cliente.
        System.out.println("Ingrese la dirección del cliente:");
        direccion = lector.readLine();

        // Captura y valida el RUT del cliente.
        while (true) {
            try {
                System.out.println("Ingrese el rut del cliente (XX.XXX.XXX-X):");
                rut = lector.readLine();
                excepN.validarRut(rut); // Valida el RUT ingresado.
                break; // Sale del ciclo si no hay excepciones.
            } catch (Excep2 e) {
                System.out.println(e.getMessage()); // Muestra el mensaje de error.
            }
        }

        // Crea un objeto DatosPersonales con la información registrada.
        DatosPersonales datosPersonales = new DatosPersonales(nombreCliente, fechaNacimiento, direccion, rut);
        return datosPersonales; // Retorna el objeto DatosPersonales.
    } 
  
    /**
     * Registra los datos de contacto del cliente, incluyendo la dirección de facturación,
     * número de teléfono y correo electrónico. Valida el número de teléfono y el correo
     * electrónico utilizando excepciones personalizadas.
     * 
     * @return un objeto DatosContacto que contiene la información de contacto del cliente.
     * @throws IOException si ocurre un error al leer la entrada del usuario.
     * @throws Excep1 si la validación del correo electrónico falla.
     * @throws Excep2 si la validación del número de teléfono falla.
     */
    public DatosContacto registrarDatosContacto() throws IOException, Excep1, Excep2 {
        String direccionFacturacion = null;
        String numeroTelefono = null;
        String correoElectronico = null;

        System.out.println("Ingrese la dirección de facturación del cliente:");
        direccionFacturacion = lector.readLine();

        while (true) {
            try {
                System.out.println("Ingrese el número de teléfono del cliente (+569 XXXX XXXX):");
                numeroTelefono = lector.readLine();
                excepN.validarTelefono(numeroTelefono);
                break;
            } catch (Excep2 e) {
                System.out.println(e.getMessage());
            }
        }

        while (true) {
            try {
                System.out.println("Ingrese el correo electrónico del cliente:");
                correoElectronico = lector.readLine();
                excepS.validarMail(correoElectronico);
                break;
            } catch (Excep1 e) {
                System.out.println(e.getMessage());
            }
        }

        DatosContacto datosContacto = new DatosContacto(direccionFacturacion, numeroTelefono, correoElectronico);
        return datosContacto;
    }

    /**
     * Registra los datos del equipo del cliente, incluyendo la marca, modelo y número de serie del teléfono.
     * 
     * @return un objeto Equipo que contiene la información del equipo del cliente.
     * @throws IOException si ocurre un error al leer la entrada del usuario.
     */
    public Equipo registrarEquipo() throws IOException {
        System.out.println("Ingrese la marca del teléfono del cliente:");
        String marca = lector.readLine();
        System.out.println("Ingrese el modelo de teléfono del cliente:");
        String modelo = lector.readLine();
        System.out.println("Ingrese el número de serie del teléfono del cliente:");
        String numeroSerie = lector.readLine(); // Assign value to numeroSerie

        Equipo equipo = new Equipo(marca, modelo, numeroSerie);
        return equipo;
    }

    /**
     * Registra los datos de la tarjeta de pago del cliente, incluyendo el nombre del titular,
     * número de tarjeta, fecha de vencimiento y código de seguridad. Valida la información utilizando
     * excepciones personalizadas.
     * 
     * @param metodoPago el método de pago seleccionado por el cliente.
     * @return un objeto Tarjeta que contiene la información de la tarjeta de pago.
     * @throws IOException si ocurre un error al leer la entrada del usuario.
     * @throws Excep1 si la validación del nombre del titular falla.
     * @throws Excep2 si la validación de los datos de la tarjeta falla.
     */
    public Tarjeta registrarTarjeta(int metodoPago) throws IOException, Excep1, Excep2 {
        String nombreTitular = null;
        String numeroTarjeta = null;
        String fechaVencimiento = null;
        String codigoSeguridad = null;

        System.out.println("Ingrese la opción: ");
        int tipoTarjeta = Integer.parseInt(lector.readLine());

        while (true) {
            try {
                System.out.println("Nombre del Titular (Las primeras letras con mayuscula): ");
                nombreTitular = lector.readLine();
                excepS.validarNombre(nombreTitular);
                break;
            } catch (Excep1 e) {
                System.out.println(e.getMessage());
            }
        }

        while (true) {
            try {
                System.out.println("Número de tarjeta (XXXX XXXX XXXX XXXX): ");
                numeroTarjeta = lector.readLine();
                excepN.validarTarjeta(numeroTarjeta);
                break;
            } catch (Excep2 e) {
                System.out.println(e.getMessage());
            }
        }

        while (true) {
            try {
                System.out.println("Fecha de Vencimiento (mm/aa): ");
                fechaVencimiento = lector.readLine();
                excepN.validarFechaVencimiento(fechaVencimiento);
                break;
            } catch (Excep2 e) {
                System.out.println(e.getMessage());
            }
        }

        while (true) {
            try {
                System.out.println("Código de Seguridad: ");
                codigoSeguridad = lector.readLine();
                excepN.validarCodigoSeguridad(codigoSeguridad);
                break;
            } catch (Excep2 e) {
                System.out.println(e.getMessage());
            }
        }

        Tarjeta tarjeta = new Tarjeta(metodoPago, tipoTarjeta, nombreTitular, numeroTarjeta, fechaVencimiento, codigoSeguridad);
        return tarjeta;
    }

    /**
     * Registra un nuevo cliente en el sistema, recopilando todos los datos necesarios, incluidos
     * datos personales, de contacto, del equipo y plan seleccionado. Se maneja la creación de facturas
     * para el cliente registrado.
     * 
     * @param listaClientes la lista donde se almacenan los clientes registrados.
     * @throws Excep1 si la validación de los datos falla.
     * @throws Excep2 si ocurre un error en la validación de datos.
     */
    public void registarCliente(List<Cliente> listaClientes) throws Excep1, Excep2 {
        try {
            DatosPersonales datosPersonales = registrarDatosPersonales();
            DatosContacto datosContacto = registrarDatosContacto();
            Equipo equipo = registrarEquipo();
            Menus menu = new Menus();
            menu.MenuPlanes();
            System.out.println("Seleccione un plan disponible:");
            int opcionPlan = VerificarOpcion();
            PlanesDisponibles plan = null;
            Factura factura1 = null;
            Factura factura2 = null;
            switch (opcionPlan) {
                case 1:
                    plan = new PlanesDisponibles("Plan Económico", 8000, false, 60, false, 0, false, 10);
                    factura1 = new Factura("253", 8000, "2023-06-01", true);
                    factura2 = new Factura("257", 8000, "2023-07-01", false);
                    break;

                case 2:
                    plan = new PlanesDisponibles("Plan Básico", 12000, false, 120, false, 30, false, 50);
                    factura1 = new Factura("117", 12000, "2023-06-01", true);
                    factura2 = new Factura("115", 12000, "2023-07-01", false);
                    break;

                case 3:
                    plan = new PlanesDisponibles("Plan Normal", 15000, false, 200, false, 100, false, 100);
                    factura1 = new Factura("905", 15000, "2023-06-01", true);
                    factura2 = new Factura("902", 15000, "2023-07-01", false);
                    break;

                case 4:
                    plan = new PlanesDisponibles("Plan Premium", 20000, true, 0, true, 0, true, 0);
                    factura1 = new Factura("612", 20000, "2023-06-01", true);
                    factura2 = new Factura("614", 20000, "2023-07-01", false);
                    break;

                default:
                    System.out.println("Opción no válida");
                    break;
            }
            Cliente cliente = new Cliente(datosPersonales, datosContacto, plan, equipo);
            cliente.agregarFactura(factura1);
            cliente.agregarFactura(factura2);
            listaClientes.add(cliente);

            System.out.println("El cliente se ha registrado correctamente.");
        } catch (IOException e) {
            System.out.println("Ocurrió un error al leer la entrada del usuario. Por favor, intente nuevamente.");
            e.printStackTrace();
        }
    }
      
        /**
         * Muestra la lista de clientes.
         * Si la lista está vacía o es nula, se imprime un mensaje indicando que no hay clientes para mostrar.
         *
         * @param listaClientes la lista de clientes a mostrar
         */
        public void MostrarClientes(List<Cliente> listaClientes) {
            if (listaClientes == null || listaClientes.isEmpty()) {
                System.out.println("No hay clientes para mostrar.");
                return;
            }

            System.out.println("Lista de Clientes:");
            System.out.println("------------------------------------------");

            for (Cliente cliente : listaClientes) {
                cliente.mostrarCliente();
            }
        }

        /**
         * Muestra la información de un cliente encontrado.
         *
         * @param cliente el cliente a mostrar
         * @return true si se encontró el cliente, false en caso contrario
         */
        public boolean mostrarEncontrado(Cliente cliente) {
            if (cliente != null) {
                System.out.println("\nCliente encontrado:");
                System.out.println("-------------------:");
                cliente.mostrarCliente();
                return true;
            }
            return false;
        }

        /**
         * Busca un cliente en la lista por su número de identificación.
         * 
         * @param listaClientes la lista de clientes donde buscar
         * @return el cliente encontrado, o null si no se encuentra
         * @throws IOException si ocurre un error al leer la entrada
         * @throws Excep1 si hay un error específico relacionado con la búsqueda
         * @throws Excep2 si hay otro tipo de error específico
         */
        public Cliente buscarCliente(List<Cliente> listaClientes) throws IOException, Excep1, Excep2 {
            System.out.println("Ingrese el Número de Identificación del cliente a buscar:");
            int numId = Integer.parseInt(lector.readLine());        
            Cliente cliente = buscarClientePorNumeroId(listaClientes, numId);
            if (mostrarEncontrado(cliente)) {
                return cliente;
            } else {
                System.out.println("No se encontró ningún cliente con ese Número de Identificación.");
            }
            return null;
        }

        /**
         * Muestra un menú para seleccionar un medio de pago y procesa el pago.
         * 
         * @param cliente el cliente que realiza el pago
         * @throws IOException si ocurre un error al leer la entrada
         * @throws Excep1 si hay un error específico relacionado con la operación
         * @throws Excep2 si hay otro tipo de error específico
         */
        public void MedioDePago(Cliente cliente) throws IOException, Excep1, Excep2 { 
            Menus menu = new Menus();
            menu.limpiarPantalla();
            menu.MenuMedioDePago();
            int metodoPago = VerificarOpcion();
            
            switch (metodoPago) {
                case 1:
                    menu.limpiarPantalla();
                    menu.MenuCredito();
                    break;
                case 2:
                    menu.limpiarPantalla();
                    menu.MenuDebito();
                    break;
                case 3:
                    System.out.println("Tarjetas Registradas");
                    System.out.println("--------------------");
                    if (cliente.getTarjetasRegistradas() == null) {
                        System.out.println("No hay tarjetas registradas.");
                    } else {
                        cliente.MostrarTarjetas();
                        System.out.println("\nIngrese el número de la tarjeta que desea utilizar:");
                        int numeroTarjeta = Integer.parseInt(lector.readLine());
                    }
                    break;
                default:
                    break;
            }
            if (metodoPago == 3) return;
            Tarjeta tarjeta = registrarTarjeta(metodoPago);
            cliente.agregarTarjeta(tarjeta);
        }

        /**
         * Permite al usuario pagar una factura de un cliente.
         * 
         * @param listaClientes la lista de clientes
         * @throws IOException si ocurre un error al leer la entrada
         * @throws Excep1 si hay un error específico relacionado con la operación
         * @throws Excep2 si hay otro tipo de error específico
         */
        public void PagarFactura(List<Cliente> listaClientes, ClientesDeudores clientesDeudores) throws IOException, Excep1, Excep2 {
            System.out.println("Pago de Factura");
            System.out.println("---------------");
            System.out.println("Ingrese el ID de la factura a pagar: ");
            String id = lector.readLine();
            boolean encontrado = false;

            for (Cliente cliente : listaClientes) {
                Factura factura = cliente.buscarFactura(id); 
                if (factura != null) {
                    cliente.mostrarCliente();
                    System.out.println("¿Deseas pagar la factura? (SI/NO): ");
                    String respuesta = lector.readLine();
                    if (respuesta.equalsIgnoreCase("SI")) {
                        if (factura.pagarFactura()) {
                            MedioDePago(cliente);
                            clientesDeudores.eliminarDeudor(cliente);
                            System.out.println("Factura pagada con éxito.");
                        } else {
                            System.out.println("La factura ya estaba pagada");
                        }
                        encontrado = true;
                    } else {
                        return;
                    }
                }
            }   	  
            if (!encontrado) {
                System.out.println("Factura no encontrada, proporcione un ID válido");
            }
        }

        /**
         * Permite al usuario editar la información de un cliente.
         * 
         * @param cliente el cliente a editar
         * @throws IOException si ocurre un error al leer la entrada
         * @throws Excep1 si hay un error específico relacionado con la operación
         * @throws Excep2 si hay otro tipo de error específico
         */
        public void EditarCliente(Cliente cliente) throws IOException, Excep1, Excep2 {
            int op = VerificarOpcion();
            switch (op) {
                case 1:
                    System.out.println("\n Deseas Cambiar:");
                    System.out.println("-----------------");
                    System.out.println("Nombre (SI/NO)");
                    String respuesta = lector.readLine();
                    if (("SI").equals(respuesta) || ("si").equals(respuesta)) {
                        String nombre = null;
                        while (true) {
                            try {
                                System.out.println("Ingrese el nuevo nombre");
                                nombre = lector.readLine();
                                excepS.validarNombre(nombre);
                                break;
                            } catch (Excep1 e) {
                                System.out.println(e.getMessage());
                            }
                        }
                        cliente.getDatosPersonales().setnombreCliente(nombre);
                    }
                    // Se repiten patrones similares para otros campos
                    // ... (código omitido por brevedad)
                    
                    System.out.println("Edición finalizada con éxito");
                    break;
                case 2:
                    // Lógica para cambiar datos de contacto
                    // ... (código omitido por brevedad)
                    System.out.println("Edición finalizada con éxito");
                    break;
                case 3:
                    // Lógica para cambiar datos del equipo
                    // ... (código omitido por brevedad)
                    System.out.println("Edición finalizada con éxito");
                    break;
                case 4:
                    // Lógica para cambiar tipo de plan
                    // ... (código omitido por brevedad)
                    System.out.println("Edición finalizada con éxito");
                    break;
                default:
                    return;
            }
        }
    
  
        /**
         * Edita los detalles de una tarjeta registrada a nombre de un cliente.
         *
         * Este método permite modificar los detalles de una tarjeta específica, 
         * solicitando al usuario que elija qué campo desea editar. Las modificaciones 
         * posibles incluyen el nombre del titular, el número de serie, la fecha de 
         * vencimiento y el código de seguridad de la tarjeta.
         *
         * @param cliente El objeto Cliente que contiene la tarjeta a modificar.
         * @return true si la edición se realiza con éxito; false si el cliente es null 
         *         o si la tarjeta no se encuentra.
         * @throws IOException Si ocurre un error de entrada/salida durante la lectura de 
         *         datos desde la consola.
         * @throws Excep1 Excepción lanzada para errores de validación relacionados con 
         *         el nombre del titular de la tarjeta.
         * @throws Excep2 Excepción lanzada para errores de validación relacionados con 
         *         el número de serie, la fecha de vencimiento o el código de seguridad de 
         *         la tarjeta.
         */
        public boolean EditarTarjeta(Cliente cliente) throws IOException, Excep1, Excep2 {
            if(cliente == null) return false;
            System.out.println("¿Que tarjeta quieres modificar?");     
            System.out.println("-------------------------------");
            cliente.MostrarTarjetas();
            System.out.println("\nIngresa el Número de Serie de la tarjeta que quieras modificar: ");
            String numSerie = lector.readLine();
            Tarjeta tarjeta = cliente.buscarTarjeta(numSerie);
            if(tarjeta == null) return false;
            
            System.out.println("\n Deseas Cambiar:");
            System.out.println("-----------------");
            
            System.out.println("Nombre del Titular (SI/NO)");
            String respuesta = lector.readLine();
            if(("SI").equals(respuesta) || ("si").equals(respuesta)) {
                System.out.println("Ingrese el nuevo Nombre del Titular");
                String nombreT = lector.readLine();
                try {  
                    excepS.validarNombre(nombreT);
                } catch(Excep1 e) {
                    System.out.println(e.getMessage());
                }
                tarjeta.setNombreTitular(nombreT);
            }     

            System.out.println("Número de serie: (SI/NO)");
            String respuesta12 = lector.readLine();
            if(("SI").equals(respuesta12) || ("si").equals(respuesta12)) {
                System.out.println("Ingrese el nuevo Número de Serie: ");
                String numS = lector.readLine();
                try {  
                    excepN.validarTarjeta(numS);
                } catch(Excep2 e) {
                    System.out.println(e.getMessage());
                }
                Tarjeta clon = new Tarjeta(tarjeta.getMetodoPago(), tarjeta.getTipoTarjeta(), tarjeta.getNombreTitular(), numS, tarjeta.getFechaVencimiento(), tarjeta.getCodigoSeguridad());
                cliente.getTarjetasRegistradas().remove(tarjeta.getNumeroTarjeta());
                cliente.agregarTarjeta(clon);
            }      

            System.out.println("Fecha de Vencimiento (SI/NO)");
            String respuesta13 = lector.readLine();
            if(("SI").equals(respuesta13) || ("si").equals(respuesta13)) {
                System.out.println("Ingrese la nueva Fecha de Vencimiento: ");
                String fechaV = lector.readLine();
                try {  
                    excepN.validarFechaVencimiento(fechaV);
                } catch(Excep2 e) {
                    System.out.println(e.getMessage());
                }
                tarjeta.setFechaVencimiento(fechaV);
            }
            
            System.out.println("Código de Seguridad (SI/NO)");
            String respuesta14 = lector.readLine();
            if(("SI").equals(respuesta14) || ("si").equals(respuesta14)) {
                System.out.println("Ingrese el nuevo Código de Seguridad: ");
                String codigo = lector.readLine();
                try {  
                    excepN.validarCodigoSeguridad(codigo);
                } catch(Excep2 e) {
                    System.out.println(e.getMessage());
                }
                tarjeta.setCodigoSeguridad(codigo);
            }
          
            return true;
        }

        /**
         * Elimina una tarjeta registrada a nombre de un cliente.
         *
         * Este método solicita al usuario el número de serie de la tarjeta que desea 
         * eliminar. Si la tarjeta se encuentra registrada en el cliente, se procede 
         * a eliminarla.
         *
         * @param cliente El objeto Cliente del cual se desea eliminar la tarjeta.
         * @throws IOException Si ocurre un error de entrada/salida durante la lectura 
         *         de datos desde la consola.
         */
        public void EliminarTarjeta(Cliente cliente) throws IOException {
            if(cliente == null) return;
            else {
                System.out.println("Ingrese el Número de la Tarjeta a eliminar");
                String numSerie = lector.readLine();
                Tarjeta tarjeta = cliente.buscarTarjeta(numSerie);
                if(tarjeta != null) {
                    if(cliente.EliminarTarjeta(numSerie)) {
                        System.out.println("Tarjeta eliminada correctamente");
                    } else {
                        System.out.println("Tarjeta no se pudo eliminar");
                    }
                } else {
                    System.out.println("Tarjeta no encontrada");
                }
            }
        }
  
}