package project;
import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import javax.swing.*;

public class Main 
{
  public static void main(String[] args) throws IOException, Excep1, Excep2
  {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    Excep1 excepS = new Excep1("ERROR");
    Excep2 excepN = new Excep2("ERROR");
    ArrayList<Cliente> listaClientes = new ArrayList<Cliente>(); //COLECCIÓN PRINCIPAL
    ClientesRegistrados clientesRegistrados = new ClientesRegistrados();
    ClientesDeudores clientesDeudores = new ClientesDeudores();
    CSVDatos csvDatos = new CSVDatos(); 
 

    Cliente cliente1 = clientesRegistrados.ClienteRegistrado1();
    Cliente cliente2 = clientesRegistrados.ClienteRegistrado2();
    Cliente cliente3 = clientesRegistrados.ClienteRegistrado3();
    Cliente cliente4 = clientesRegistrados.ClienteRegistrado4();
    listaClientes.add(cliente1);
    listaClientes.add(cliente2);
    listaClientes.add(cliente3);
    listaClientes.add(cliente4);
    
    clientesDeudores.llenarMapa(listaClientes); 
    csvDatos.leerClientes(listaClientes);
    csvDatos.leerFacturas(listaClientes);
    csvDatos.leerTarjetas(listaClientes); 
     
    SwingUtilities.invokeLater(() -> {
        Ventana ventanaPrincipal = new Ventana(listaClientes, clientesDeudores); // Pasar la lista de clientes aquí
        ventanaPrincipal.setVisible(true); // Hacer visible la ventana
    });
    
    
    GestorClientes gestorClientes = new GestorClientes();
    Menus menu = new Menus();
    
    while(true)
    {
      menu.MenuPrincipal();
      
      int opcion = gestorClientes.VerificarOpcion();
      
      switch(opcion) 
      {
        case 1:
          menu.limpiarPantalla();
          menu.MenuClientes();
          int opcion1 = gestorClientes.VerificarOpcion();
          
          switch(opcion1)
          {
             case 1:
            	 menu.limpiarPantalla();
                 gestorClientes.MostrarClientes(listaClientes);
                 System.out.println("\nDigite una letra para salir: ");
                 String op = reader.readLine();
            	 break;
             case 2:
            	 menu.limpiarPantalla();
            	 try
            	 {
            		 gestorClientes.registarCliente(listaClientes); 
            	 }catch(Excep1 e)
              	  {
              		  System.out.println(e.getMessage());
              	  }catch(Excep2 e)
              	  {
              		  System.out.println(e.getMessage());
              	  }
            	 
            	 System.out.println("\nDigite una letra para salir: ");
                 String op2 = reader.readLine();
            	 break;
             case 3:
            	 menu.limpiarPantalla();
                 gestorClientes.buscarCliente(listaClientes);
                 System.out.println("\nDigite una letra para salir: ");
                 String op3 = reader.readLine();                                 
            	 break;
             case 4:
            	 menu.limpiarPantalla();
                 Cliente cliente = gestorClientes.buscarCliente(listaClientes);
                 if(cliente != null) 
                 {
               	  menu.MenuEditarCliente();
               	  try
               	  {
               		  gestorClientes.EditarCliente(cliente);
               	  }catch(Excep1 e)
               	  {
               		  System.out.println(e.getMessage());
               	  }catch(Excep2 e)
               	  {
               		  System.out.println(e.getMessage());
               	  }
               	  
                 }
                 else System.out.println("\nIntente de nuevo");
                 System.out.println("\nDigite una letra para salir: ");
                 String op4 = reader.readLine();
            	 break;
             case 5:
            	 menu.limpiarPantalla();
                 Cliente c = gestorClientes.buscarCliente(listaClientes);
               	  if(gestorClientes.EliminarCliente(listaClientes, c, clientesDeudores)) 
               		  
               		  System.out.println("\nEliminación existosa");
               		
                 else System.out.println("\nIntente de nuevo");
                 System.out.println("\nDigite una letra para salir: ");
                 String op5 = reader.readLine();
                 break;
             case 6:
            	 menu.limpiarPantalla();
                 Cliente clienteReporte = gestorClientes.buscarCliente(listaClientes);
                 if(clienteReporte != null) 
                 {
                	 Reportes RI = new Reportes();
                	 RI.Reporte(clienteReporte);
                     System.out.println("\nReporte generado correctamente");
                	 
                 }
                 else System.out.println("\nCliente no encontrado");
                 System.out.println("\nDigite una letra para salir: ");
                 String op6 = reader.readLine();
            	 break;
             case 7:
            	 System.out.println("Lista de clientes deudores");
            	 System.out.println("--------------------------");
            	 if(clientesDeudores.mostrarClientesDeudores() == false) System.out.println("\nNo hay clientes deudores");
                 System.out.println("\nDigite una letra para salir: "); 
                 String op7 = reader.readLine();
            	 break;
             default:
            	 break;
          }
          break;
        case 2:
          menu.limpiarPantalla();
          menu.MenuTarjeta();
          int opcion2 = gestorClientes.VerificarOpcion();
          switch(opcion2)
          {
            case 1:
                Cliente c2 = gestorClientes.buscarCliente(listaClientes);
                if(c2 != null) c2.MostrarTarjetas();
            	System.out.println("\nDigite una letra para salir: ");
                String op = reader.readLine();
            	break;
            case 2:
                Cliente c3 = gestorClientes.buscarCliente(listaClientes);
                c3.MostrarTarjetas();
                gestorClientes.EliminarTarjeta(c3); 
            	System.out.println("\nDigite una letra para salir: ");
            	String op2 = reader.readLine(); 
            	break;
            case 3:
                Cliente c4 = gestorClientes.buscarCliente(listaClientes);
                if(c4 != null)
                {
                	if(gestorClientes.EditarTarjeta(c4)) System.out.println("Tarjeta editada correctamente");
                	else System.out.println("\nTarjeta no encontrada");
                }
                else System.out.println("\nCliente no encontrado");
                System.out.println("\nDigite una letra para salir: ");
            	String op3 = reader.readLine(); 
            default:
            	break;
          }
          break;
        case 3:
        	menu.limpiarPantalla(); 
            menu.PlanEconomico();
            menu.PlanBasico();
            menu.PlanNormal();
            menu.PlanPremium();
            System.out.println("\nDigite una letra para salir ");
            String op8 = reader.readLine();
            break;
        case 4:
        	menu.limpiarPantalla();
        	try
        	{
        		gestorClientes.PagarFactura(listaClientes, clientesDeudores);
        	}catch(Excep1 e)
        	{
        		System.out.println(e.getMessage());
        	}catch(Excep2 e)
        	{
        		System.out.println(e.getMessage());
        	}
        	
            System.out.println("\nDigite una letra para salir ");
            String op9 = reader.readLine();
            break;
        case 5:
        	Reportes reporte = new Reportes();
        	reporte.Reporte(listaClientes);
        	System.out.println("\nDigite una letra para salir ");
            String op10 = reader.readLine();
        	break;
        case 6:
        	CSVDatos csv = new CSVDatos();
        	csv.registrarClienteCSV(listaClientes); // Guarda los cambios antes de salir
        	csv.registrarFacturasCSV(listaClientes);
        	csv.registrarTarjetasCSV(listaClientes);
            System.out.println("\nDigite una letra ");
            String op11 = reader.readLine(); 
        	break;
        default:
          System.out.println("Opción no válida");
          break;
      }   
      menu.limpiarPantalla();
    }   
  }
}

