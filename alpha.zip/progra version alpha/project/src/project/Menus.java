package project;

import java.io.IOException;

/**
 * Clase Menus que maneja la interfaz de usuario en consola 
 * del sistema de telefonía celular, proporcionando varios 
 * menús y submenús para la interacción con el usuario.
 */
class Menus {

    /**
     * Muestra el menú principal de la aplicación.
     */
    public void MenuPrincipal() {
        System.out.println("Bienvenido al Sistema de Telefonía Celular");
        System.out.println("------------------------------------------");
        System.out.println("1. Mostrar SubMenú de Cliente");
        System.out.println("2. Mostrar SubMenú de Tarjeta");
        System.out.println("3. Mostrar Planes Disponibles");
        System.out.println("4. Pagar Factura ");
        System.out.println("5. Generar Reporte General ");
        System.out.println("6. Salir \n");
    }

    /**
     * Muestra el submenú de clientes.
     */
    public void MenuClientes() {
        System.out.println("SubMenú de Clientes");
        System.out.println("-------------------");
        System.out.println("1. Mostrar Clientes");
        System.out.println("2. Registrar Cliente");
        System.out.println("3. Buscar Cliente");
        System.out.println("4. Editar Cliente");
        System.out.println("5. Eliminar Cliente");
        System.out.println("6. Generar Reporte Individual");
        System.out.println("7. Mostrar Clientes Deudores");
        System.out.println("8. Salir \n");
    }

    /**
     * Muestra el submenú de tarjetas.
     */
    public void MenuTarjeta() {
        System.out.println("SubMenú de Tarjetas");
        System.out.println("-------------------");
        System.out.println("1. Mostrar Tarjetas Asociadas ");
        System.out.println("2. Eliminar Tarjeta Asociada");
        System.out.println("3. Editar Tarjeta Asociada");
        System.out.println("4. Salir \n");
    }

    /**
     * Limpia la pantalla de la consola según el sistema operativo.
     */
    public void limpiarPantalla() {
        String sistemaOperativo = System.getProperty("os.name").toLowerCase();
        try {
            if (sistemaOperativo.contains("win")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                new ProcessBuilder("clear").inheritIO().start().waitFor();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Muestra el menú para seleccionar un plan.
     */
    public void MenuPlanes() {
        System.out.println("\n¿Que plan desea registrar?");
        System.out.println("-------------------------");
        System.out.println("1. Plan Económico");
        System.out.println("2. Plan Básico");
        System.out.println("3. Plan Normal");
        System.out.println("4. Plan Premium \n");
    }

    /**
     * Muestra la información del Plan Económico.
     */
    public void PlanEconomico() {
        System.out.println("Plan Económico");
        System.out.println("--------------");
        System.out.println("- Llamadas nacionales: 60 minutos");
        System.out.println("- Llamadas internaciones: 0 minutos");
        System.out.println("- Datos móviles: 10 GB");
        System.out.println("Precio: $8000\n");
    }

    /**
     * Muestra la información del Plan Básico.
     */
    public void PlanBasico() {
        System.out.println("Plan Básico");
        System.out.println("-----------");
        System.out.println("- Llamadas nacionales: 120 minutos");
        System.out.println("- Llamadas internaciones: 30 minutos");
        System.out.println("- Datos móviles: 50 GB");
        System.out.println("Precio: $12000\n");
    }

    /**
     * Muestra la información del Plan Normal.
     */
    public void PlanNormal() {
        System.out.println("Plan Normal");
        System.out.println("--------------");
        System.out.println("- Llamadas nacionales: 200 minutos");
        System.out.println("- Llamadas internaciones: 100 minutos");
        System.out.println("- Datos móviles: 100 GB");
        System.out.println("Precio: $15000\n");
    }

    /**
     * Muestra la información del Plan Premium.
     */
    public void PlanPremium() {
        System.out.println("Plan Premium");
        System.out.println("------------");
        System.out.println("- Llamadas nacionales: minutos ilimitados");
        System.out.println("- Llamadas internaciones: minutos ilimitados");
        System.out.println("- Datos móviles: GB ilimitados");
        System.out.println("Precio: $20000\n");
    }



    /**
     * Muestra las opciones de métodos de pago.
     */
    public void MenuMedioDePago() {
        System.out.println("¿Con que método desea pagar?");
        System.out.println("------------------");
        System.out.println("1. Tarjeta de crédito");
        System.out.println("2. Tarjeta de débito");
        System.out.println("3. Tarjeta previamente registrada");
    }

    /**
     * Muestra las opciones de tipos de tarjeta de crédito.
     */
    public void MenuCredito() {
        System.out.println("¿Con que tipo de tarjeta desea pagar?");
        System.out.println("-------------------------------------");
        System.out.println("1. Visa");
        System.out.println("2. MasterCard");
        System.out.println("3. American Express");
        System.out.println("4. Diners Club");
    }

    /**
     * Muestra las opciones de tipos de tarjeta de débito.
     */
    public void MenuDebito() {
        System.out.println("¿Con que tipo de tarjeta desea pagar?");
        System.out.println("-------------------------------------");
        System.out.println("1. Visa Débito");
        System.out.println("2. MasterCard Débito");
        System.out.println("3. Redcompra");
        System.out.println("4. Bank Red");
    }

    /**
     * Muestra las opciones para editar la información del cliente.
     */
    public void MenuEditarCliente() {
        System.out.println("¿Que información desea desea editar?");
        System.out.println("------------------------------------");
        System.out.println("1. Datos personales del cliente");
        System.out.println("2. Datos de contacto del cliente");
        System.out.println("3. Equipo del cliente");
        System.out.println("4. Tipo de plan del cliente");
    }
}
