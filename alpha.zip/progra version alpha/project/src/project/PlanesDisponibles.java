package project;

import java.util.Map;

/**
 * La clase PlanesDisponibles representa los diferentes planes de telefonía disponibles.
 * Cada plan incluye detalles como nombre, precio, límites de llamadas y datos.
 */
class PlanesDisponibles {
    private String nombrePlan; // Nombre del plan
    private int precioPlan; // Precio del plan en la moneda correspondiente
    private Boolean llamadasNacionalesIlimitadas; // Indica si el plan tiene llamadas nacionales ilimitadas
    private int limiteLlamadasNacionales; // Límite de minutos de llamadas nacionales
    private Boolean llamadasInternacionalesIlimitadas; // Indica si el plan tiene llamadas internacionales ilimitadas
    private int limiteLlamadasInternacionales; // Límite de minutos de llamadas internacionales
    private Boolean datosIlimitados; // Indica si el plan incluye datos ilimitados
    private int limiteDatos; // Límite de datos en MB o GB
    private Map<String, PlanesDisponibles> planes; // Mapa para almacenar los planes disponibles

    /**
     * Constructor para crear un nuevo plan de telefonía.
     *
     * @param nombrePlan                      El nombre del plan.
     * @param precioPlan                      El precio del plan.
     * @param llamadasNacionalesIlimitadas    Indica si tiene llamadas nacionales ilimitadas.
     * @param limiteLlamadasNacionales        Límite de minutos para llamadas nacionales.
     * @param llamadasInternacionalesIlimitadas Indica si tiene llamadas internacionales ilimitadas.
     * @param limiteLlamadasInternacionales    Límite de minutos para llamadas internacionales.
     * @param datosIlimitados                 Indica si tiene datos ilimitados.
     * @param limiteDatos                     Límite de datos en MB o GB.
     */
    public PlanesDisponibles(String nombrePlan, int precioPlan, Boolean llamadasNacionalesIlimitadas,
                             int limiteLlamadasNacionales, Boolean llamadasInternacionalesIlimitadas,
                             int limiteLlamadasInternacionales, Boolean datosIlimitados, int limiteDatos) {
        this.nombrePlan = nombrePlan;
        this.precioPlan = precioPlan;
        this.llamadasNacionalesIlimitadas = llamadasNacionalesIlimitadas;
        this.limiteLlamadasNacionales = limiteLlamadasNacionales;
        this.llamadasInternacionalesIlimitadas = llamadasInternacionalesIlimitadas;
        this.limiteLlamadasInternacionales = limiteLlamadasInternacionales;
        this.datosIlimitados = datosIlimitados;
        this.limiteDatos = limiteDatos;
    }

    /**
     * Obtiene el mapa de planes disponibles.
     *
     * @return Un mapa de los planes disponibles.
     */
    public Map<String, PlanesDisponibles> getPlanes() {
        PlanesDisponibles plan1 = new PlanesDisponibles("Plan Económico", 8000, false, 60, false, 0, false, 10);
        PlanesDisponibles plan2 = new PlanesDisponibles("Plan Básico", 12000, false, 120, false, 30, false, 50);
        PlanesDisponibles plan3 = new PlanesDisponibles("Plan Normal", 15000, false, 200, false, 100, false, 100);
        PlanesDisponibles plan4 = new PlanesDisponibles("Plan Premium", 20000, true, 0, true, 0, true, 0);

        // Se añaden los planes al mapa
        planes.put(plan1.getNombrePlan(), plan1);
        planes.put(plan2.getNombrePlan(), plan2);
        planes.put(plan3.getNombrePlan(), plan3);
        planes.put(plan4.getNombrePlan(), plan4);

        return planes;
    }

    /**
     * Busca y devuelve un plan según la clave proporcionada.
     *
     * @param clave Clave del plan a buscar.
     * @return El plan buscado, o null si no se encuentra.
     */
    public PlanesDisponibles getPlanes(String clave) {
        PlanesDisponibles plan1 = new PlanesDisponibles("Plan Económico", 8000, false, 60, false, 0, false, 10);
        PlanesDisponibles plan2 = new PlanesDisponibles("Plan Básico", 12000, false, 120, false, 30, false, 50);
        PlanesDisponibles plan3 = new PlanesDisponibles("Plan Normal", 15000, false, 200, false, 100, false, 100);
        PlanesDisponibles plan4 = new PlanesDisponibles("Plan Premium", 20000, true, 0, true, 0, true, 0);

        // Se añaden los planes al mapa
        planes.put(plan1.getNombrePlan(), plan1);
        planes.put(plan2.getNombrePlan(), plan2);
        planes.put(plan3.getNombrePlan(), plan3);
        planes.put(plan4.getNombrePlan(), plan4);

        // Se busca el plan según la clave
        PlanesDisponibles planBuscado = planes.get(clave);
        return planBuscado; // Retorna el plan buscado
    }

    /**
     * Ingresa una opción y retorna el plan correspondiente.
     *
     * @param op Opción del plan a seleccionar.
     * @return El plan correspondiente a la opción.
     */
    public PlanesDisponibles ingresarYretornar(int op) {
        switch (op) {
            case 1:
                return new PlanesDisponibles("Plan Económico", 8000, false, 60, false, 0, false, 10);
            case 2:
                return new PlanesDisponibles("Plan Básico", 12000, false, 120, false, 30, false, 50);
            case 3:
                return new PlanesDisponibles("Plan Normal", 15000, false, 200, false, 100, false, 100);
            case 4:
                return new PlanesDisponibles("Plan Premium", 20000, true, 0, true, 0, true, 0);
            default:
                break; // Si no coincide, retorna null
        }
        return null;
    }

    // Métodos getter y setter para acceder y modificar los atributos

    public String getNombrePlan() {
        return nombrePlan;
    }

    public void setNombrePlan(String nombrePlan) {
        this.nombrePlan = nombrePlan;
    }

    public int getPrecioPlan() {
        return precioPlan;
    }

    public void setPrecioPlan(int precioPlan) {
        this.precioPlan = precioPlan;
    }

    public Boolean getLlamadasNacionalesIlimitadas() {
        return llamadasNacionalesIlimitadas;
    }

    public void setLlamadasNacionalesIlimitadas(Boolean llamadasNacionalesIlimitadas) {
        this.llamadasNacionalesIlimitadas = llamadasNacionalesIlimitadas;
    }

    public int getLimiteLlamadasNacionales() {
        return limiteLlamadasNacionales;
    }

    public void setLimiteLlamadasNacionales(int limiteLlamadasNacionales) {
        this.limiteLlamadasNacionales = limiteLlamadasNacionales;
    }

    public Boolean getLlamadasInternacionalesIlimitadas() {
        return llamadasInternacionalesIlimitadas;
    }

    public void setLlamadasInternacionalesIlimitadas(Boolean llamadasInternacionalesIlimitadas) {
        this.llamadasInternacionalesIlimitadas = llamadasInternacionalesIlimitadas;
    }

    public int getLimiteLlamadasInternacionales() {
        return limiteLlamadasInternacionales;
    }

    public void setLimiteLlamadasInternacionales(int limiteLlamadasInternacionales) {
        this.limiteLlamadasInternacionales = limiteLlamadasInternacionales;
    }

    public Boolean getDatosIlimitados() {
        return datosIlimitados;
    }

    public void setDatosIlimitados(Boolean datosIlimitados) {
        this.datosIlimitados = datosIlimitados;
    }

    public int getLimiteDatos() {
        return limiteDatos;
    }
}
