package project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

/**
 * Clase que representa una ventana para buscar clientes por su número de identificación.
 * Extiende de JFrame y proporciona una interfaz gráfica para ingresar un número de identificación
 * y visualizar los detalles del cliente correspondiente.
 */
public class VentanaBuscarCliente extends JFrame {
    private JTextField buscarField; // Campo de texto para ingresar el número de identificación
    private JButton buscarButton; // Botón para iniciar la búsqueda
    private JTextArea resultadosArea; // Área de texto para mostrar los resultados de la búsqueda
    private ArrayList<Cliente> listaClientes; // Lista de clientes para realizar la búsqueda
    private GestorClientes gestorClientes; // Gestor que maneja la búsqueda de clientes

    /**
     * Constructor de la clase VentanaBuscarCliente.
     * 
     * @param listaClientes Lista de clientes donde se realizará la búsqueda.
     */
    public VentanaBuscarCliente(ArrayList<Cliente> listaClientes) {
        this.listaClientes = listaClientes; // Inicializa la lista de clientes
        this.gestorClientes = new GestorClientes(); // Inicializa el gestor
        setTitle("Buscar Cliente"); // Título de la ventana
        setSize(500, 400); // Tamaño de la ventana
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cierra la ventana al terminar
        setLayout(new GridBagLayout()); // Establece el layout de la ventana
        GridBagConstraints gbc = new GridBagConstraints(); // Para gestionar el diseño de los componentes

        // Crear componentes
        buscarField = new JTextField(20); // Campo de texto para la búsqueda
        buscarButton = new JButton("Buscar"); // Botón de búsqueda
        resultadosArea = new JTextArea(10, 30); // Área de texto para resultados
        resultadosArea.setEditable(false); // El área de resultados no es editable
        JScrollPane scrollPane = new JScrollPane(resultadosArea); // Agrega scroll al área de texto

        // Configurar el botón de búsqueda
        buscarButton.addActionListener(this::buscarCliente); // Añade el listener al botón

        // Configurar la posición de los componentes
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        add(new JLabel("Número de Identificación:"), gbc); // Etiqueta

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        add(buscarField, gbc); // Campo de búsqueda

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        add(buscarButton, gbc); // Botón de búsqueda

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        add(scrollPane, gbc); // Área de resultados
    }

    /**
     * Método que busca un cliente por su número de identificación.
     * 
     * @param e Evento de acción que dispara la búsqueda.
     * @return Cliente encontrado o null si no se encuentra.
     */
    private Cliente buscarCliente(ActionEvent e) {
        String identificacionTexto = buscarField.getText().trim(); // Obtiene el texto del campo de búsqueda

        try {
            int identificacion = Integer.parseInt(identificacionTexto); // Convierte el texto a número
            Cliente cliente = gestorClientes.buscarClientePorNumeroId(listaClientes, identificacion); // Busca el cliente

            if (cliente != null) {
                mostrarCliente(cliente); // Mostrar cliente encontrado
                return cliente; // Retorna el cliente encontrado
            } else {
                resultadosArea.setText("Cliente no encontrado."); // Muestra mensaje si no se encuentra
                JOptionPane.showMessageDialog(this, "Cliente No Encontrado");
                return null; // Retorna null si no se encuentra el cliente
            }
        } catch (NumberFormatException ex) {
            resultadosArea.setText("Error: El número de identificación debe ser numérico."); // Manejo de errores
            return null; // Retorna null si el formato es incorrecto
        }
    }

    /**
     * Método para mostrar los detalles del cliente en el área de resultados.
     * 
     * @param cliente El cliente cuyos detalles se mostrarán.
     */
    private void mostrarCliente(Cliente cliente) {
        StringBuilder detallesCliente = new StringBuilder(); // StringBuilder para construir la información del cliente
        detallesCliente.append("Nombre: ").append(cliente.getDatosPersonales().getNombreCliente()).append("\n");
        detallesCliente.append("Número de Identificación: ").append(cliente.getDatosPersonales().getNumeroIdentificacion()).append("\n");
        detallesCliente.append("Dirección: ").append(cliente.getDatosPersonales().getDireccion()).append("\n");
        detallesCliente.append("Plan: ").append(cliente.getPlan().getNombrePlan()).append("\n");
        detallesCliente.append("Equipo: ").append(cliente.getEquipo().getMarca()).append(" ").append(cliente.getEquipo().getModelo()).append("\n");

        // Mostrar facturas
        if (cliente.getFacturas().isEmpty()) {
            detallesCliente.append("Facturas: No hay facturas registradas.\n"); // Mensaje si no hay facturas
        } else {
            detallesCliente.append("Facturas:\n");
            for (String idFactura : cliente.getFacturas().keySet()) {
                Factura factura = cliente.getFacturas().get(idFactura);
                detallesCliente.append("  - Factura ID: ").append(factura.getIdFactura())
                        .append(", Monto: $").append(factura.getMonto())
                        .append(", Fecha: ").append(factura.getFechaEmision())
                        .append(", Estado: ").append(factura.getPagado() ? "PAGADO" : "NO PAGADO").append("\n");
            }
        }

        resultadosArea.setText(detallesCliente.toString()); // Muestra la información del cliente en el área de resultados
    }
}
