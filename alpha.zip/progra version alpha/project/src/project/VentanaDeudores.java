package project;

import javax.swing.JOptionPane;
import java.awt.BorderLayout;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * Clase VentanaDeudores que representa una ventana gráfica para mostrar información sobre clientes deudores.
 * Esta clase extiende JFrame y utiliza JTable para mostrar los detalles de los clientes deudores.
 */
public class VentanaDeudores extends JFrame {
    private JTable table; // Tabla para mostrar los detalles de los clientes deudores
    private DefaultTableModel model; // Modelo de la tabla
    private ClientesDeudores clientesDeudores; // Mapa de clientes deudores

    /**
     * Constructor que inicializa la ventana para mostrar información de deudores.
     * 
     * @param clientesDeudores objeto que contiene los clientes deudores
     */
    public VentanaDeudores(ClientesDeudores clientesDeudores) {
        this.clientesDeudores = clientesDeudores; // Asignar el mapa de clientes deudores
        setTitle("Mostrar Información de Deudores"); // Título de la ventana
        setSize(500, 300); // Tamaño de la ventana
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cerrar la ventana al finalizar
        setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        
        // Crear el modelo de la tabla con las columnas necesarias
        model = new DefaultTableModel();
        model.addColumn("Nombre");
        model.addColumn("Teléfono");
        model.addColumn("RUT");
        model.addColumn("Correo");
        model.addColumn("Dirección");
        model.addColumn("Número de Identificación");
        model.addColumn("Tipo de Plan");
        model.addColumn("Equipo");
        model.addColumn("Facturas");
        
        table = new JTable(model); // Crear la tabla con el modelo
        add(new JScrollPane(table), BorderLayout.CENTER); // Agregar la tabla dentro de un JScrollPane

        // Botón para cerrar la ventana
        JButton botonCerrar = new JButton("Cerrar");
        botonCerrar.addActionListener(e -> dispose()); // Acción para cerrar la ventana
        add(botonCerrar, BorderLayout.SOUTH); // Agregar el botón en la parte inferior
    }

    /**
     * Método para mostrar los detalles de un cliente específico en la tabla.
     * 
     * @param cliente El cliente cuyas informaciones se van a mostrar.
     */
    public void mostrarCliente(Cliente cliente) {
        // Limpiar el modelo de la tabla
        model.setRowCount(0);
        
        // Agregar el cliente al modelo
        model.addRow(new Object[]{
            cliente.getDatosPersonales().getNombreCliente(),
            cliente.getDatosContacto().getTelefono(),
            cliente.getDatosPersonales().getRut(),
            cliente.getDatosContacto().getCorreo(),
            cliente.getDatosPersonales().getDireccion(),
            cliente.getDatosPersonales().getNumeroIdentificacion(),
            cliente.getPlan().getNombrePlan(),
            cliente.getEquipo().getMarca() + " " + cliente.getEquipo().getModelo(),
            facturasToString(cliente.getFacturas()) // Convertir las facturas a cadena
        });
    }

    /**
     * Método para mostrar todos los clientes deudores en la tabla.
     * Si no hay clientes deudores, muestra un mensaje de alerta.
     */
    public void mostrarClientesDeudores() {
        // Limpiar el modelo de la tabla
        model.setRowCount(0);
        if (clientesDeudores.getMapaClientesDeudores().isEmpty()) {
            // Mostrar un mensaje de alerta si no hay clientes deudores
            JOptionPane.showMessageDialog(this, "No hay clientes deudores.", "Alerta", JOptionPane.WARNING_MESSAGE);
            return; // Salir del método si el mapa está vacío
        }
        // Agregar los clientes deudores al modelo
        for (Map.Entry<Integer, Cliente> entry : clientesDeudores.getMapaClientesDeudores().entrySet()) {
            Cliente cliente = entry.getValue(); // Obtener el cliente deudor
            model.addRow(new Object[]{
                cliente.getDatosPersonales().getNombreCliente(),
                cliente.getDatosContacto().getTelefono(),
                cliente.getDatosPersonales().getRut(),
                cliente.getDatosContacto().getCorreo(),
                cliente.getDatosPersonales().getDireccion(),
                cliente.getDatosPersonales().getNumeroIdentificacion(),
                cliente.getPlan().getNombrePlan(),
                cliente.getEquipo().getMarca() + " " + cliente.getEquipo().getModelo(),
                facturasToString(cliente.getFacturas()) // Convertir las facturas a cadena
            });
        }
    }
    
    /**
     * Método para convertir el mapa de facturas a una cadena legible.
     * 
     * @param facturas Mapa de facturas que se van a convertir.
     * @return Cadena que representa las facturas.
     */
    private String facturasToString(Map<String, Factura> facturas) {
        StringBuilder builder = new StringBuilder();
        if (facturas.isEmpty()) {
            return "No hay facturas"; // Mensaje si no hay facturas
        }
        for (Map.Entry<String, Factura> entry : facturas.entrySet()) {
            Factura factura = entry.getValue();
            builder.append("- ").append(factura.toString()).append("\n"); // Precede con un guion
        }
        return builder.toString(); // Retornar la cadena construida
    }
}
