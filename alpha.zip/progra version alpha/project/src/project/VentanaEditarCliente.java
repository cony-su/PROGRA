package project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

/**
 * La clase VentanaEditarCliente extiende JDialog y permite editar la información de un cliente
 * existente a partir de su número de identificación. Utiliza una interfaz gráfica para
 * buscar y seleccionar el cliente, y luego proporciona varias opciones para editar
 * diferentes aspectos de la información del cliente.
 */
public class VentanaEditarCliente extends JDialog {
    // Componentes de la ventana
    private JTextField buscarField;
    private JButton buscarButton;
    private JTextArea resultadosArea;
    private JButton editarButton, cancelarButton;
    private JPanel panelPrincipal, panelBusqueda, panelEdicion, panelFormularioDatosContacto, panelFormularioDatosPersonales, panelFormularioEquipo, panelFormularioPlan;
    private ArrayList<Cliente> listaClientes;
    private GestorClientes gestorClientes; // Gestor que maneja la lógica relacionada con los clientes
    private Cliente clienteEncontrado; // Cliente que se obtiene al realizar la búsqueda
    private CardLayout cardLayout; // Layout que permite cambiar entre los diferentes paneles

    /**
     * Constructor de la clase VentanaEditarCliente. Inicializa la ventana, los paneles y
     * configura el layout principal para mostrar los diferentes formularios de edición.
     *
     * @param listaClientes Lista de clientes disponible para realizar la búsqueda.
     */
    public VentanaEditarCliente(ArrayList<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
        this.gestorClientes = new GestorClientes(); // Inicializa el gestor de clientes
        setTitle("Editar Cliente");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        cardLayout = new CardLayout();
        panelPrincipal = new JPanel(cardLayout); // El panel principal usará CardLayout para intercambiar entre paneles
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        add(panelPrincipal, gbc); // Añade el panel principal a la ventana

        crearPanelBusqueda(); // Método que configura el panel de búsqueda
        crearPanelEdicion();  // Método que configura el panel de edición

        cardLayout.show(panelPrincipal, "Busqueda"); // Muestra el panel de búsqueda al iniciar
    }

    /**
     * Crea el panel de búsqueda de clientes por número de identificación.
     * Incluye un campo de texto para ingresar el número y un botón para buscar al cliente.
     * Muestra los resultados de la búsqueda y permite acceder al formulario de edición.
     */
    private void crearPanelBusqueda() {
        panelBusqueda = new JPanel(new GridBagLayout());
        buscarField = new JTextField(15); // Campo para ingresar el ID del cliente
        buscarButton = new JButton("Buscar"); // Botón para realizar la búsqueda
        resultadosArea = new JTextArea(12, 30); // Área donde se muestran los resultados
        resultadosArea.setEditable(false); // No editable
        JScrollPane scrollPane = new JScrollPane(resultadosArea); // Añade el área de resultados a un JScrollPane

        // Asigna la acción de buscar un cliente al botón de búsqueda
        buscarButton.addActionListener(this::buscarCliente);

        // Botones para editar la información o cancelar la búsqueda
        editarButton = new JButton("Editar Información");
        cancelarButton = new JButton("Cancelar");

        // Configuración del layout usando GridBagConstraints
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        panelBusqueda.add(new JLabel("Número de Identificación del cliente a editar:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        panelBusqueda.add(buscarField, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        panelBusqueda.add(buscarButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panelBusqueda.add(scrollPane, gbc); // Añade el área de resultados

        JPanel panelBotones = new JPanel(); // Panel para los botones de editar y cancelar
        panelBotones.add(editarButton);
        panelBotones.add(cancelarButton);
        cancelarButton.addActionListener(e -> dispose());

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panelBusqueda.add(panelBotones, gbc); // Añade los botones al panel

        // Añade el panel de búsqueda al panel principal
        panelPrincipal.add(panelBusqueda, "Busqueda");

        // Acción para cancelar la búsqueda
        cancelarButton.addActionListener(e -> cardLayout.show(panelPrincipal, "Busqueda"));

        // Acción para editar el cliente si es encontrado
        editarButton.addActionListener(e -> {
            if (clienteEncontrado != null) {
                crearPanelFormularioDatosContacto(clienteEncontrado); // Crea el formulario de edición de datos de contacto
                cardLayout.show(panelPrincipal, "Edicion"); // Muestra el panel de edición
            } else {
                JOptionPane.showMessageDialog(this, "No se puede editar. Cliente no encontrado.");
            }
        });
    }

    /**
     * Crea el panel de opciones de edición que permite seleccionar qué aspecto del cliente se desea modificar.
     */
    private void crearPanelEdicion() {
        panelEdicion = new JPanel(new GridBagLayout());
        GridBagConstraints gbcEdicion = new GridBagConstraints();
        gbcEdicion.insets = new Insets(10, 0, 10, 0);
        gbcEdicion.gridx = 0;
        gbcEdicion.fill = GridBagConstraints.NONE;
        gbcEdicion.anchor = GridBagConstraints.CENTER;

        JLabel tituloEdicion = new JLabel("¿Qué tipo de información desea editar?", SwingConstants.CENTER);
        tituloEdicion.setFont(new Font("Arial", Font.BOLD, 16));
        gbcEdicion.gridy = 0;
        panelEdicion.add(tituloEdicion, gbcEdicion); // Añade el título al panel de edición

        // Botón para editar los datos de contacto
        gbcEdicion.gridy++;
        JButton editarDatosContacto = new JButton("Editar Datos de Contacto");
        editarDatosContacto.addActionListener(e -> {
            crearPanelFormularioDatosContacto(clienteEncontrado); // Crea el formulario para editar los datos de contacto
            cardLayout.show(panelPrincipal, "FormularioDatosContacto"); // Muestra el formulario
        });
        panelEdicion.add(editarDatosContacto, gbcEdicion);

        // Botón para editar los datos personales
        gbcEdicion.gridy++;
        JButton editarDatosPersonales = new JButton("Editar Datos Personales");
        editarDatosPersonales.addActionListener(e -> {
            crearPanelFormularioDatosPersonales(clienteEncontrado); // Crea el formulario para editar los datos personales
            cardLayout.show(panelPrincipal, "FormularioDatosPersonales"); // Muestra el formulario
        });
        panelEdicion.add(editarDatosPersonales, gbcEdicion);

        // Botón para editar el equipo
        gbcEdicion.gridy++;
        JButton editarEquipo = new JButton("Editar Equipo");
        editarEquipo.addActionListener(e -> {
            crearPanelFormularioEquipo(clienteEncontrado); // Crea el formulario para editar el equipo
            cardLayout.show(panelPrincipal, "FormularioDatosEquipo"); // Muestra el formulario
        });
        panelEdicion.add(editarEquipo, gbcEdicion);

        // Botón para editar el plan
        gbcEdicion.gridy++;
        JButton editarPlan = new JButton("Editar Plan");
        editarPlan.addActionListener(e -> {
            crearPanelFormularioPlan(clienteEncontrado); // Crea el formulario para editar el plan
            cardLayout.show(panelPrincipal, "FormularioPlan"); // Muestra el formulario
        });
        panelEdicion.add(editarPlan, gbcEdicion);

        panelPrincipal.add(panelEdicion, "Edicion"); // Añade el panel de edición al panel principal
    }

    
    
    
    private void crearPanelFormularioPlan(Cliente cliente) {
        panelFormularioPlan = new JPanel(new GridBagLayout());
        GridBagConstraints gbcFormulario = new GridBagConstraints();
        gbcFormulario.insets = new Insets(10, 10, 10, 10);
        gbcFormulario.gridx = 0;
        gbcFormulario.fill = GridBagConstraints.NONE;
        gbcFormulario.anchor = GridBagConstraints.CENTER;

        JLabel tituloFormulario = new JLabel("Seleccione el nuevo plan:");
        tituloFormulario.setFont(new Font("Arial", Font.BOLD, 16));
        gbcFormulario.gridy = 0;
        panelFormularioPlan.add(tituloFormulario, gbcFormulario);

        JRadioButton planEconomico = new JRadioButton("Económico");
        JRadioButton planBasico = new JRadioButton("Básico");
        JRadioButton planNormal = new JRadioButton("Normal");
        JRadioButton planPremium = new JRadioButton("Premium");

        ButtonGroup grupoPlan = new ButtonGroup();
        grupoPlan.add(planEconomico);
        grupoPlan.add(planBasico);
        grupoPlan.add(planNormal);
        grupoPlan.add(planPremium);

        gbcFormulario.gridy++;
        panelFormularioPlan.add(planEconomico, gbcFormulario);
        gbcFormulario.gridy++;
        panelFormularioPlan.add(planBasico, gbcFormulario);
        gbcFormulario.gridy++;
        panelFormularioPlan.add(planNormal, gbcFormulario);
        gbcFormulario.gridy++;
        panelFormularioPlan.add(planPremium, gbcFormulario);

        gbcFormulario.gridy++;
        JButton confirmarButton = new JButton("Confirmar");
        panelFormularioPlan.add(confirmarButton, gbcFormulario);


        confirmarButton.addActionListener(e -> {
            String planSeleccionado = null;
            if (planEconomico.isSelected()) {
                planSeleccionado = "Económico";
                PlanesDisponibles plan = new PlanesDisponibles("Plan Económico", 8000, false, 60, false, 0, false, 10);
                cliente.setPlan(plan);
            } else if (planBasico.isSelected()) {
                planSeleccionado = "Básico";
                PlanesDisponibles plan = new PlanesDisponibles("Plan Básico", 12000, false, 120, false, 30, false, 50);
                cliente.setPlan(plan);
            } else if (planNormal.isSelected()) {
                planSeleccionado = "Normal";
                PlanesDisponibles plan = new PlanesDisponibles("Plan Normal", 15000, false, 200, false, 100, false, 100);
                cliente.setPlan(plan);
            } else if (planPremium.isSelected()) {
                planSeleccionado = "Premium";
                PlanesDisponibles plan = new PlanesDisponibles("Plan Premium", 20000, true, 0, true, 0, true, 0);
                cliente.setPlan(plan);
            }

            if (planSeleccionado != null) {
                // Asigna el plan al cliente
               // cliente.setPlan(planSeleccionado);
            	
                JOptionPane.showMessageDialog(this, "Plan actualizado a: " + planSeleccionado);
                
                cardLayout.show(panelPrincipal, "Edicion");
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione un plan.");
            }
        });

        panelPrincipal.add(panelFormularioPlan, "FormularioPlan");
    }
 

    private void crearPanelFormularioDatosContacto(Cliente cliente) {
        panelFormularioDatosContacto = new JPanel(new GridBagLayout());
        GridBagConstraints gbcFormulario = new GridBagConstraints();
        gbcFormulario.insets = new Insets(10, 10, 10, 10);
        gbcFormulario.gridx = 0;
        gbcFormulario.fill = GridBagConstraints.NONE;
        gbcFormulario.anchor = GridBagConstraints.CENTER;

        JLabel tituloFormulario = new JLabel("Seleccione el dato de contacto a editar:");
        tituloFormulario.setFont(new Font("Arial", Font.BOLD, 16));
        gbcFormulario.gridy = 0;
        panelFormularioDatosContacto.add(tituloFormulario, gbcFormulario);

        JRadioButton editarCorreo = new JRadioButton("Correo");
        JRadioButton editarTelefono = new JRadioButton("Teléfono");
        JRadioButton editarDireccionFacturacion = new JRadioButton("Dirección de Facturación");

        ButtonGroup grupoOpciones = new ButtonGroup();
        grupoOpciones.add(editarCorreo);
        grupoOpciones.add(editarTelefono);
        grupoOpciones.add(editarDireccionFacturacion);

        gbcFormulario.gridy++;
        panelFormularioDatosContacto.add(editarCorreo, gbcFormulario);
        gbcFormulario.gridy++;
        panelFormularioDatosContacto.add(editarTelefono, gbcFormulario);
        gbcFormulario.gridy++;
        panelFormularioDatosContacto.add(editarDireccionFacturacion, gbcFormulario);

        gbcFormulario.gridy++;
        JButton siguienteButton = new JButton("Siguiente");
        panelFormularioDatosContacto.add(siguienteButton, gbcFormulario);

        siguienteButton.addActionListener(e -> {
            if (editarCorreo.isSelected()) {
                mostrarFormularioIngreso(clienteEncontrado, "Correo");
            } else if (editarTelefono.isSelected()) {
                mostrarFormularioIngreso(clienteEncontrado, "Teléfono");
            } else if (editarDireccionFacturacion.isSelected()) {
                mostrarFormularioIngreso(clienteEncontrado, "Dirección de Facturación");
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione una opción.");
            }
        });

        panelPrincipal.add(panelFormularioDatosContacto, "FormularioDatosContacto");
    }

    private void crearPanelFormularioDatosPersonales(Cliente cliente) {
        panelFormularioDatosPersonales = new JPanel(new GridBagLayout());
        GridBagConstraints gbcFormulario = new GridBagConstraints();
        gbcFormulario.insets = new Insets(10, 10, 10, 10);
        gbcFormulario.gridx = 0;
        gbcFormulario.fill = GridBagConstraints.NONE;
        gbcFormulario.anchor = GridBagConstraints.CENTER;

        JLabel tituloFormulario = new JLabel("Seleccione el dato de contacto a editar:");
        tituloFormulario.setFont(new Font("Arial", Font.BOLD, 16));
        gbcFormulario.gridy = 0;
        panelFormularioDatosPersonales.add(tituloFormulario, gbcFormulario);

        JRadioButton editarNombre = new JRadioButton("Nombre y Apellido");
        JRadioButton editarFechaNacimiento = new JRadioButton("Fecha de Nacimiento");
        JRadioButton editarRut = new JRadioButton("Rut");

        ButtonGroup grupoOpciones = new ButtonGroup();
        grupoOpciones.add(editarNombre);
        grupoOpciones.add(editarFechaNacimiento);
        grupoOpciones.add(editarRut);

        gbcFormulario.gridy++;
        panelFormularioDatosPersonales.add(editarNombre, gbcFormulario);
        gbcFormulario.gridy++;
        panelFormularioDatosPersonales.add(editarFechaNacimiento, gbcFormulario);
        gbcFormulario.gridy++;
        panelFormularioDatosPersonales.add(editarRut, gbcFormulario);

        gbcFormulario.gridy++;
        JButton siguienteButton = new JButton("Siguiente");
        panelFormularioDatosPersonales.add(siguienteButton, gbcFormulario);

        siguienteButton.addActionListener(e -> {
            if (editarNombre.isSelected()) {
                mostrarFormularioIngreso(clienteEncontrado, "Nombre y Apellido");
            } else if (editarFechaNacimiento.isSelected()) {
                mostrarFormularioIngreso(clienteEncontrado, "Fecha de Nacimiento");
            } else if (editarRut.isSelected()) {
                mostrarFormularioIngreso(clienteEncontrado, "Rut");
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione una opción.");
            }
        });

        panelPrincipal.add(panelFormularioDatosPersonales, "FormularioDatosPersonales");
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    private void crearPanelFormularioEquipo(Cliente cliente) {
    	panelFormularioEquipo = new JPanel(new GridBagLayout());
        GridBagConstraints gbcFormulario = new GridBagConstraints();
        gbcFormulario.insets = new Insets(10, 10, 10, 10);
        gbcFormulario.gridx = 0;
        gbcFormulario.fill = GridBagConstraints.NONE;
        gbcFormulario.anchor = GridBagConstraints.CENTER;

        JLabel tituloFormulario = new JLabel("Seleccione el dato de contacto a editar:");
        tituloFormulario.setFont(new Font("Arial", Font.BOLD, 16));
        gbcFormulario.gridy = 0;
        panelFormularioEquipo.add(tituloFormulario, gbcFormulario);

        JRadioButton editarMarca = new JRadioButton("Marca");
        JRadioButton editarModelo = new JRadioButton("Modelo");
        JRadioButton editarNumeroSerie = new JRadioButton("Número de Serie");

        ButtonGroup grupoOpciones = new ButtonGroup();
        grupoOpciones.add(editarMarca);
        grupoOpciones.add(editarModelo);
        grupoOpciones.add(editarNumeroSerie);

        gbcFormulario.gridy++;
        panelFormularioEquipo.add(editarMarca, gbcFormulario);
        gbcFormulario.gridy++;
        panelFormularioEquipo.add(editarModelo, gbcFormulario);
        gbcFormulario.gridy++;
        panelFormularioEquipo.add(editarNumeroSerie, gbcFormulario);

        gbcFormulario.gridy++;
        JButton siguienteButton = new JButton("Siguiente");
        panelFormularioEquipo.add(siguienteButton, gbcFormulario);

        siguienteButton.addActionListener(e -> {
            if (editarMarca.isSelected()) {
                mostrarFormularioIngreso(clienteEncontrado, "Marca");
            } else if (editarModelo.isSelected()) {
                mostrarFormularioIngreso(clienteEncontrado, "Modelo");
            } else if (editarNumeroSerie.isSelected()) {
                mostrarFormularioIngreso(clienteEncontrado, "Número de Serie");
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione una opción.");
            }
        });

        panelPrincipal.add(panelFormularioEquipo, "FormularioDatosEquipo");
    }

    private void mostrarFormularioIngreso(Cliente cliente, String tipoDato) {
        JPanel panelIngresoDatos = new JPanel(new GridBagLayout());
        GridBagConstraints gbcIngreso = new GridBagConstraints();
        gbcIngreso.insets = new Insets(10, 10, 10, 10);
        gbcIngreso.gridx = 0;
        gbcIngreso.fill = GridBagConstraints.NONE;
        gbcIngreso.anchor = GridBagConstraints.CENTER;

        JLabel tituloIngreso = new JLabel("Ingrese la nueva información de " + tipoDato + ":");
        tituloIngreso.setFont(new Font("Arial", Font.BOLD, 16));
        gbcIngreso.gridy = 0;
        panelIngresoDatos.add(tituloIngreso, gbcIngreso);

        JTextField campoIngreso = new JTextField(20);
        gbcIngreso.gridy++;
        panelIngresoDatos.add(campoIngreso, gbcIngreso);

        gbcIngreso.gridy++;
        JButton confirmarButton = new JButton("Confirmar");
        panelIngresoDatos.add(confirmarButton, gbcIngreso);

        confirmarButton.addActionListener(e -> {
            String nuevoDato = campoIngreso.getText();
            // Aquí se actualiza el cliente seleccionado con el nuevo dato
            switch (tipoDato) {
                case "Correo":
                    cliente.getDatosContacto().setCorreo(nuevoDato); // Actualizar correo
                    break;
                case "Teléfono":
                    cliente.getDatosContacto().setTelefono(nuevoDato);
                    break;
                case "Dirección de Facturación":
                    cliente.getDatosContacto().setDireccionFacturacion(nuevoDato);
                case "Nombre y Apellido":
                	cliente.getDatosPersonales().setnombreCliente(nuevoDato);
                    break;
                case "Fecha de Nacimiento":
                	cliente.getDatosPersonales().setFechaNacimiento(nuevoDato);
                    break;
                case "Rut":
                	cliente.getDatosPersonales().setRut(nuevoDato);
                    break;
                case "Marca":
                	cliente.getEquipo().setMarca(nuevoDato);
                    break;
                case "Modelo":
                	cliente.getEquipo().setModelo(nuevoDato);
                    break;
                case "Número de Serie":
                	cliente.getEquipo().setNumeroSerie(nuevoDato);
                    break;
                default:
                	break;
            }

            JOptionPane.showMessageDialog(this, tipoDato + " actualizado a: " + nuevoDato);
            cardLayout.show(panelPrincipal, "Edicion");
        });

        panelPrincipal.add(panelIngresoDatos, "Ingreso" + tipoDato);
        cardLayout.show(panelPrincipal, "Ingreso" + tipoDato);
    }

    private void buscarCliente(ActionEvent e) 
    {
        String identificacionTexto = buscarField.getText().trim();

        try {
            int identificacion = Integer.parseInt(identificacionTexto);
            clienteEncontrado = gestorClientes.buscarClientePorNumeroId(listaClientes, identificacion);

            if (clienteEncontrado != null) {
                resultadosArea.setText("Cliente encontrado: " + clienteEncontrado.toString());
            } else {
                resultadosArea.setText("Cliente no encontrado.");
            }
        } catch (NumberFormatException ex) 
        {
            JOptionPane.showMessageDialog(this, "Ingrese un número de identificación válido.");
        }
    }

}