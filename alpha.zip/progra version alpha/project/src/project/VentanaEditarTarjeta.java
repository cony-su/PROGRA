package project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class VentanaEditarTarjeta extends JFrame {
	private Excep1 excepS = new Excep1("ERROR");
    private Excep2 excepN = new Excep2("ERROR");
    private JTextField idClienteField;
    private JButton buscarClienteButton, editarTarjetaButton, cancelarButton;
    private JTextArea resultadoArea;
    private JPanel panelBusqueda, panelAcciones;
    private Cliente clienteActual;
    private ArrayList<Cliente> listaClientes;
    
    public VentanaEditarTarjeta(ArrayList<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
        setTitle("Editar Tarjeta");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel de búsqueda de cliente
        panelBusqueda = new JPanel();
        panelBusqueda.add(new JLabel("ID Cliente:"));
        idClienteField = new JTextField(10);
        panelBusqueda.add(idClienteField);
        buscarClienteButton = new JButton("Buscar Cliente");
        panelBusqueda.add(buscarClienteButton);
        
        // Área de resultados para mostrar detalles del cliente y tarjetas
        resultadoArea = new JTextArea(10, 30);
        resultadoArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultadoArea);

        // Panel con botones de acciones
        panelAcciones = new JPanel();
        editarTarjetaButton = new JButton("Editar Tarjeta");
        editarTarjetaButton.setEnabled(false);
        cancelarButton = new JButton("Cancelar");
        panelAcciones.add(editarTarjetaButton);
        panelAcciones.add(cancelarButton);

        // Listeners de los botones
        buscarClienteButton.addActionListener(e -> buscarCliente());
        editarTarjetaButton.addActionListener(e -> mostrarFormularioSeleccionTarjeta());
        cancelarButton.addActionListener(e -> dispose());

        // Organización del panel
        setLayout(new BorderLayout());
        add(panelBusqueda, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(panelAcciones, BorderLayout.SOUTH);
    }

    // Método para buscar cliente por ID
    private void buscarCliente() {
        String idClienteStr = idClienteField.getText().trim();
        int idCliente;
        try {
            idCliente = Integer.parseInt(idClienteStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, ingresa un ID válido.");
            return;
        }

        GestorClientes gestorClientes = new GestorClientes();
        clienteActual = gestorClientes.buscarClientePorNumeroId(listaClientes, idCliente);

        if (clienteActual != null) {
            resultadoArea.setText("Cliente encontrado: " + clienteActual.getDatosPersonales().getNombreCliente() + "\n");
            resultadoArea.append("Tarjetas Registradas:\n");
            mostrarTarjetas(clienteActual);
            editarTarjetaButton.setEnabled(true);
        } else {
            resultadoArea.setText("Cliente no encontrado.");
            editarTarjetaButton.setEnabled(false);
        }
    }

    // Método para mostrar las tarjetas del cliente
    private void mostrarTarjetas(Cliente cliente) {
        if (cliente.getTarjetasRegistradas().isEmpty()) {
            resultadoArea.append("No hay tarjetas registradas.\n");
        } else {
            for (String numSerie : cliente.getTarjetasRegistradas().keySet()) {
                Tarjeta tarjeta = cliente.getTarjetasRegistradas().get(numSerie);
                resultadoArea.append("Número de Serie: " + numSerie + "\n");
                resultadoArea.append("  Nombre del Titular: " + tarjeta.getNombreTitular() + "\n");
                resultadoArea.append("  Tipo: " + tarjeta.getTipoTarjeta() + "\n\n");
            }
        }
    }

    // Método para mostrar el formulario de selección de tarjeta para editar
    private void mostrarFormularioSeleccionTarjeta() {
        String numSerie = JOptionPane.showInputDialog(this, "Ingrese el número de serie de la tarjeta a editar:");
        try
    	{
        	excepN.validarTarjeta(numSerie);
    		if (numSerie != null && clienteActual.getTarjetasRegistradas().containsKey(numSerie)) {
    			Tarjeta tarjetaAEditar = clienteActual.getTarjetasRegistradas().get(numSerie);
    			mostrarFormularioEdicionTarjeta(tarjetaAEditar);
    		} else {
    			JOptionPane.showMessageDialog(this, "Tarjeta no encontrada.");
    		}
    	}catch(Excep2 ex)
    	{
    		JOptionPane.showMessageDialog(this, ex.getMessage(), "Dato Invalido", JOptionPane.ERROR_MESSAGE);
    	}
    }

    // Método para mostrar el formulario de edición de la tarjeta
    private void mostrarFormularioEdicionTarjeta(Tarjeta tarjeta) {
        JFrame edicionFrame = new JFrame("Editar Tarjeta");
        edicionFrame.setSize(400, 300);
        edicionFrame.setLocationRelativeTo(null);
        edicionFrame.setLayout(new GridLayout(5, 2));

        JRadioButton titularRadio = new JRadioButton("Editar Nombre del Titular");
        JRadioButton serieRadio = new JRadioButton("Editar Número de Serie");
        JRadioButton fechaRadio = new JRadioButton("Editar Fecha de Vencimiento");
        JRadioButton codigoRadio = new JRadioButton("Editar Código de Seguridad");

        ButtonGroup opcionesGrupo = new ButtonGroup();
        opcionesGrupo.add(titularRadio);
        opcionesGrupo.add(serieRadio);
        opcionesGrupo.add(fechaRadio);
        opcionesGrupo.add(codigoRadio);

        edicionFrame.add(titularRadio);
        edicionFrame.add(serieRadio);
        edicionFrame.add(fechaRadio);
        edicionFrame.add(codigoRadio);

        JButton siguienteButton = new JButton("Siguiente");
        JButton volverButton = new JButton("Volver");
        edicionFrame.add(siguienteButton); 
        edicionFrame.add(volverButton);

        siguienteButton.addActionListener(e -> {
        	
        	try
        	{
            	if (titularRadio.isSelected()) {
                String nuevoTitular = JOptionPane.showInputDialog("Ingrese el nuevo nombre del titular:");
                excepS.validarNombre(nuevoTitular);
                tarjeta.setNombreTitular(nuevoTitular);
            } else if (serieRadio.isSelected()) {
                String nuevoSerie = JOptionPane.showInputDialog("Ingrese el nuevo número de serie:");
                excepN.validarTarjeta(nuevoSerie);
                tarjeta.setNumeroTarjeta(nuevoSerie);
            } else if (fechaRadio.isSelected()) {
                String nuevaFecha = JOptionPane.showInputDialog("Ingrese la nueva fecha de vencimiento (MM/AA):");
                excepN.validarFechaVencimiento(nuevaFecha);
                tarjeta.setFechaVencimiento(nuevaFecha);
            } else if (codigoRadio.isSelected()) {
                String nuevoCodigo = JOptionPane.showInputDialog("Ingrese el nuevo código de seguridad:");
                excepN.validarCodigoSeguridad(nuevoCodigo);
                tarjeta.setCodigoSeguridad(nuevoCodigo);
            }
            edicionFrame.dispose();
            
        	}catch(Excep1 ex)
        	{
        		JOptionPane.showMessageDialog(this, ex.getMessage(), "Dato Invalido", JOptionPane.ERROR_MESSAGE);
        	}catch(Excep2 ex)
        	{
        		JOptionPane.showMessageDialog(this, ex.getMessage(), "Dato Invalido", JOptionPane.ERROR_MESSAGE);
        	}
            
        });

        volverButton.addActionListener(e -> edicionFrame.dispose());

        edicionFrame.setVisible(true);
    }
}
