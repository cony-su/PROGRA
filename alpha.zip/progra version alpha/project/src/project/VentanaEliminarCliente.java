package project;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class VentanaEliminarCliente extends JFrame {
    private JTextField buscarField;
    private JButton buscarButton;
    private JTextArea resultadosArea;
    private JButton eliminarButton;
    private ArrayList<Cliente> listaClientes;
    private GestorClientes gestorClientes;
    private Cliente clienteActual;  // Guardar el cliente encontrado
    private ClientesDeudores clientesDeudores;
    private int clave;
    

    public VentanaEliminarCliente(ArrayList<Cliente> listaClientes, ClientesDeudores clientesDeudores) {
        this.listaClientes = listaClientes;
        this.clientesDeudores = clientesDeudores;
        this.gestorClientes = new GestorClientes(); // Inicializa el gestor
        setTitle("Eliminar Cliente");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Crear componentes
        buscarField = new JTextField(15); // Ajustar el tamaño del campo de texto
        buscarButton = new JButton("Buscar");
        resultadosArea = new JTextArea(10, 30);
        resultadosArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultadosArea);

        eliminarButton = new JButton("Eliminar");
        eliminarButton.setEnabled(false); // Deshabilitar hasta que se encuentre un cliente
        eliminarButton.addActionListener(this::Eliminar); // Acción para eliminar cliente

        // Configurar el botón de búsqueda
        buscarButton.addActionListener(this::Buscar);

        // Ajustar el diseño para que la etiqueta y el campo estén juntos
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        add(new JLabel("Número de Identificación del cliente a eliminar:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.LINE_START;
        add(buscarField, gbc);

        // Ahora el botón de búsqueda estará centrado justo debajo
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER; // Centrar el botón
        gbc.fill = GridBagConstraints.NONE;  // Evitar que el botón se expanda en toda la fila
        add(buscarButton, gbc);

        // Agregar el área de resultados
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        add(scrollPane, gbc);

        // Agregar el botón de eliminar centrado
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        add(eliminarButton, gbc);
    }

    // Método que busca un cliente y lo muestra, habilitando el botón de eliminar si es encontrado
    private void Buscar(ActionEvent e) {
        String identificacionTexto = buscarField.getText().trim();

        try {
            int identificacion = Integer.parseInt(identificacionTexto);
            Cliente cliente = gestorClientes.buscarClientePorNumeroId(listaClientes, identificacion);

            if (cliente != null) {
                mostrarCliente(cliente); // Mostrar cliente encontrado
                clienteActual = cliente; // Guardar el cliente actual
                clave = cliente.getDatosPersonales().getNumeroIdentificacion();
                eliminarButton.setEnabled(true); // Habilitar el botón de eliminar
            } else {
                resultadosArea.setText("Cliente no encontrado.");
                eliminarButton.setEnabled(false); // Deshabilitar el botón de eliminar
                clienteActual = null; // No hay cliente actual
            }
        } catch (NumberFormatException ex) {
            resultadosArea.setText("Error: El número de identificación debe ser numérico.");
            eliminarButton.setEnabled(false); // Deshabilitar el botón de eliminar
            clienteActual = null; // No hay cliente actual
        }
    }

    // Método para mostrar los detalles del cliente en el área de resultados
    private void mostrarCliente(Cliente cliente) {
        StringBuilder detallesCliente = new StringBuilder();
        detallesCliente.append("Nombre: ").append(cliente.getDatosPersonales().getNombreCliente()).append("\n");
        detallesCliente.append("Número de Identificación: ").append(cliente.getDatosPersonales().getNumeroIdentificacion()).append("\n");
        detallesCliente.append("Dirección: ").append(cliente.getDatosPersonales().getDireccion()).append("\n");
        detallesCliente.append("Plan: ").append(cliente.getPlan().getNombrePlan()).append("\n");
        detallesCliente.append("Equipo: ").append(cliente.getEquipo().getMarca()).append(" ").append(cliente.getEquipo().getModelo()).append("\n");

        // Mostrar facturas
        if (cliente.getFacturas().isEmpty()) {
            detallesCliente.append("Facturas: No hay facturas registradas.\n");
        } else {
            detallesCliente.append("Facturas:\n");
            for (String idFactura : cliente.getFacturas().keySet()) {
                Factura factura = cliente.getFacturas().get(idFactura);
                detallesCliente.append("  - Factura ID: ").append(factura.getIdFactura())
                        .append(", Monto: $").append(factura.getMonto())
                        .append(", Fecha: ").append(factura.getFechaEmision())
                        .append(", Estado: ").append(factura.getPagado() ? "PAGADO" : "NO PAGADO").append("\n");
            }
        }

        resultadosArea.setText(detallesCliente.toString());
    }

    private void Eliminar(ActionEvent e) {
        if (clienteActual != null) {
            int confirmacion = JOptionPane.showConfirmDialog(this, "¿Seguro que quieres eliminar a este cliente?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                // Eliminar el cliente de la lista principal de clientes
                if (gestorClientes.EliminarCliente(listaClientes, clienteActual)) {
                	clientesDeudores.eliminarDeudor(clienteActual);
                	clientesDeudores.getMapaClientesDeudores().remove(clave, clienteActual);                    
                    // Confirmar eliminación y actualizar interfaz
                    JOptionPane.showMessageDialog(this, "Cliente eliminado correctamente.");
                    resultadosArea.setText(""); // Limpiar el área de resultados
                    eliminarButton.setEnabled(false); // Deshabilitar el botón de eliminar
                    clienteActual = null; // Resetear el cliente actual
                } else {
                    JOptionPane.showMessageDialog(this, "Error al eliminar el cliente.");
                }
            }
        }
    }

}
