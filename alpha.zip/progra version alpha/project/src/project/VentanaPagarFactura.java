package project;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

 

public class VentanaPagarFactura extends JFrame {
	private Excep1 excepS = new Excep1("ERROR");
    private Excep2 excepN = new Excep2("ERROR");
    private JTextField buscarField;
    private JTextField eliminarField; // Campo para número de tarjeta a eliminar
    private JButton buscarButton;
    private JButton pagarButton; // Botón para pagar factura
    private JTextArea resultadosArea;
    private ArrayList<Cliente> listaClientes;
    private GestorClientes gestorClientes;
    private ClientesDeudores clientesDeudores;
    

    public VentanaPagarFactura(ArrayList<Cliente> listaClientes, ClientesDeudores clientesDeudores) {
        this.listaClientes = listaClientes;
        this.clientesDeudores = clientesDeudores;
        this.gestorClientes = new GestorClientes(); // Inicializa el gestor
        setTitle("Pagar Factura");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Crear componentes
        buscarField = new JTextField(20); // Campo para buscar cliente
        eliminarField = new JTextField(10); // Campo más pequeño para ID de factura
        buscarButton = new JButton("Buscar");
        pagarButton = new JButton("Pagar Factura");
        resultadosArea = new JTextArea(10, 30);
        resultadosArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultadosArea);

        // Configurar los botones
        buscarButton.addActionListener(this::buscarCliente);
        pagarButton.addActionListener(this::pagarFactura);

        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2; // Ocupa dos columnas
        gbc.anchor = GridBagConstraints.CENTER; // Centrar el texto
        add(new JLabel("Ingrese el Número de Identificación del Cliente"), gbc);

        // Campo de búsqueda centrado
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1; // Ocupa una columna
        gbc.anchor = GridBagConstraints.CENTER;
        add(buscarField, gbc);

        // Botón de búsqueda a la derecha del campo
        gbc.gridx = 1; // Colocar a la derecha del campo
        gbc.gridy = 1;
        gbc.gridwidth = 1; // Restablece el ancho de columna
        gbc.anchor = GridBagConstraints.LINE_START; // Alinear a la izquierda
        add(buscarButton, gbc);

        // Área de resultados
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2; // Ocupa dos columnas
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        add(scrollPane, gbc);

        // Etiqueta para ingresar la identificación de la factura
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1; // Ocupa una columna
        gbc.anchor = GridBagConstraints.LINE_END; // Alinear a la derecha
        add(new JLabel("Ingrese la Identificación de la Factura a Pagar:"), gbc);

        // Campo para ID de factura, un poco más pequeño
        gbc.gridx = 1; // Colocar a la derecha de la etiqueta
        gbc.gridy = 3;
        gbc.gridwidth = 1; // Restablece el ancho de columna
        gbc.anchor = GridBagConstraints.LINE_START; // Alinear a la izquierda
        eliminarField.setPreferredSize(new java.awt.Dimension(80, 25)); // Ajusta el tamaño del campo
        add(eliminarField, gbc);

        // Botón de pago centrado
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2; // Ocupa dos columnas
        gbc.anchor = GridBagConstraints.CENTER; // Centrar el botón
        add(pagarButton, gbc);
    }

    // Método que busca y retorna un cliente o null, sin mostrar el resultado
    private Cliente buscarCliente(ActionEvent e) {
        String identificacionTexto = buscarField.getText().trim();

        try {
            int identificacion = Integer.parseInt(identificacionTexto);
            Cliente cliente = gestorClientes.buscarClientePorNumeroId(listaClientes, identificacion);

            if (cliente != null) {
                mostrarCliente(cliente); // Mostrar cliente encontrado
                return cliente; // Retorna el cliente encontrado
            } else {
                resultadosArea.setText("Cliente no encontrado.");
                JOptionPane.showMessageDialog(this, "Cliente No Encontrado");
                return null; // Retorna null si no se encuentra el cliente
            }
        } catch (NumberFormatException ex) {
            resultadosArea.setText("Error: El número de identificación debe ser numérico.");
            return null; // Retorna null si el formato es incorrecto
        }
    }

    // Método para mostrar los detalles del cliente en el área de resultados
    private void mostrarCliente(Cliente cliente) {
        StringBuilder detallesCliente = new StringBuilder();
        detallesCliente.append("Cliente: ").append(cliente.getDatosPersonales().getNombreCliente()).append("\n");

        // Mostrar facturas
        if (cliente.getFacturas().isEmpty()) {
            detallesCliente.append("Facturas: No hay facturas registradas.\n");
        } else {
            detallesCliente.append("\nFacturas:\n");
            for (String idFactura : cliente.getFacturas().keySet()) {
                Factura factura = cliente.getFacturas().get(idFactura);
                detallesCliente.append("  - Factura ID: ").append(factura.getIdFactura())
                        .append(", Monto: $").append(factura.getMonto())
                        .append(", Fecha: ").append(factura.getFechaEmision())
                        .append(", Estado: ").append(factura.getPagado() ? "PAGADO" : "NO PAGADO").append("\n");
            }
        }

        if (cliente.getTarjetasRegistradas().isEmpty()) {
            detallesCliente.append("\nTarjetas: No hay tarjetas registradas.\n");
        } else {
            detallesCliente.append("\nTarjetas:\n");
            for (int i = 0; i < cliente.getTarjetasRegistradas().keySet().size(); i++) {
                String numSerie = (String) cliente.getTarjetasRegistradas().keySet().toArray()[i]; // Obtiene el número de serie
                Tarjeta tarjeta = cliente.getTarjetasRegistradas().get(numSerie);

                // Agrega el formato requerido para cada tarjeta
                detallesCliente.append("Tarjeta n°").append(i + 1).append(":").append("\n")
                        .append("  - Metodo de Pago: ").append(tarjeta.getMetodoPago()).append("\n")
                        .append("  - Tipo de Tarjeta: ").append(tarjeta.getTipoTarjeta()).append("\n")
                        .append("  - Nombre Titular: ").append(tarjeta.getNombreTitular()).append("\n")
                        .append("  - Número Tarjeta: ").append(tarjeta.getNumeroTarjeta()).append("\n\n"); // Agrega un espacio entre tarjetas
            }
        }

        resultadosArea.setText(detallesCliente.toString()); // Mostrar detalles en el área de resultados
    }

    // Método para pagar la factura
 // Método para pagar la factura
    private void pagarFactura(ActionEvent e) {
        String idFacturaTexto = eliminarField.getText().trim();

        // Buscamos el cliente primero
        Cliente cliente = buscarCliente(e);

        if (cliente != null) {
            Factura factura = cliente.buscarFactura(idFacturaTexto); // Busca la factura por ID

            if (factura != null) {
                // Mostrar tarjetas registradas
                StringBuilder tarjetasStringBuilder = new StringBuilder();
                HashMap<String, Tarjeta> tarjetas = cliente.getTarjetasRegistradas(); // Asumiendo que el Cliente tiene un método getTarjetasRegistradas()

                if (tarjetas.isEmpty()) {
                    tarjetasStringBuilder.append("\nTarjetas: No hay tarjetas registradas.\n");
                } else {
                    tarjetasStringBuilder.append("\nTarjetas:\n");
                    for (int i = 0; i < tarjetas.keySet().size(); i++) {
                        String numSerie = (String) tarjetas.keySet().toArray()[i]; // Obtiene el número de serie
                        Tarjeta tarjeta = tarjetas.get(numSerie);

                        // Agrega el formato requerido para cada tarjeta
                        tarjetasStringBuilder.append("Tarjeta n°").append(i + 1).append(":").append("\n")
                                .append("  - Metodo de Pago: ").append(tarjeta.getMetodoPago()).append("\n")
                                .append("  - Tipo de Tarjeta: ").append(tarjeta.getTipoTarjeta()).append("\n")
                                .append("  - Nombre Titular: ").append(tarjeta.getNombreTitular()).append("\n")
                                .append("  - Número Tarjeta: ").append(tarjeta.getNumeroTarjeta()).append("\n\n"); // Agrega un espacio entre tarjetas
                    }
                }

                // Pregunta al usuario si desea usar una tarjeta registrada o registrar una nueva
                String[] opciones = {"Usar tarjeta registrada", "Registrar nueva tarjeta"};
                int seleccion = JOptionPane.showOptionDialog(this, "Seleccione una opción:", "Pagar Factura",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

                if (seleccion == 0) { // Usar tarjeta registrada
                    String tarjetaSeleccionadaTexto = (String) JOptionPane.showInputDialog(this,
                            "Seleccione una tarjeta:\n" + tarjetasStringBuilder.toString(), "Seleccionar Tarjeta",
                            JOptionPane.PLAIN_MESSAGE, null, tarjetas.keySet().toArray(), null);

                    if (tarjetaSeleccionadaTexto != null) {
                        Tarjeta tarjetaSeleccionada = tarjetas.get(tarjetaSeleccionadaTexto);
                        if (tarjetaSeleccionada != null) {
                            // Realizar el pago
                            if (!factura.getPagado()) {
                                factura.pagarFactura(); // Marca la factura como pagada

                                // Verificar si el cliente sigue siendo deudor
                                if (cliente.clienteDeudor()) {
                                    // Si es deudor, lo mantenemos en la lista de deudores
                                    clientesDeudores.getMapaClientesDeudores().put(cliente.getDatosPersonales().getNumeroIdentificacion(), cliente);
                                } else {
                                    // Si ya no es deudor, lo removemos de la lista
                                    clientesDeudores.getMapaClientesDeudores().remove(cliente.getDatosPersonales().getNumeroIdentificacion());
                                }

                                JOptionPane.showMessageDialog(this, "Factura pagada con éxito con la tarjeta: " + tarjetaSeleccionadaTexto);
                                resultadosArea.setText(""); // Limpia el área de resultados
                            } else {
                                JOptionPane.showMessageDialog(this, "La factura ya ha sido pagada.");
                            }
                        }
                    }
                } else if (seleccion == 1) { // Registrar nueva tarjeta
                    // Lógica para registrar una nueva tarjeta
                    registrarNuevaTarjeta(cliente, factura);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Factura no encontrada.");
            }
        }
    }


    // Método para registrar una nueva tarjeta
 
    private void registrarNuevaTarjeta(Cliente cliente, Factura factura) {
        // Crear un panel para el formulario
        JPanel panel = new JPanel(new GridLayout(0, 2)); // GridLayout para organizar los campos

        // Campos para el método de pago
        JRadioButton creditoButton = new JRadioButton("Crédito", true); // Por defecto selecciona "Crédito"
        JRadioButton debitoButton = new JRadioButton("Débito");
        ButtonGroup metodoPagoGroup = new ButtonGroup(); // Grupo para los botones de opción

        // Añadir los botones al grupo
        metodoPagoGroup.add(creditoButton);
        metodoPagoGroup.add(debitoButton);

        // JComboBox para el tipo de tarjeta
        String[] tiposTarjetaCredito = {"Seleccione", "Visa", "MasterCard", "American Express", "Diners Club"};
        String[] tiposTarjetaDebito = {"Seleccione", "Redcompra", "Visa", "MasterCard", "Bank Red"};
        JComboBox<String> tipoTarjetaComboBox = new JComboBox<>(tiposTarjetaCredito);

        // Otros campos
        JTextField nombreTitularField = new JTextField();
        JTextField fechaVencimientoField = new JTextField();
        JTextField numeroTarjetaField = new JTextField();
        JTextField codigoSeguridadField = new JTextField();

        // Añadir componentes al panel
        panel.add(new JLabel("Método de Pago:"));
        panel.add(creditoButton);
        panel.add(new JLabel(""));
        panel.add(debitoButton);
        panel.add(new JLabel("Tipo de Tarjeta:"));
        panel.add(tipoTarjetaComboBox);
        panel.add(new JLabel("Nombre del Titular:"));
        panel.add(nombreTitularField);
        panel.add(new JLabel("Fecha de Vencimiento (MM/AA):"));
        panel.add(fechaVencimientoField);
        panel.add(new JLabel("Número de Tarjeta:"));
        panel.add(numeroTarjetaField);
        panel.add(new JLabel("Código de Seguridad:"));
        panel.add(codigoSeguridadField);

        // Listener para el cambio de método de pago
        ActionListener metodoPagoListener = e -> {
            if (debitoButton.isSelected()) {
                tipoTarjetaComboBox.removeAllItems();
                for (String tipo : tiposTarjetaDebito) {
                    tipoTarjetaComboBox.addItem(tipo);
                }
            } else {
                tipoTarjetaComboBox.removeAllItems();
                for (String tipo : tiposTarjetaCredito) {
                    tipoTarjetaComboBox.addItem(tipo);
                }
            }
            tipoTarjetaComboBox.setSelectedIndex(0); // Restablecer selección
        };

        creditoButton.addActionListener(metodoPagoListener);
        debitoButton.addActionListener(metodoPagoListener);

        // Mostrar el panel en un cuadro de diálogo
        int result = JOptionPane.showConfirmDialog(this, panel, "Registrar Nueva Tarjeta", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
        	
        	try
        	{
        		// Determinar el método de pago
        		int metodoPago = creditoButton.isSelected() ? 1 : (debitoButton.isSelected() ? 2 : 0);
            
        		// Verificar si el usuario ha seleccionado un método de pago
        		if (metodoPago == 0) {
        			JOptionPane.showMessageDialog(this, "Por favor, seleccione un método de pago.");
        			return; // Salir si no se ha seleccionado
        		}
        		
        		// Determinar el tipo de tarjeta
        		int tipoTarjeta = tipoTarjetaComboBox.getSelectedIndex(); // Obtener el índice seleccionado
        		
        		// Verificar si el usuario ha seleccionado un tipo de tarjeta
        		if (tipoTarjeta == 0) {
        			JOptionPane.showMessageDialog(this, "Por favor, seleccione un tipo de tarjeta.");
        			return; // Salir si no se ha seleccionado
        		}
        		
        		// Captura los datos ingresados
        		String nombreTitular = nombreTitularField.getText();
        		String fechaVencimiento = fechaVencimientoField.getText();
        		String numeroTarjeta = numeroTarjetaField.getText();
        		String codigoSeguridad = codigoSeguridadField.getText();
        		
        		//Llamada a excepciones
        		excepS.validarNombre(nombreTitular);
        		excepN.validarCodigoSeguridad(fechaVencimiento);
        		excepN.validarCodigoSeguridad(numeroTarjeta);
        		excepN.validarCodigoSeguridad(codigoSeguridad);

        		// Crear una nueva tarjeta con los datos ingresados
        		Tarjeta nuevaTarjeta = new Tarjeta(metodoPago, tipoTarjeta, nombreTitular, fechaVencimiento, numeroTarjeta, codigoSeguridad);
        		
        		// Pagar la factura
        		factura.pagarFactura();
        		
        		// Verificar el estado del cliente deudor
        		if (!cliente.clienteDeudor()) {
        			// Si el cliente ya no es deudor, eliminar de la lista de deudores
        			clientesDeudores.getMapaClientesDeudores().remove(cliente.getDatosPersonales().getNumeroIdentificacion());
        		}	

        		// Agregar la tarjeta al cliente
        		cliente.agregarTarjeta(nuevaTarjeta);
        		JOptionPane.showMessageDialog(this, "Tarjeta registrada con éxito.");
        		
        	}catch(Excep1 ex)
        	{
        		JOptionPane.showMessageDialog(this, ex.getMessage(), "Dato Invalido", JOptionPane.ERROR_MESSAGE);
        	}catch(Excep2 ex)
        	{
        		JOptionPane.showMessageDialog(this, ex.getMessage(), "Dato Invalido", JOptionPane.ERROR_MESSAGE);
        	}
        }
    }


}