package project;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class VentanaReporteIndividual extends JFrame {

    private JTextField buscarField;
    private JButton buscarButton;
    private ArrayList<Cliente> listaClientes;
    private GestorClientes gestorClientes;

    public VentanaReporteIndividual(ArrayList<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
        this.gestorClientes = new GestorClientes(); // Inicializa el gestor
        setTitle("Generar Reporte Individual");
        setSize(500, 150);  // Tamaño ajustado para una interfaz compacta
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Crear componentes
        buscarField = new JTextField(20);  // Ajustar tamaño del campo de búsqueda
        buscarButton = new JButton("Buscar");

        // Configurar el botón de búsqueda
        buscarButton.addActionListener(this::Buscar);

        // Agregar componentes a la ventana con un diseño visual más limpio
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        add(new JLabel("Número de Identificación del cliente:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0; 
        add(buscarField, gbc);

        // Centrar el botón "Buscar"
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER; // Centra el botón
        gbc.fill = GridBagConstraints.NONE;
        add(buscarButton, gbc);
    }

    // Método que busca y genera el reporte si se encuentra el cliente
    private Cliente Buscar(ActionEvent e) {
        String identificacionTexto = buscarField.getText().trim();

        try {
            int identificacion = Integer.parseInt(identificacionTexto);
            Cliente cliente = gestorClientes.buscarClientePorNumeroId(listaClientes, identificacion);

            if (cliente != null) {
                Reportes reporte = new Reportes();
                reporte.Reporte(cliente);
                return cliente; // Retorna el cliente encontrado
            } else {
                // Mostrar un mensaje de error en caso de que no se encuentre el cliente
                javax.swing.JOptionPane.showMessageDialog(this, "Cliente no encontrado.");
                return null;
            }
        } catch (NumberFormatException ex) {
            // Mostrar un mensaje de error si el formato es incorrecto
            javax.swing.JOptionPane.showMessageDialog(this, "El número de identificación debe ser numérico.");
            return null;
        }
    }
}
