package project;
import java.util.*;

import java.util.HashMap;

public class ClientesDeudores 
{
	HashMap <Integer, Cliente> mapaClientesDeudores = null; 
	
	public ClientesDeudores()
	{
		mapaClientesDeudores = new HashMap<Integer, Cliente>(); 
	}
	
	public HashMap<Integer, Cliente> getMapaClientesDeudores()
	{
		return mapaClientesDeudores;
	}
	
	public void setMapaClientesDeudores(HashMap<Integer, Cliente> mapaClientesDeudores)
	{
		this.mapaClientesDeudores = mapaClientesDeudores;
	}
	
	public void llenarMapa(ArrayList<Cliente> listaClientes)
	{
		for(Cliente cliente : listaClientes)
		  {
			  if(cliente.clienteDeudor()) mapaClientesDeudores.put(cliente.getDatosPersonales().getNumeroIdentificacion(), cliente);
		  }
	}
	
	public boolean eliminarDeudor(Cliente cliente) //si ya no es deudor lo quito del mapa
	{
		if(cliente.clienteDeudor()) return false;  
		mapaClientesDeudores.remove(cliente);
		return true;
	}
	
	public boolean mostrarClientesDeudores()
	{
		if(getMapaClientesDeudores() == null || getMapaClientesDeudores().isEmpty()) return false;
		for(int numID : getMapaClientesDeudores().keySet())
		  {
			  Cliente cliente = getMapaClientesDeudores().get(numID);
		      cliente.mostrarCliente();	         
		  }
		return true;
	}
	
}
