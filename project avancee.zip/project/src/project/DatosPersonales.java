package project;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

class DatosPersonales
{  
  private String nombreCliente;
  private String fechaNacimiento; 
  private String direccion;
  private int numeroIdentificacion;
  private String rut; 
  private static Set<Integer> seriesGeneradas = new HashSet<>();

  //CONSTRUCTOR
  public DatosPersonales(String nombreCliente, String FechaNacimiento, String direccion, String rut)
  {
    this.nombreCliente = nombreCliente;
    this.fechaNacimiento = FechaNacimiento;
    this.direccion = direccion;
    this.numeroIdentificacion = generarNumSerieUnico();
    this.rut = rut;
  }
  
  public DatosPersonales(String nombreCliente, String FechaNacimiento, String direccion, String rut, int numeroIdentificacion)
  {
    this.nombreCliente = nombreCliente;
    this.fechaNacimiento = FechaNacimiento;
    this.direccion = direccion;
    this.numeroIdentificacion = numeroIdentificacion;
    this.rut = rut;
  }
  
  private int generarNumSerieUnico() {
      Random random = new Random();
      int serie;
      do {
          // Genera un número aleatorio de 4 dígitos entre 1000 y 9999
          serie = random.nextInt(9000) + 1000;
      } while (seriesGeneradas.contains(serie)); // Repetir si el número ya existe
      seriesGeneradas.add(serie); // Añadir el número al set para no repetirlo
      return serie;
  }


  //SETTERS Y GETTERS
  public String getNombreCliente(){ 
    return nombreCliente;
  }

  public void setnombreCliente(String nombreCliente){
    this.nombreCliente = nombreCliente;
  }

  public String getFechaNacimiento(){
    return fechaNacimiento;
  }

  public void setFechaNacimiento(String fechaNacimiento){
    this.fechaNacimiento = fechaNacimiento;
  }

  public String getDireccion(){
    return direccion;
  }

  public void setDireccion(String direccion){
    this.direccion = direccion;
  }

  public int getNumeroIdentificacion(){
    return numeroIdentificacion;
  }

  public void setNumeroIdentificacion(int numeroIdentificacion){
    this.numeroIdentificacion = numeroIdentificacion;
  }

  public String getRut(){
    return rut;
  }

  public void setRut(String rut){
    this.rut = rut;
  }
}