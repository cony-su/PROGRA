package project;

class Equipo
{
  private String marca;
  private String modelo;
  private String numeroSerie;

  //CONSTRUCTOR
  public Equipo(String marca, String modelo, String numeroSerie)
  {
    this.marca = marca;
    this.modelo = modelo;
    this.numeroSerie = numeroSerie;
  }

  //SETTERS Y GETTERS
  public String getMarca() {
    return marca;
  }

  public void setMarca(String marca){
    this.marca = marca;
  }

  public String getModelo() {
    return modelo;
  }

  public void setModelo(String modelo){
    this.modelo = modelo;
  }

  public String getNumeroSerie() {
    return numeroSerie;
  }

  public void setNumeroSerie(String numeroSerie){
    this.numeroSerie = numeroSerie;
  }
}