package project;

//ERROR ESPECIFICO (EL USUARIO INGRESA LETRAS Y NO NUMEROS)
public class Excep1 extends Exception
{
	public Excep1(String msg)
	{
		super(msg);
	}
	
	//VALIDA NOMBRE Y APELLIDO
	public void validarNombre(String n) throws Excep1
	{
		if (!n.matches("^[A-Z][a-z]* [A-Z][a-z]*$"))
		{
			throw new Excep1("El nomble o el apellido no son valido");
		}
	}
	
	//VALIDA GMAIL (SE PUEDE CAMBIAR PARA QUE NO SOLO ACEPTE GMAIL)
	public void validarMail(String g) throws Excep1
	{
		if (!g.matches("^[\\w\\d.%+-]+@[\\w\\d]*\\.+[\\w]{2,6}"))
		{
			throw new Excep1("El gmail no es valido");
		}
	}
}


