package project;

//ERROR GENERAL
public class Excep2 extends Exception {
	
	public Excep2(String msg)
	{
		super(msg);
	}
	
	//Validar numero
	public void validarN(String n) throws Excep2
	{
		if (!n.matches("\\d*"))
			throw new Excep2("El valor ingresado no es numerico, porfavor ingrese un valor valido");
	}
	
	//Validacion de telefono
	public void validarTelefono(String t) throws Excep2
	{
		if (!t.matches("^\\+569 [0-9]{4} [0-9]{4}$"))
			throw new Excep2("El numero telefonico no es valido");
	}
	
	//Validacion de fecha de nacimiento
	public void validarFechaNacimiento(String fn) throws Excep2
	{
		if (!fn.matches("^(0[1-9]|[12][0-9]|3[01])/(1[0-2]|0[1-9])/(19[0-9][0-9]|20[01][0-9]|202[0-4])$"))
			throw new Excep2("La fecha de nacimiento no es valida");
	}
	
	//Validacion de tarjeta
	public void validarTarjeta(String tar) throws Excep2
	{
		if (!tar.matches("\\d{4} \\d{4} \\d{4} \\d{4}"))
			throw new Excep2("El numero de la tarjeta no es valido");
	}
	
	//Validar el codigo de seguridad de la tarjeta
	public void validarCodigoSeguridad(String cr) throws Excep2
	{
		if (!cr.matches("\\d{3}"))
			throw new Excep2("El numero del reverso de su tarteja no es valida");
	}
	
	//Validacion de fecha de vencimiento
	public void validarFechaVencimiento(String fv) throws Excep2
	{
		if (!fv.matches("^(0[1-9]|1[0-2])/(2[4-9]|[3-9][0-9])$"))
			throw new Excep2("La fecha de caducidad de su tarjeta no es valida o ha caducado");
	}
	
	//Validar Rut
	public void validarRut(String r) throws Excep2
	{
		if (!r.matches("^([1-9]|[12][0-9])\\.\\d{3}\\.\\d{3}-([k]|[K]|[0-9])$"))
			throw new Excep2("El rut ingresado no es valido");
	}
}
