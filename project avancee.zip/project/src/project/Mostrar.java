package project;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class Mostrar extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    // Constructor para inicializar la ventana
    public Mostrar() {
        setTitle("Mostrar Información");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Crear el modelo de la tabla
        model = new DefaultTableModel();
        model.addColumn("Nombre");
        model.addColumn("Teléfono");
        model.addColumn("RUT");
        model.addColumn("Correo");
        model.addColumn("Dirección");
        model.addColumn("Número de Identificación");
        model.addColumn("Tipo de Plan");
        model.addColumn("Equipo");
        model.addColumn("Facturas");
        
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER); // Agregar la tabla dentro de un JScrollPane

        // Botón para cerrar la ventana
        JButton botonCerrar = new JButton("Cerrar");
        botonCerrar.addActionListener(e -> dispose());
        add(botonCerrar, BorderLayout.SOUTH);
    }

    // Método para mostrar un cliente específico
    public void mostrarCliente(Cliente cliente) {
        // Limpiar el modelo de la tabla
        model.setRowCount(0);
        
        // Agregar el cliente al modelo
        model.addRow(new Object[]{
        	    cliente.getDatosPersonales().getNombreCliente(),
        	    cliente.getDatosContacto().getTelefono(),
        	    cliente.getDatosPersonales().getRut(),
        	    cliente.getDatosContacto().getCorreo(),
        	    cliente.getDatosPersonales().getDireccion(),
        	    cliente.getDatosPersonales().getNumeroIdentificacion(),
        	    cliente.getPlan().getNombrePlan(),
        	    cliente.getEquipo().getMarca() + cliente.getEquipo().getModelo(),
        	    cliente.getFacturas() // Este es el séptimo elemento
        	});

    }

    // Método para mostrar todos los clientes
    public void mostrarClientes(ArrayList<Cliente> listaClientes) {
        // Limpiar el modelo de la tabla
        model.setRowCount(0);
        
        // Agregar los clientes al modelo
        for (Cliente cliente : listaClientes) {
        	model.addRow(new Object[]{
        		    cliente.getDatosPersonales().getNombreCliente(),
        		    cliente.getDatosContacto().getTelefono(),
        		    cliente.getDatosPersonales().getRut(),
        		    cliente.getDatosContacto().getCorreo(),
        		    cliente.getDatosPersonales().getDireccion(),
        		    cliente.getDatosPersonales().getNumeroIdentificacion(),
        		    cliente.getPlan().getNombrePlan(),
        		    cliente.getEquipo().getMarca() + cliente.getEquipo().getModelo(),
        		    facturasToString(cliente.getFacturas()),
        		     // Este es el séptimo elemento
        		});

        }
    }
    
    private String facturasToString(Map<String, Factura> facturas) {
        StringBuilder builder = new StringBuilder();
        if (facturas.isEmpty()) {
            return "No hay facturas"; // Mensaje si no hay facturas
        }
        for (Map.Entry<String, Factura> entry : facturas.entrySet()) {
            Factura factura = entry.getValue();
            builder.append("- ").append(factura.toString()).append("\n"); // Precede con un guion
        }
        return builder.toString();
    }


    public void mostrarPlanesDisponibles() {
        // Limpiar el modelo de la tabla (si lo habías usado anteriormente)
        model.setRowCount(0);
        
        // Crear un JLabel para el título y personalizar su fuente
        JLabel titulo = new JLabel("Planes Disponibles");
        titulo.setFont(new Font("Arial", Font.BOLD, 18)); // Cambiar la fuente y tamaño
        titulo.setHorizontalAlignment(SwingConstants.CENTER); // Centrar el texto

        // Crear un JTextArea para mostrar los planes disponibles
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false); // No permitir edición
        textArea.setMargin(new Insets(10, 10, 10, 10)); // Agregar margen al JTextArea

        // Definir el texto de los planes
        StringBuilder planesTexto = new StringBuilder();
        planesTexto.append("1. Plan Económico\n");
        planesTexto.append("   - Llamadas nacionales: 60 minutos\n");
        planesTexto.append("   - Datos móviles: 10 GB\n");
        planesTexto.append("   - Precio: $8000\n\n");
        planesTexto.append("2. Plan Básico\n");
        planesTexto.append("   - Llamadas nacionales: 120 minutos\n");
        planesTexto.append("   - Llamadas internacionales: 30 minutos\n");
        planesTexto.append("   - Datos móviles: 50 GB\n");
        planesTexto.append("   - Precio: $12000\n\n");
        planesTexto.append("3. Plan Normal\n");
        planesTexto.append("   - Llamadas nacionales: 200 minutos\n");
        planesTexto.append("   - Llamadas internacionales: 100 minutos\n");
        planesTexto.append("   - Datos móviles: 100 GB\n");
        planesTexto.append("   - Precio: $15000\n\n");
        planesTexto.append("4. Plan Premium\n");
        planesTexto.append("   - Llamadas nacionales: ilimitadas\n");
        planesTexto.append("   - Llamadas internacionales: ilimitadas\n");
        planesTexto.append("   - Datos móviles: ilimitados\n");
        planesTexto.append("   - Precio: $20000\n");

        // Establecer el texto en el JTextArea
        textArea.setText(planesTexto.toString());

        // Agregar el JTextArea a un JScrollPane para permitir el desplazamiento si es necesario
        JScrollPane scrollPane = new JScrollPane(textArea);
        
        // Configurar la ventana
        setTitle("Planes Disponibles");
        setLayout(new BorderLayout()); // Usar BorderLayout para agregar componentes
        add(titulo, BorderLayout.NORTH); // Agregar el título al norte
        add(scrollPane, BorderLayout.CENTER); // Agregar el JScrollPane al centro

        // Botón para cerrar la ventana
        JButton botonCerrar = new JButton("Cerrar");
        botonCerrar.addActionListener(e -> dispose());
        add(botonCerrar, BorderLayout.SOUTH);
        
        // Ajustar el tamaño de la ventana
        setSize(400, 300);
        setVisible(true); // Hacer la ventana visible
    }

}
