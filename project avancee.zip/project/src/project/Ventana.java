package project;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;


public class Ventana extends JFrame 
{
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private CardLayout cardLayout; // Usar CardLayout para cambiar entre vistas
    private JPanel menuPrincipal; // Panel para el menú principal
    private JPanel subMenuClientes; // Panel para el submenú de clientes
    private JPanel subMenuTatjetas;
    private ArrayList<Cliente> listaClientes = new ArrayList<Cliente>(); 
    private ClientesDeudores clientesDeudores = new ClientesDeudores();
    

    public Ventana(ArrayList<Cliente> listaClientes, ClientesDeudores clientesDeudores) {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        setTitle("Menú Principal");
        inicializarClientes();
        cardLayout = new CardLayout();
        contentPane = new JPanel(cardLayout); // Asignar CardLayout al contentPane
        setContentPane(contentPane);
        
        menuPrincipal = crearPanelMenuPrincipal(); // Crear panel del menú principal
        subMenuClientes = crearPanelSubMenuClientes(); // Crear panel del submenú
        subMenuTatjetas = crearPanelSubMenuTarjetas();
        
        contentPane.add(menuPrincipal, "Menú Principal"); // Agregar menú principal
        contentPane.add(subMenuClientes, "SubMenuClientes"); // Agregar submenú de clientes
        contentPane.add(subMenuTatjetas, "SubMenuTarjetas"); // Agregar submenú de tarjetas
        
        cardLayout.show(contentPane, "Menú Principal"); // Mostrar menú principal al inicio
        
    }
    
    private void inicializarClientes() {
    	ClientesRegistrados clientesRegistrados = new ClientesRegistrados();
    	Cliente cliente1 = clientesRegistrados.ClienteRegistrado1();
        Cliente cliente2 = clientesRegistrados.ClienteRegistrado2();
        Cliente cliente3 = clientesRegistrados.ClienteRegistrado3();
        Cliente cliente4 = clientesRegistrados.ClienteRegistrado4();
    	listaClientes.add(cliente1);
        listaClientes.add(cliente2);
        listaClientes.add(cliente3);
        listaClientes.add(cliente4);
        clientesDeudores.llenarMapa(listaClientes);
    }


    private JPanel crearPanelMenuPrincipal() {
        JPanel panelBotones = new JPanel(new GridBagLayout()); // Usar GridBagLayout para centrar los botones
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0); // Espaciado entre componentes
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL; // Los botones llenan el espacio horizontalmente

        // Crear el título
        JLabel tituloMenu = new JLabel("Bienvenido al Sistema de Telefonía Celular", SwingConstants.CENTER);
        tituloMenu.setFont(new Font("Arial", Font.BOLD, 16)); // Ajustar el tamaño del título
        gbc.gridy = 0; // Posición en la fila 0
        panelBotones.add(tituloMenu, gbc);

        // Crear botones
        JButton botonSubmenuClientes = new JButton("Mostrar SubMenú de Clientes");
        JButton botonSubmenuTarjetas = new JButton("Mostrar SubMenú de Tarjetas");
        JButton botonMostrarPlanesDisponibles = new JButton("Mostrar Planes Disponibles");
        JButton botonGenerarReporteGeneral = new JButton("Generar Reporte General");
        JButton botonPagarFactura = new JButton("Pagar Factura");
        JButton botonSalir = new JButton("Salir");

        // Añadir acción a los botones
        botonSubmenuClientes.addActionListener(e -> cardLayout.show(contentPane, "SubMenuClientes")); // Cambia a submenú
        botonSubmenuTarjetas.addActionListener(e -> cardLayout.show(contentPane, "SubMenuTarjetas")); // Cambia a submenú de tarjetas
        botonMostrarPlanesDisponibles.addActionListener(e -> mostrarPlanesDisponibles());
        botonGenerarReporteGeneral.addActionListener(e -> generarReporteGeneral());
        botonPagarFactura.addActionListener(e -> pagarFactura());
        botonSalir.addActionListener(e -> salir());

        // Agregar botones al panel, uno por uno
        gbc.gridy++; // Mover a la siguiente fila
        panelBotones.add(botonSubmenuClientes, gbc);
        gbc.gridy++;
        panelBotones.add(botonSubmenuTarjetas, gbc);
        gbc.gridy++;
        panelBotones.add(botonMostrarPlanesDisponibles, gbc);
        gbc.gridy++;
        panelBotones.add(botonGenerarReporteGeneral, gbc);
        gbc.gridy++;
        panelBotones.add(botonPagarFactura, gbc);
        gbc.gridy++;
        panelBotones.add(botonSalir, gbc);

        return panelBotones; // Retornar el panel de botones
    }


    private JPanel crearPanelSubMenuClientes() {
        JPanel panelSubMenu = new JPanel(new GridBagLayout()); // Usar GridBagLayout para centrar los botones
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0); // Espaciado entre componentes
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL; // Los botones llenan el espacio horizontalmente
        gbc.anchor = GridBagConstraints.CENTER; // Asegurarse de que los botones estén alineados al centro

        JLabel tituloSubMenu = new JLabel("SubMenú de Clientes", SwingConstants.CENTER);
        tituloSubMenu.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridy = 0;
        panelSubMenu.add(tituloSubMenu, gbc);

        // Crear botones
        JButton botonRegistrarCliente = new JButton("Registrar Cliente");
        JButton botonMostrarClientes = new JButton("Mostrar Clientes");
        JButton botonBuscarCliente = new JButton("Buscar Cliente");
        JButton botonEliminarCliente = new JButton("Eliminar Cliente");
        JButton botonEditarCliente = new JButton("Editar Cliente");
        JButton botonGenerarReporteIndividual = new JButton("Generar Reporte Individual");
        JButton botonMostrarDeudores = new JButton("Mostrar Clientes Deudores");
        JButton botonVolver = new JButton("Volver");

        // Añadir acciones a los botones
        botonRegistrarCliente.addActionListener(e -> registrarCliente());
        botonMostrarClientes.addActionListener(e -> mostrarClientes());
        botonBuscarCliente.addActionListener(e -> buscarCliente());
        botonEliminarCliente.addActionListener(e -> eliminarCliente());
        botonEditarCliente.addActionListener(e -> editarCliente());
        botonGenerarReporteIndividual.addActionListener(e -> reporteIndividualCliente());
        botonMostrarDeudores.addActionListener(e -> mostrarDeudoresCliente());
        botonVolver.addActionListener(e -> cardLayout.show(contentPane, "Menú Principal"));

        // Agregar botones al panel
        gbc.gridy++;
        panelSubMenu.add(botonRegistrarCliente, gbc);
        gbc.gridy++;
        panelSubMenu.add(botonMostrarClientes, gbc);
        gbc.gridy++;
        panelSubMenu.add(botonBuscarCliente, gbc);
        gbc.gridy++;
        panelSubMenu.add(botonEliminarCliente, gbc);
        gbc.gridy++;
        panelSubMenu.add(botonEditarCliente, gbc);
        gbc.gridy++;
        panelSubMenu.add(botonGenerarReporteIndividual, gbc);
        gbc.gridy++;
        panelSubMenu.add(botonMostrarDeudores, gbc);
        gbc.gridy++;
        panelSubMenu.add(botonVolver, gbc);

        return panelSubMenu;
    }


    private void subMenuTarjetas() {
        // Lógica para mostrar tarjetas
    }

    private void mostrarPlanesDisponibles() {
    	Mostrar ventanaMostrar = new Mostrar(); // Asegúrate de que 'MostrarClientes' tenga 'M' mayúscula
    	ventanaMostrar.mostrarPlanesDisponibles();
        ventanaMostrar.setVisible(true);
    }

    private void generarReporteGeneral() {
        Reportes reporte = new Reportes();
        reporte.Reporte(listaClientes);
    }

    private void pagarFactura() {
        // Lógica para pagar factura
    }

    private void registrarCliente() {
    	VentanaRegistro ventanaRegistro = new VentanaRegistro(listaClientes);
	    ventanaRegistro.setVisible(true);
    }

    private void mostrarClientes() 
    {	
    	Mostrar ventanaMostrar = new Mostrar(); // Asegúrate de que 'MostrarClientes' tenga 'M' mayúscula
    	ventanaMostrar.mostrarClientes(listaClientes);
        ventanaMostrar.setVisible(true);
    }


    private void buscarCliente() {
        VentanaBuscarCliente ventanaBuscar = new VentanaBuscarCliente(listaClientes);      
        ventanaBuscar.setVisible(true);
    }
    
    private void eliminarCliente() {
    	VentanaEliminarCliente ventanaEliminar = new VentanaEliminarCliente(listaClientes);      
    	ventanaEliminar.setVisible(true);
    }
    
    private void editarCliente() {
    	VentanaEditarCliente ventana = new VentanaEditarCliente(listaClientes);
    	ventana.setVisible(true);
    }
    
    
    private void reporteIndividualCliente() {
    	VentanaReporteIndividual reporte = new VentanaReporteIndividual(listaClientes);
    	reporte.setVisible(true);
    }
    

    private void mostrarDeudoresCliente() {
    	VentanaDeudores deudores = new VentanaDeudores(clientesDeudores);
    	deudores.mostrarClientesDeudores();
    	deudores.setVisible(true);
    }
    
    private void salir() {
        System.exit(0); // Cierra la aplicación
    }

    private JPanel crearPanelSubMenuTarjetas() {
        JPanel panelSubMenu = new JPanel(new GridBagLayout()); // Usar GridBagLayout para centrar los botones
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0); // Espaciado entre componentes
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL; // Los botones llenan el espacio horizontalmente
        gbc.anchor = GridBagConstraints.CENTER; // Asegurarse de que los botones estén alineados al centro

        JLabel tituloSubMenu = new JLabel("SubMenú de Tarjetas", SwingConstants.CENTER);
        tituloSubMenu.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridy = 0;
        panelSubMenu.add(tituloSubMenu, gbc);

        // Crear botones
        JButton botonMostrarTarjetasAsociadas = new JButton("Mostrar Tarjetas Asociadas");
        JButton botonEliminarTarjetaAsociada = new JButton("Eliminar Tarjeta Asociada");
        JButton botonEditarTarjetaAsociada = new JButton("Editar Tarjeta Asociada");
        JButton botonVolver = new JButton("Volver");

        // Añadir acciones a los botones
        botonMostrarTarjetasAsociadas.addActionListener(e -> mostrarTarjetasAsociadas());
        botonEliminarTarjetaAsociada.addActionListener(e -> eliminarTarjetaAsociada());
        botonEditarTarjetaAsociada.addActionListener(e -> editarTarjetaAsociada());
        botonVolver.addActionListener(e -> cardLayout.show(contentPane, "Menú Principal"));

        // Agregar botones al panel
        gbc.gridy++;
        panelSubMenu.add(botonMostrarTarjetasAsociadas, gbc);
        gbc.gridy++;
        panelSubMenu.add(botonEliminarTarjetaAsociada, gbc);
        gbc.gridy++;
        panelSubMenu.add(botonEditarTarjetaAsociada, gbc);
        gbc.gridy++;
        panelSubMenu.add(botonVolver, gbc);

        return panelSubMenu;
    }

    
    private void mostrarTarjetasAsociadas() {
    	VentanaMostrarTarjetas tarjetas = new VentanaMostrarTarjetas(listaClientes);
    	tarjetas.setVisible(true);
    }
    
    private void eliminarTarjetaAsociada() {
    	VentanaEliminarTarjeta ventana = new VentanaEliminarTarjeta(listaClientes);
    	ventana.setVisible(true);
    }
    
    private void editarTarjetaAsociada() {
        // Lógica para modificar cliente
        JOptionPane.showMessageDialog(this, "Funcionalidad de editar tarjetas.");
    }


}
