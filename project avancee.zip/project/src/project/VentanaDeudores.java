package project;
import javax.swing.JOptionPane;
import java.awt.BorderLayout;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class VentanaDeudores extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private ClientesDeudores clientesDeudores;

    // Constructor para inicializar la ventana
    public VentanaDeudores(ClientesDeudores clientesDeudores) {
        this.clientesDeudores = clientesDeudores;
        setTitle("Mostrar Información de Deudores");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Crear el modelo de la tabla
        model = new DefaultTableModel();
        model.addColumn("Nombre");
        model.addColumn("Teléfono");
        model.addColumn("RUT");
        model.addColumn("Correo");
        model.addColumn("Dirección");
        model.addColumn("Número de Identificación");
        model.addColumn("Tipo de Plan");
        model.addColumn("Equipo");
        model.addColumn("Facturas");
        
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER); // Agregar la tabla dentro de un JScrollPane

        // Botón para cerrar la ventana
        JButton botonCerrar = new JButton("Cerrar");
        botonCerrar.addActionListener(e -> dispose());
        add(botonCerrar, BorderLayout.SOUTH);
    }

    // Método para mostrar un cliente específico
    public void mostrarCliente(Cliente cliente) {
        // Limpiar el modelo de la tabla
        model.setRowCount(0);
        
        // Agregar el cliente al modelo
        model.addRow(new Object[]{
            cliente.getDatosPersonales().getNombreCliente(),
            cliente.getDatosContacto().getTelefono(),
            cliente.getDatosPersonales().getRut(),
            cliente.getDatosContacto().getCorreo(),
            cliente.getDatosPersonales().getDireccion(),
            cliente.getDatosPersonales().getNumeroIdentificacion(),
            cliente.getPlan().getNombrePlan(),
            cliente.getEquipo().getMarca() + " " + cliente.getEquipo().getModelo(),
            facturasToString(cliente.getFacturas())
        });
    }

    // Método para mostrar todos los clientes deudores
    public void mostrarClientesDeudores() {
        // Limpiar el modelo de la tabla
        model.setRowCount(0);
        if (clientesDeudores.getMapaClientesDeudores().isEmpty()) {
            // Mostrar un mensaje de alerta si no hay clientes deudores
            JOptionPane.showMessageDialog(this, "No hay clientes deudores.", "Alerta", JOptionPane.WARNING_MESSAGE);
            return; // Salir del método si el mapa está vacío
        }
        // Agregar los clientes deudores al modelo
        for (Map.Entry<Integer, Cliente> entry : clientesDeudores.getMapaClientesDeudores().entrySet()) {
            Cliente cliente = entry.getValue(); // Obtener el cliente deudor
            model.addRow(new Object[]{
                cliente.getDatosPersonales().getNombreCliente(),
                cliente.getDatosContacto().getTelefono(),
                cliente.getDatosPersonales().getRut(),
                cliente.getDatosContacto().getCorreo(),
                cliente.getDatosPersonales().getDireccion(),
                cliente.getDatosPersonales().getNumeroIdentificacion(),
                cliente.getPlan().getNombrePlan(),
                cliente.getEquipo().getMarca() + " " + cliente.getEquipo().getModelo(),
                facturasToString(cliente.getFacturas())
            });
        }
    }
    
    // Método para convertir el mapa de facturas a una cadena legible
    private String facturasToString(Map<String, Factura> facturas) {
        StringBuilder builder = new StringBuilder();
        if (facturas.isEmpty()) {
            return "No hay facturas"; // Mensaje si no hay facturas
        }
        for (Map.Entry<String, Factura> entry : facturas.entrySet()) {
            Factura factura = entry.getValue();
            builder.append("- ").append(factura.toString()).append("\n"); // Precede con un guion
        }
        return builder.toString();
    }
}
