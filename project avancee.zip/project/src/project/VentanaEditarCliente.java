package project;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class VentanaEditarCliente extends JDialog {
    private JTextField buscarField;
    private JButton buscarButton;
    private JTextArea resultadosArea;
    private JButton editarButton, cancelarButton;
    private JPanel panelPrincipal, panelBusqueda, panelEdicion;
    private ArrayList<Cliente> listaClientes;
    private GestorClientes gestorClientes;
    private Cliente clienteEncontrado;

    public VentanaEditarCliente(ArrayList<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
        this.gestorClientes = new GestorClientes(); // Inicializa el gestor
        setTitle("Buscar Cliente");
        setSize(500, 400);  // Ajustamos el tamaño de la ventana
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Panel principal para cambiar entre diferentes vistas
        panelPrincipal = new JPanel(new CardLayout());
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        add(panelPrincipal, gbc);

        // Crear componentes de búsqueda
        panelBusqueda = new JPanel(new GridBagLayout());
        buscarField = new JTextField(15);  // Ajustamos el tamaño del campo de texto
        buscarButton = new JButton("Buscar");
        resultadosArea = new JTextArea(12, 30);  // Aumentamos el tamaño del área de resultados
        resultadosArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultadosArea);

        buscarButton.addActionListener(this::buscarCliente);

        // Botones de Editar y Cancelar
        editarButton = new JButton("Editar Información");
        cancelarButton = new JButton("Cancelar");

        // Configuración del GridBagLayout
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        panelBusqueda.add(new JLabel("Número de Identificación del cliente a editar:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        panelBusqueda.add(buscarField, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        panelBusqueda.add(buscarButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panelBusqueda.add(scrollPane, gbc);

        // Agregar botones debajo del área de resultados
        JPanel panelBotones = new JPanel();
        panelBotones.add(editarButton);
        panelBotones.add(cancelarButton);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panelBusqueda.add(panelBotones, gbc);

        panelPrincipal.add(panelBusqueda, "Busqueda");

        // Acción del botón "Cancelar" para volver al menú de búsqueda
        cancelarButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) panelPrincipal.getLayout();
            cl.show(panelPrincipal, "Busqueda");
        });

        // Acción del botón "Editar Información"
        editarButton.addActionListener(e -> {
            if (clienteEncontrado != null) {
                mostrarMenuEdicion(); // Cambiar al formulario de edición
            } else {
                JOptionPane.showMessageDialog(this, "No se puede editar. Cliente no encontrado.");
            }
        });

        // Inicializar el panel de edición
        panelEdicion = new JPanel(new GridLayout(5, 1, 10, 10));
        JLabel tituloEdicion = new JLabel("¿Qué tipo de información desea editar?");
        tituloEdicion.setHorizontalAlignment(SwingConstants.CENTER);
        panelEdicion.add(tituloEdicion);

        JButton editarDatosPersonales = new JButton("Editar Datos Personales");
        JButton editarDatosContacto = new JButton("Editar Datos de Contacto");
        JButton editarEquipo = new JButton("Editar Equipo");
        JButton editarPlan = new JButton("Editar Plan");

        editarDatosPersonales.addActionListener(e -> JOptionPane.showMessageDialog(this, "Opción de editar Datos Personales seleccionada."));
        editarDatosContacto.addActionListener(e -> JOptionPane.showMessageDialog(this, "Opción de editar Datos de Contacto seleccionada."));
        editarEquipo.addActionListener(e -> JOptionPane.showMessageDialog(this, "Opción de editar Equipo seleccionada."));
        editarPlan.addActionListener(e -> JOptionPane.showMessageDialog(this, "Opción de editar Plan seleccionada."));

        panelEdicion.add(editarDatosPersonales);
        panelEdicion.add(editarDatosContacto);
        panelEdicion.add(editarEquipo);
        panelEdicion.add(editarPlan);

        panelPrincipal.add(panelEdicion, "Edicion");
    }

    // Método que busca y retorna un cliente o null, sin mostrar el resultado
    private Cliente buscarCliente(ActionEvent e) {
        String identificacionTexto = buscarField.getText().trim();

        try {
            int identificacion = Integer.parseInt(identificacionTexto);
            clienteEncontrado = gestorClientes.buscarClientePorNumeroId(listaClientes, identificacion);

            if (clienteEncontrado != null) {
                mostrarCliente(clienteEncontrado); // Mostrar cliente encontrado
                return clienteEncontrado; // Retorna el cliente encontrado
            } else {
                resultadosArea.setText("Cliente no encontrado.");
                JOptionPane.showMessageDialog(this, "Cliente No Encontrado");
                return null; // Retorna null si no se encuentra el cliente
            }
        } catch (NumberFormatException ex) {
            resultadosArea.setText("Error: El número de identificación debe ser numérico.");
            return null; // Retorna null si el formato es incorrecto
        }
    }

    // Método para mostrar los detalles del cliente en el área de resultados
    private void mostrarCliente(Cliente cliente) {
        StringBuilder detallesCliente = new StringBuilder();
        detallesCliente.append("Nombre: ").append(cliente.getDatosPersonales().getNombreCliente()).append("\n");
        detallesCliente.append("Número de Identificación: ").append(cliente.getDatosPersonales().getNumeroIdentificacion()).append("\n");
        detallesCliente.append("Dirección: ").append(cliente.getDatosPersonales().getDireccion()).append("\n");
        detallesCliente.append("Plan: ").append(cliente.getPlan().getNombrePlan()).append("\n");
        detallesCliente.append("Equipo: ").append(cliente.getEquipo().getMarca()).append(" ").append(cliente.getEquipo().getModelo()).append("\n");

        resultadosArea.setText(detallesCliente.toString());
    }

    // Método para cambiar al menú de edición
    private void mostrarMenuEdicion() {
        CardLayout cl = (CardLayout) panelPrincipal.getLayout();
        cl.show(panelPrincipal, "Edicion");
    }
}
