package project;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class VentanaEliminarTarjeta extends JFrame {
    private JTextField buscarField;
    private JTextField eliminarField; // Campo para número de tarjeta a eliminar
    private JButton buscarButton;
    private JButton eliminarButton; // Botón para eliminar la tarjeta
    private JTextArea resultadosArea;
    private ArrayList<Cliente> listaClientes;
    private GestorClientes gestorClientes;

    public VentanaEliminarTarjeta(ArrayList<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
        this.gestorClientes = new GestorClientes(); // Inicializa el gestor
        setTitle("Eliminar Tarjeta");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Crear componentes
        buscarField = new JTextField(20);
        eliminarField = new JTextField(20); // Inicializa el campo para eliminar tarjeta
        buscarButton = new JButton("Buscar");
        eliminarButton = new JButton("Eliminar Tarjeta");
        resultadosArea = new JTextArea(10, 30);
        resultadosArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultadosArea);

        // Configurar el botón de búsqueda
        buscarButton.addActionListener(this::buscarCliente);
        
        // Configurar el botón de eliminación
        eliminarButton.addActionListener(this::eliminarTarjeta);

        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        add(new JLabel("Número de Identificación:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        add(buscarField, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        add(buscarButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        add(scrollPane, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_END;
        add(new JLabel("Número de Tarjeta a Eliminar:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_START;
        add(eliminarField, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.CENTER;
        add(eliminarButton, gbc);
    }

    // Método que busca y retorna un cliente o null, sin mostrar el resultado
    private Cliente buscarCliente(ActionEvent e) {
        String identificacionTexto = buscarField.getText().trim();

        try {
            int identificacion = Integer.parseInt(identificacionTexto);
            Cliente cliente = gestorClientes.buscarClientePorNumeroId(listaClientes, identificacion);

            if (cliente != null) {
                mostrarCliente(cliente); // Mostrar cliente encontrado
                return cliente; // Retorna el cliente encontrado
            } else {
                resultadosArea.setText("Cliente no encontrado.");
                JOptionPane.showMessageDialog(this, "Cliente No Encontrado");
                return null; // Retorna null si no se encuentra el cliente
            }
        } catch (NumberFormatException ex) {
            resultadosArea.setText("Error: El número de identificación debe ser numérico.");
            return null; // Retorna null si el formato es incorrecto
        }
    }

    // Método para mostrar los detalles del cliente en el área de resultados
    private void mostrarCliente(Cliente cliente) {
        StringBuilder detallesCliente = new StringBuilder();
        detallesCliente.append("Nombre: ").append(cliente.getDatosPersonales().getNombreCliente()).append("\n");
        detallesCliente.append("Número de Identificación: ").append(cliente.getDatosPersonales().getNumeroIdentificacion()).append("\n");
        detallesCliente.append("Dirección: ").append(cliente.getDatosPersonales().getDireccion()).append("\n");
        detallesCliente.append("Plan: ").append(cliente.getPlan().getNombrePlan()).append("\n");
        detallesCliente.append("Equipo: ").append(cliente.getEquipo().getMarca()).append(" ").append(cliente.getEquipo().getModelo()).append("\n");

        // Mostrar facturas
        if (cliente.getFacturas().isEmpty()) {
            detallesCliente.append("Facturas: No hay facturas registradas.\n");
        } else {
            detallesCliente.append("Facturas:\n");
            for (String idFactura : cliente.getFacturas().keySet()) {
                Factura factura = cliente.getFacturas().get(idFactura);
                detallesCliente.append("  - Factura ID: ").append(factura.getIdFactura())
                        .append(", Monto: $").append(factura.getMonto())
                        .append(", Fecha: ").append(factura.getFechaEmision())
                        .append(", Estado: ").append(factura.getPagado() ? "PAGADO" : "NO PAGADO").append("\n");
            }
        }

        if (cliente.getTarjetasRegistradas().isEmpty()) {
            detallesCliente.append("\nTarjetas: No hay tarjetas registradas.\n");
        } else {
            detallesCliente.append("\nTarjetas:\n");
            for (int i = 0; i < cliente.getTarjetasRegistradas().keySet().size(); i++) {
                String numSerie = (String) cliente.getTarjetasRegistradas().keySet().toArray()[i]; // Obtiene el número de serie
                Tarjeta tarjeta = cliente.getTarjetasRegistradas().get(numSerie);

                // Agrega el formato requerido para cada tarjeta
                detallesCliente.append("tarjeta n°").append(i + 1).append(":").append("\n")
                        .append("  - Metodo de Pago: ").append(tarjeta.getMetodoPago()).append("\n")
                        .append("  - Tipo de Tarjeta: ").append(tarjeta.getTipoTarjeta()).append("\n")
                        .append("  - Nombre Titular: ").append(tarjeta.getNombreTitular()).append("\n")
                        .append("  - Número Tarjeta: ").append(tarjeta.getNumeroTarjeta()).append("\n\n"); // Agrega un espacio entre tarjetas
            }
        }

        resultadosArea.setText(detallesCliente.toString());
    }
    
    // Método para eliminar tarjeta
    private void eliminarTarjeta(ActionEvent e) {
        String numTarjeta = eliminarField.getText().trim();
        String identificacionTexto = buscarField.getText().trim();

        try {
            int identificacion = Integer.parseInt(identificacionTexto);
            Cliente cliente = gestorClientes.buscarClientePorNumeroId(listaClientes, identificacion);

            if (cliente != null) {
                // Intentar eliminar la tarjeta
                boolean eliminada = cliente.EliminarTarjeta(numTarjeta);
                if (eliminada) {
                    JOptionPane.showMessageDialog(this, "Tarjeta eliminada correctamente.");
                } else {
                    JOptionPane.showMessageDialog(this, "Error: Tarjeta no encontrada.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Cliente no encontrado.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Error: El número de identificación debe ser numérico.");
        }
    }
} 