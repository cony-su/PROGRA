package project;
import java.util.*;
import java.awt.*;
import javax.swing.*;

public class VentanaRegistro extends JFrame {
    private static final long serialVersionUID = 1L;
    ArrayList<Cliente> listaClientes;
    // Sección: Datos personales
    private JTextField nombreField;
    private JTextField fechaNacimientoField;
    private JTextField direccionField;
    private JTextField rutField;

    // Sección: Datos de contacto
    private JTextField direccionFacturacionField;
    private JTextField telefonoField;
    private JTextField correoField;

    // Sección: Datos del equipo
    private JTextField marcaField;
    private JTextField modeloField;
    private JTextField numeroSerieField;
    
    //Tipo de plan
    private JTextField TipoPlanField;

    private JButton botonContinuar1, botonContinuar2, botonContinuar3,botonRegistrar, botonCancelar, botonCancelar2, botonCancelar3;

    // CardLayout para cambiar entre las secciones
    private JPanel panelPrincipal;
    private CardLayout cardLayout;

    public VentanaRegistro(ArrayList<Cliente> listaClientes) {
    	this.listaClientes = listaClientes;
        setTitle("Registrar Cliente");
        setSize(400, 400); // Aumentar el tamaño de la ventana para un mejor diseño
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Inicialización del CardLayout
        cardLayout = new CardLayout();
        panelPrincipal = new JPanel(cardLayout);

        // Agregar las secciones
        panelPrincipal.add(crearPanelDatosPersonales(), "Datos Personales");
        panelPrincipal.add(crearPanelDatosContacto(), "Datos de Contacto");
        panelPrincipal.add(crearPanelDatosEquipo(), "Datos del Equipo");
        panelPrincipal.add(crearPanelDatosPlan(), "Datos del Plan");
        
        add(panelPrincipal);

        // Mostrar la primera sección (Datos Personales)
        cardLayout.show(panelPrincipal, "Datos Personales");
    }

    // Panel para Datos Personales
    private JPanel crearPanelDatosPersonales() {
        JPanel panel = new JPanel(new GridLayout(7, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Agregar margen

        panel.add(new JLabel("Nombre:", SwingConstants.CENTER));
        nombreField = new JTextField();
        panel.add(nombreField);

        panel.add(new JLabel("Fecha de Nacimiento:", SwingConstants.CENTER));
        fechaNacimientoField = new JTextField();
        panel.add(fechaNacimientoField);

        panel.add(new JLabel("Dirección:", SwingConstants.CENTER));
        direccionField = new JTextField();
        panel.add(direccionField);

        panel.add(new JLabel("RUT:", SwingConstants.CENTER));
        rutField = new JTextField();
        panel.add(rutField);

        botonContinuar1 = new JButton("Continuar");
        panel.add(botonContinuar1);

        botonCancelar = new JButton("Cancelar");
        panel.add(botonCancelar);

        // Acción para ir a la siguiente sección
        botonContinuar1.addActionListener(e -> cardLayout.show(panelPrincipal, "Datos de Contacto"));

        // Acción de cancelar
        botonCancelar.addActionListener(e -> dispose());

        return panel;
    }

    // Panel para Datos de Contacto
    private JPanel crearPanelDatosContacto() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Agregar margen

        panel.add(new JLabel("Dirección de Facturación:", SwingConstants.CENTER));
        direccionFacturacionField = new JTextField();
        panel.add(direccionFacturacionField);

        panel.add(new JLabel("Teléfono:", SwingConstants.CENTER));
        telefonoField = new JTextField();
        panel.add(telefonoField);

        panel.add(new JLabel("Correo:", SwingConstants.CENTER));
        correoField = new JTextField();
        panel.add(correoField);

        botonCancelar2 = new JButton("Cancelar");
        panel.add(botonCancelar2);
        botonCancelar2.addActionListener(e -> dispose());

        botonContinuar2 = new JButton("Continuar");
        panel.add(botonContinuar2);

        // Acción para ir a la siguiente sección
        botonContinuar2.addActionListener(e -> cardLayout.show(panelPrincipal, "Datos del Equipo"));

        return panel;
    }

    // Panel para Datos del Equipo
    private JPanel crearPanelDatosEquipo() {
        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10)); // Ajustar el layout a GridLayout
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Agregar margen

        panel.add(new JLabel("Marca:", SwingConstants.CENTER));
        marcaField = new JTextField(); // Cuadro de texto normal
        panel.add(marcaField);

        panel.add(new JLabel("Modelo:", SwingConstants.CENTER));
        modeloField = new JTextField(); // Cuadro de texto normal
        panel.add(modeloField);

        panel.add(new JLabel("Número de Serie:", SwingConstants.CENTER));
        numeroSerieField = new JTextField(); // Cuadro de texto normal
        panel.add(numeroSerieField);

        botonCancelar3 = new JButton("Cancelar");
        panel.add(botonCancelar3);
        botonCancelar3.addActionListener(e -> dispose());

        botonContinuar3 = new JButton("Continuar");
        panel.add(botonContinuar3);

        // Acción para ir a la siguiente sección
        botonContinuar3.addActionListener(e -> cardLayout.show(panelPrincipal, "Datos del Plan"));

        return panel;
    }
    
    private JPanel crearPanelDatosPlan() {
    	JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10)); // Ajustar el layout a GridLayout
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); 
        
        panel.add(new JLabel("Tipo de plan :", SwingConstants.CENTER));
        TipoPlanField = new JTextField(); // Cuadro de texto normal
        panel.add(TipoPlanField);

        botonRegistrar = new JButton("Registrar");
        JPanel buttonPanel = new JPanel(); // Panel para centrar el botón
        buttonPanel.add(botonRegistrar);
        panel.add(buttonPanel); // Agregar el panel con el botón al panel principal

        // Acción para registrar el cliente
        botonRegistrar.addActionListener(e -> registrarCliente());

        return panel;
    }

    // Método para registrar el cliente (modificado)
    private void registrarCliente() {
        // Recoger datos de los campos de texto
        String nombre = nombreField.getText();
        String fechaNacimiento = fechaNacimientoField.getText();
        String direccion = direccionField.getText();
        String rut = rutField.getText();

        String direccionFacturacion = direccionFacturacionField.getText();
        String telefono = telefonoField.getText();
        String correo = correoField.getText();

        String marca = marcaField.getText();
        String modelo = modeloField.getText();
        String numeroSerie = numeroSerieField.getText();
        
        String TipoPlan = TipoPlanField.getText();
        int tipoPlanInt = Integer.parseInt(TipoPlan);
        PlanesDisponibles plan = null;
        Factura factura1 = null;
        switch(tipoPlanInt)
        {
          case 1:
            plan = new PlanesDisponibles("Plan Económico", 8000, false, 60, false, 0, false, 10);
            factura1 = new Factura("253", 8000, "2023-06-01", false);
            break;

          case 2:
            plan = new PlanesDisponibles("Plan Básico", 12000, false, 120, false, 30, false, 50);
            factura1 = new Factura("117", 12000, "2023-06-01", false);
            break;

          case 3:
            plan = new PlanesDisponibles("Plan Normal", 15000, false, 200, false, 100, false, 100);
            factura1 = new Factura("905", 15000, "2023-06-01", false);
            break;

          case 4:
            plan = new PlanesDisponibles("Plan Premium", 20000, true, 0, true, 0, true, 0);
            factura1 = new Factura("612", 20000, "2023-06-01", false);
            break;

          default:
            break;
        }

        // Crear los objetos con los datos ingresados
        DatosPersonales datosPersonales = new DatosPersonales(nombre, fechaNacimiento, direccion, rut);
        DatosContacto datosContacto = new DatosContacto(direccionFacturacion, telefono, correo);
        Equipo equipo = new Equipo(marca, modelo, numeroSerie);
        Cliente cliente = new Cliente(datosPersonales, datosContacto, plan, equipo);
        listaClientes.add(cliente);
        cliente.agregarFactura(factura1);

        JOptionPane.showMessageDialog(this, "Cliente registrado con éxito.");
        dispose(); // Cierra la ventana después de registrar
    }
    
}
