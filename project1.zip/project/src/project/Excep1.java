package project;

//ERROR ESPECIFICO (EL USUARIO INGRESA LETRAS Y NO NUMEROS)
public class Excep1 extends Exception
{
	public Excep1()
	{
		super("Opción inválida, por favor ingrese un número valido");
	}
}


