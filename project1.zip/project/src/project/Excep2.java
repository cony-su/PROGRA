package project;

//ERROR GENERAL
public class Excep2 extends Exception {
	
	public Excep2()
	{
		super();
	}

}
