package project;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.*;
import java.awt.*;

public class Ventana extends JFrame 
{
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private CardLayout cardLayout; // Usar CardLayout para cambiar entre vistas
    private JPanel menuPrincipal; // Panel para el menú principal
    private JPanel subMenuClientes; // Panel para el submenú de clientes
    private JPanel subMenuTatjetas;
    private ArrayList<Cliente> listaClientes = new ArrayList<Cliente>(); 

    public Ventana(ArrayList<Cliente> listaClientes) {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        setTitle("Menu Principal");
        
        cardLayout = new CardLayout();
        contentPane = new JPanel(cardLayout); // Asignar CardLayout al contentPane
        setContentPane(contentPane);
        
        menuPrincipal = crearPanelMenuPrincipal(); // Crear panel del menú principal
        subMenuClientes = crearPanelSubMenuClientes(); // Crear panel del submenú
        subMenuTatjetas = crearPanelSubMenuTarjetas();
        
        contentPane.add(menuPrincipal, "Bienvenido al Sistema de Telefonía Celular"); // Agregar menú principal
        contentPane.add(subMenuClientes, "SubMenuClientes"); // Agregar submenú de clientes
        contentPane.add(subMenuTatjetas, "SubMenuTarjetas"); // Agregar submenú de tarjetas
        
        cardLayout.show(contentPane, "MenuPrincipal"); // Mostrar menú principal al inicio
        
    }


    private JPanel crearPanelMenuPrincipal() {
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.Y_AXIS)); // Alinear verticalmente
        panelBotones.setPreferredSize(new Dimension(300, 300)); // Cambia 200, 200 según lo desees
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Margen interno

        JLabel tituloMenu = new JLabel("Bienvenido al Sistema de Telefonía Celular", SwingConstants.CENTER);
        panelBotones.add(tituloMenu);
        
        JButton botonSubmenuClientes = new JButton("Mostrar SubMenú de Clientes");
        JButton botonSubmenuTarjetas = new JButton("Mostrar SubMenú de Tarjetas");
        JButton botonMostrarPlanesDisponibles = new JButton("Mostrar Planes Disponibles");
        JButton botonGenerarReporteGeneral = new JButton("Generar Reporte General");
        JButton botonPagarFactura = new JButton("Pagar Factura");
        JButton botonSalir = new JButton("Salir");

        // Añadir acción a los botones
        botonSubmenuClientes.addActionListener(e -> cardLayout.show(contentPane, "SubMenuClientes")); // Cambia a submenú
        botonSubmenuTarjetas.addActionListener(e -> cardLayout.show(contentPane, "SubMenuTarjetas")); // Cambia a submenú de tarjetas
        botonMostrarPlanesDisponibles.addActionListener(e -> mostrarPlanesDisponibles());
        botonGenerarReporteGeneral.addActionListener(e -> generarReporteGeneral());
        botonPagarFactura.addActionListener(e -> pagarFactura());
        botonSalir.addActionListener(e -> salir());

        // Agregar botones al panel
        panelBotones.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre el título y los botones
        panelBotones.add(botonSubmenuClientes);
        panelBotones.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        panelBotones.add(botonSubmenuTarjetas);
        panelBotones.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        panelBotones.add(botonMostrarPlanesDisponibles);
        panelBotones.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        panelBotones.add(botonGenerarReporteGeneral);
        panelBotones.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        panelBotones.add(botonPagarFactura);
        panelBotones.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        panelBotones.add(botonSalir);

        return panelBotones; // Retornar el panel de botones
    }

    private JPanel crearPanelSubMenuClientes() {
        JPanel panelSubMenu = new JPanel();
        panelSubMenu.setLayout(new BoxLayout(panelSubMenu, BoxLayout.Y_AXIS));
        panelSubMenu.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Margen interno

        JLabel tituloSubMenu = new JLabel("SubMenú de Clientes", SwingConstants.CENTER);
        panelSubMenu.add(tituloSubMenu);

        JButton botonRegistrarCliente = new JButton("Registrar Cliente");
        JButton botonMostrarClientes = new JButton("Mostrar Clientes");
        JButton botonModificarCliente = new JButton("Modificar Cliente");
        JButton botonEliminarCliente = new JButton("Eliminar Cliente");
        JButton botonVolver = new JButton("Volver al Menú Principal");

        // Añadir acciones a los botones
        botonRegistrarCliente.addActionListener(e -> registrarCliente());
        botonMostrarClientes.addActionListener(e -> mostrarClientes());
        botonModificarCliente.addActionListener(e -> modificarCliente());
        botonEliminarCliente.addActionListener(e -> eliminarCliente());
        botonVolver.addActionListener(e -> cardLayout.show(contentPane, "MenuPrincipal")); // Volver al menú principal

        panelSubMenu.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre el título y los botones
        panelSubMenu.add(botonRegistrarCliente);
        panelSubMenu.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        panelSubMenu.add(botonMostrarClientes);
        panelSubMenu.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        panelSubMenu.add(botonModificarCliente);
        panelSubMenu.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        panelSubMenu.add(botonEliminarCliente);
        panelSubMenu.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        panelSubMenu.add(botonVolver);
        
        

        return panelSubMenu; // Retornar el panel del submenú
    }

    private void subMenuTarjetas() {
        // Lógica para mostrar tarjetas
    }

    private void mostrarPlanesDisponibles() {
        // Lógica para mostrar planes
    }

    private void generarReporteGeneral() {
        // Lógica para generar reporte
    }

    private void pagarFactura() {
        // Lógica para pagar factura
    }

    private void registrarCliente() {
        // Lógica para registrar cliente
    	VentanaRegistro ventanaRegistro = new VentanaRegistro();
	    ventanaRegistro.setVisible(true);
        JOptionPane.showMessageDialog(this, "Funcionalidad de registro de cliente.");
    }

    private void mostrarClientes() {
        // Lógica para mostrar clientes
        JOptionPane.showMessageDialog(this, "Funcionalidad de mostrar clientes.");
    }

    private void modificarCliente() {
        // Lógica para modificar cliente
        JOptionPane.showMessageDialog(this, "Funcionalidad de modificar cliente.");
    }

    private void eliminarCliente() {
        // Lógica para eliminar cliente
        JOptionPane.showMessageDialog(this, "Funcionalidad de eliminar cliente.");
    }

    private void salir() {
        System.exit(0); // Cierra la aplicación
    }

    private JPanel crearPanelSubMenuTarjetas() {
        JPanel panelSubMenu = new JPanel();
        panelSubMenu.setLayout(new BoxLayout(panelSubMenu, BoxLayout.Y_AXIS));
        panelSubMenu.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Margen interno

        JLabel tituloSubMenu = new JLabel("SubMenú de Tarjetas", SwingConstants.CENTER);
        panelSubMenu.add(tituloSubMenu);

        JButton botonMostrarTarjetasAsociadas = new JButton("Mostrar Tarjetas Asociadas ");
        JButton botonEliminarTarjetaAsociada = new JButton("Eliminar Tarjeta Asociada");
        JButton botonEditarTarjetaAsociada = new JButton("Editar Tarjeta Asociada");
        JButton botonVolver = new JButton("Volver al Menú Principal"); 

        // Añadir acciones a los botones
        botonMostrarTarjetasAsociadas.addActionListener(e -> mostrarTarjetasAsociadas());
        botonEliminarTarjetaAsociada.addActionListener(e -> eliminarTarjetaAsociada());
        botonEditarTarjetaAsociada.addActionListener(e -> editarTarjetaAsociada());
        botonVolver.addActionListener(e -> cardLayout.show(contentPane, "MenuPrincipal")); // Volver al menú principal

        panelSubMenu.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre el título y los botones
        panelSubMenu.add(botonMostrarTarjetasAsociadas);
        panelSubMenu.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        panelSubMenu.add(botonEliminarTarjetaAsociada);
        panelSubMenu.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        panelSubMenu.add(botonEditarTarjetaAsociada);
        panelSubMenu.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        panelSubMenu.add(botonVolver);
        
        return panelSubMenu; // Retornar el panel del submenú
    }
    
    private void mostrarTarjetasAsociadas() {
        // Lógica para modificar cliente
        JOptionPane.showMessageDialog(this, "Funcionalidad de mostrar tarjetas.");
    }
    
    private void eliminarTarjetaAsociada() {
        // Lógica para modificar cliente
        JOptionPane.showMessageDialog(this, "Funcionalidad de eliminar tarjetas.");
    }
    
    private void editarTarjetaAsociada() {
        // Lógica para modificar cliente
        JOptionPane.showMessageDialog(this, "Funcionalidad de editar tarjetas.");
    }

}
