package project;

import java.awt.EventQueue;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.*;
import java.awt.*;

public class VentanaRegistro extends JFrame {
    private JTextField nombreField;
    private JTextField telefonoField;
    private JTextField fechaNacimientoField;
    private JTextField direccionField;
    private JTextField numeroIdentificacionField;
    private JTextField rutField;
    private JTextField direccionFacturacionField;
    private JTextField correoField;

    private JButton botonRegistrar;
    private JButton botonCancelar;

    public VentanaRegistro() {
        setTitle("Registrar Cliente");
        setSize(400, 300); // Ajustar el tamaño de la ventana
        setLocationRelativeTo(null); // Centrar la ventana
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cerrar solo esta ventana, no toda la aplicación

        // Crear los campos de entrada
        nombreField = new JTextField(15); // Ajustar el tamaño del campo de texto
        telefonoField = new JTextField(15); 

        // Crear los botones
        botonRegistrar = new JButton("Registrar");
        botonCancelar = new JButton("Cancelar");

        // Crear el panel principal con GridBagLayout
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Añadir espacio entre los componentes

        // Configurar las posiciones de los componentes en la cuadrícula
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Nombre:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(nombreField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Teléfono:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(telefonoField, gbc);

        // Añadir los botones
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(botonRegistrar, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(botonCancelar, gbc);

        // Añadir el panel al frame
        add(panel);

        // Acción al presionar el botón "Cancelar"
        botonCancelar.addActionListener(e -> dispose()); // Cerrar la ventana
    }
}